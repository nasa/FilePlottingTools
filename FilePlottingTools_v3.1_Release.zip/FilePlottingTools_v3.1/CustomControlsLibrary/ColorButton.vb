﻿Public Class ColorButton
    Private SelectedColor As Color
    Private ColorDiag As ColorDialog
    Private DropForm As ColorSelectorForm

    Public Sub New()
        ' This call is required by the designer.
        InitializeComponent()
        ' Add any initialization after the InitializeComponent() call.
    End Sub

    Public Sub New(ByVal ButtonColors As ArrayList, ByRef ColorDiag As ColorDialog)
        ' This call is required by the designer.
        InitializeComponent()
        ' Add any initialization after the InitializeComponent() call.
        InitialzeButton(ButtonColors, ColorDiag)

    End Sub

    Private Sub btnColor_Click(sender As System.Object, e As System.EventArgs) Handles btnColor.Click
        'ColorDiag.ShowDialog()
        'Me.BackColor = ColorDiag.Color

        Me.DropForm.StartPosition = FormStartPosition.Manual
        'Dim LocPoint As New Point(Me.Parent.Location.X + Me.Left, Me.Parent.Location.Y + Me.Top + 75)
        Dim LocPoint As Point = Me.PointToScreen(New Point(0, 0))
        Me.DropForm.Location = LocPoint
        If Me.DropForm.ShowDialog() = DialogResult.OK Then
            MyColor = Me.DropForm.SelectedColor
        End If
    End Sub

    Public Sub InitialzeButton(ByVal ButtonColors As ArrayList, ByRef ColorDiag As ColorDialog)
        Me.ColorDiag = ColorDiag
        Me.DropForm = New ColorSelectorForm(ButtonColors, ColorDiag)
    End Sub

    Public Property MyColor() As Color
        Get
            Return SelectedColor
        End Get
        Set(value As Color)
            SelectedColor = value
            btnColor.BackColor = SelectedColor
            btnColor.ForeColor = SelectedColor
            btnColor.Refresh()
        End Set
    End Property
End Class

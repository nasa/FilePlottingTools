﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ColorSelectorForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnMore = New System.Windows.Forms.Button()
        Me.btnC8 = New System.Windows.Forms.Button()
        Me.btnC7 = New System.Windows.Forms.Button()
        Me.btnC6 = New System.Windows.Forms.Button()
        Me.btnC5 = New System.Windows.Forms.Button()
        Me.btnC4 = New System.Windows.Forms.Button()
        Me.btnC3 = New System.Windows.Forms.Button()
        Me.btnC2 = New System.Windows.Forms.Button()
        Me.btnC1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnMore
        '
        Me.btnMore.Location = New System.Drawing.Point(23, 92)
        Me.btnMore.Name = "btnMore"
        Me.btnMore.Size = New System.Drawing.Size(75, 27)
        Me.btnMore.TabIndex = 17
        Me.btnMore.Text = "More..."
        Me.btnMore.UseVisualStyleBackColor = True
        '
        'btnC8
        '
        Me.btnC8.BackColor = System.Drawing.Color.FromArgb(CType(CType(75, Byte), Integer), CType(CType(172, Byte), Integer), CType(CType(198, Byte), Integer))
        Me.btnC8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnC8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(75, Byte), Integer), CType(CType(172, Byte), Integer), CType(CType(198, Byte), Integer))
        Me.btnC8.Location = New System.Drawing.Point(90, 38)
        Me.btnC8.Name = "btnC8"
        Me.btnC8.Size = New System.Drawing.Size(20, 20)
        Me.btnC8.TabIndex = 16
        Me.btnC8.UseVisualStyleBackColor = False
        '
        'btnC7
        '
        Me.btnC7.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(162, Byte), Integer))
        Me.btnC7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnC7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(162, Byte), Integer))
        Me.btnC7.Location = New System.Drawing.Point(64, 38)
        Me.btnC7.Name = "btnC7"
        Me.btnC7.Size = New System.Drawing.Size(20, 20)
        Me.btnC7.TabIndex = 15
        Me.btnC7.UseVisualStyleBackColor = False
        '
        'btnC6
        '
        Me.btnC6.BackColor = System.Drawing.Color.Red
        Me.btnC6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnC6.ForeColor = System.Drawing.Color.Red
        Me.btnC6.Location = New System.Drawing.Point(38, 38)
        Me.btnC6.Name = "btnC6"
        Me.btnC6.Size = New System.Drawing.Size(20, 20)
        Me.btnC6.TabIndex = 14
        Me.btnC6.UseVisualStyleBackColor = False
        '
        'btnC5
        '
        Me.btnC5.BackColor = System.Drawing.Color.FromArgb(CType(CType(79, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(189, Byte), Integer))
        Me.btnC5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnC5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(79, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(189, Byte), Integer))
        Me.btnC5.Location = New System.Drawing.Point(12, 38)
        Me.btnC5.Name = "btnC5"
        Me.btnC5.Size = New System.Drawing.Size(20, 20)
        Me.btnC5.TabIndex = 13
        Me.btnC5.UseVisualStyleBackColor = False
        '
        'btnC4
        '
        Me.btnC4.BackColor = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(125, Byte), Integer))
        Me.btnC4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnC4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(125, Byte), Integer))
        Me.btnC4.Location = New System.Drawing.Point(90, 12)
        Me.btnC4.Name = "btnC4"
        Me.btnC4.Size = New System.Drawing.Size(20, 20)
        Me.btnC4.TabIndex = 12
        Me.btnC4.UseVisualStyleBackColor = False
        '
        'btnC3
        '
        Me.btnC3.BackColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.btnC3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnC3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.btnC3.Location = New System.Drawing.Point(64, 12)
        Me.btnC3.Name = "btnC3"
        Me.btnC3.Size = New System.Drawing.Size(20, 20)
        Me.btnC3.TabIndex = 11
        Me.btnC3.UseVisualStyleBackColor = False
        '
        'btnC2
        '
        Me.btnC2.BackColor = System.Drawing.Color.FromArgb(CType(CType(155, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(89, Byte), Integer))
        Me.btnC2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnC2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(155, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(89, Byte), Integer))
        Me.btnC2.Location = New System.Drawing.Point(38, 12)
        Me.btnC2.Name = "btnC2"
        Me.btnC2.Size = New System.Drawing.Size(20, 20)
        Me.btnC2.TabIndex = 10
        Me.btnC2.UseVisualStyleBackColor = False
        '
        'btnC1
        '
        Me.btnC1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.btnC1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnC1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.btnC1.Location = New System.Drawing.Point(12, 12)
        Me.btnC1.Name = "btnC1"
        Me.btnC1.Size = New System.Drawing.Size(20, 20)
        Me.btnC1.TabIndex = 9
        Me.btnC1.UseVisualStyleBackColor = False
        '
        'ColorSelectorForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(125, 131)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnMore)
        Me.Controls.Add(Me.btnC8)
        Me.Controls.Add(Me.btnC7)
        Me.Controls.Add(Me.btnC6)
        Me.Controls.Add(Me.btnC5)
        Me.Controls.Add(Me.btnC4)
        Me.Controls.Add(Me.btnC3)
        Me.Controls.Add(Me.btnC2)
        Me.Controls.Add(Me.btnC1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "ColorSelectorForm"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnMore As System.Windows.Forms.Button
    Friend WithEvents btnC8 As System.Windows.Forms.Button
    Friend WithEvents btnC7 As System.Windows.Forms.Button
    Friend WithEvents btnC6 As System.Windows.Forms.Button
    Friend WithEvents btnC5 As System.Windows.Forms.Button
    Friend WithEvents btnC4 As System.Windows.Forms.Button
    Friend WithEvents btnC3 As System.Windows.Forms.Button
    Friend WithEvents btnC2 As System.Windows.Forms.Button
    Friend WithEvents btnC1 As System.Windows.Forms.Button
End Class

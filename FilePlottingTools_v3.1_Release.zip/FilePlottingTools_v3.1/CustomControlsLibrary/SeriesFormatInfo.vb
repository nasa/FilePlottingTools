﻿Public Class SeriesFormatInfo

End Class

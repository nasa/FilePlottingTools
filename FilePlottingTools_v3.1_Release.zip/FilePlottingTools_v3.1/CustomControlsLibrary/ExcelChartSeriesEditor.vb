﻿
Public Class ExcelChartSeriesEditor
    Private SeriesColor As Color
    Private ColorDiag As ColorDialog
    Private ColorSelectForm As ColorSelectorForm

    'NOTE:  This is not done,, needs work, aSeries is not integer
    Public Sub New(ByRef aSeries As Integer, ByRef ClrDiag As ColorDialog, ByRef ColorList As ArrayList)
        InitializeComponent()
        Me.btnColor.InitialzeButton(ColorList, ClrDiag)

    End Sub

    Private Sub btnColor_Load(sender As System.Object, e As System.EventArgs) Handles btnColor.Load

    End Sub
End Class

﻿Imports System.Collections
Imports System.Diagnostics
Imports System.Windows.Forms
Imports System.Drawing
Imports Microsoft.Win32
Imports System.IO

Module UsefulFunctions

    Public Sub MoveItemsInListView(ByRef lvwListView As ListView, ByVal blnMoveUp As Boolean)
        'got this online:
        'http://www.pchilton.co.uk/2011/04/16/vb-net-move-listviewitems-up-and-down/

        Try
            'Set the listview index to limit to depending on whether we are moving things up or down in the list
            Dim intLimittedIndex As Integer = (lvwListView.Items.Count - 1)
            If blnMoveUp Then intLimittedIndex = 0

            'Define a new collection of the listview indexes to move
            Dim colIndexesToMove As New List(Of Integer)()

            'Loop through each selected item in the listview (multiple select support)
            For Each lviSelectedItem As ListViewItem In lvwListView.SelectedItems
                'Add the item's index to the collection
                colIndexesToMove.Add(lviSelectedItem.Index)

                'If this item is at the limit we defined
                If lviSelectedItem.Index = intLimittedIndex Then
                    'Do not attempt to move item(s) as we are at the top or bottom of the list
                    Exit Try
                End If
            Next

            'If we are moving items down
            If Not blnMoveUp Then
                'Reverse the index list so that we move items from the bottom of the selection first
                colIndexesToMove.Reverse()
            End If

            'Loop through each index we want to move
            For Each intIndex As Integer In colIndexesToMove
                'Define a new listviewitem
                Dim lviNewItem As ListViewItem = CType(lvwListView.Items(intIndex).Clone(), ListViewItem)

                'Remove the currently selected item from the list
                lvwListView.Items(intIndex).Remove()

                'Insert the new item in it's new place
                If blnMoveUp Then
                    lvwListView.Items.Insert(intIndex - 1, lviNewItem)
                Else
                    lvwListView.Items.Insert(intIndex + 1, lviNewItem)
                End If

                'Set the new item to be selected
                lviNewItem.Selected = True
            Next
        Catch ex As Exception
            Trace.WriteLine("MoveItemsInListView() has thrown an exception: " & ex.Message)
        Finally
            'Set the focus on the listview
            lvwListView.Focus()
        End Try
    End Sub

    Public Function PointsToPixelsAsPoint(ByVal Xpoints As Double, ByVal Ypoints As Double) As Point

        Dim x As Integer = Xpoints / 72 * 96
        Dim y As Integer = Ypoints / 72 * 96

        Dim newpoint As New Point(x, y)

        Return newpoint

    End Function

    Public Sub SaveFileFromResource(ByVal FilePath As String, ByRef file As Object)
        Dim FByte() As Byte = file
        My.Computer.FileSystem.WriteAllBytes(FilePath, FByte, True)
    End Sub

    Public Function GetVersionString() As String
        Return My.Application.Info.Version.Major.ToString + "." + My.Application.Info.Version.Minor.ToString
    End Function

    Public Function GetUserRegKeyValue(ByVal path As String, ByVal keyName As String) As Object

        If UserRegKeyExists(path) Then
            Dim regKey As Object = Registry.CurrentUser.OpenSubKey(path, False)

            Dim value As Object = regKey.GetValue(keyName)
            Return value
        Else
            Return Nothing
        End If

    End Function

    Public Function GetLocalRegKeyValue(ByVal path As String, ByVal keyName As String) As Object

        If LocalRegKeyExists(path) Then
            Dim regKey As Object = Registry.LocalMachine.OpenSubKey(path, False)

            Dim value As Object = regKey.GetValue(keyName)
            Return value
        Else
            Return Nothing
        End If

    End Function

    Public Function UserRegKeyExists(ByVal path As String) As Boolean
        Dim regKey As Object = Registry.CurrentUser.OpenSubKey(path, False)
        If regKey Is Nothing Then
            Return False
        Else
            Return True
        End If
    End Function

    Public Function LocalRegKeyExists(ByVal path As String) As Boolean
        Dim regKey As Object = Registry.LocalMachine.OpenSubKey(path, False)
        If regKey Is Nothing Then
            Return False
        Else
            Return True
        End If
    End Function

    Public Function ChangeFileToTabDelimitedCharArray(ByVal FileName As String, ByVal DelimArray As Char(), ByRef NumRows As Integer, ByRef NumCols As Integer) As Char()
        'initialize NumCols and NumRows to 0
        NumCols = 0
        NumRows = 0

        'Read the entire file into a string, count number of characters, and created fixed size character array.
        'close reader
        Dim Fullfilereader As StreamReader = New StreamReader(FileName)
        Dim NumChars As Integer = Fullfilereader.ReadToEnd.Count()
        Dim LineChar(NumChars) As Char
        Fullfilereader.Close()
        Fullfilereader.Dispose()

        'open a new reader on the same file for line by line reading
        Dim LineReader As StreamReader = New StreamReader(FileName)
        Dim index As Integer = 0

        'Read all lines in file
        While True

            Dim Line As String = LineReader.ReadLine()
            'split the line by the delimiters in the delimarray
            Dim ValueArray() As String = Line.Split(DelimArray, StringSplitOptions.RemoveEmptyEntries)


            If ValueArray.Count = 0 Then
                'there are no entries in the line
            Else
                'the line has entries, increment num rows and cols
                NumRows += 1
                NumCols = ValueArray.Count

                'loop through each entry and add to fixed size array
                'seperate each entry by a tab, and add return at end of line
                For i As Integer = 0 To NumCols - 1
                    For j As Integer = 0 To ValueArray(i).Count - 1
                        LineChar(index) = ValueArray(i)(j)
                        index += 1
                    Next
                    If i = NumCols - 1 Then
                        LineChar(index) = vbCrLf
                        index += 1
                    Else
                        LineChar(index) = vbTab
                        index += 1
                    End If

                Next

            End If

            'check if its the end of the file, if so exit while
            If LineReader.EndOfStream Then
                Exit While
            End If

        End While

        'close the file
        LineReader.Close()
        LineReader.Dispose()

        Return LineChar

    End Function

    Public Function GetFileNameFromFullPathText(ByVal FullPath As String) As String

        Dim LastSlashIndex As Integer = FullPath.LastIndexOf("\")

        Return FullPath.Substring(LastSlashIndex + 1)

    End Function

End Module

﻿Public Class ColorSelectorForm
    Public SelectedColor As Color
    Public ColorList As ArrayList
    Private ClrDialog As ColorDialog
    Public Sub New(ByRef ButtonColorList As ArrayList, ByRef clrdiag As ColorDialog)
        InitializeComponent()
        Me.ColorList = ButtonColorList
        Me.ClrDialog = clrdiag
    End Sub

    Private Sub ColorSelectorForm_Deactivate(sender As Object, e As System.EventArgs) Handles Me.Deactivate
        ' when the form is deactivated, close it
        If SelectedColor = Nothing Then
            Me.DialogResult = Windows.Forms.DialogResult.Cancel
        Else
            Me.DialogResult = Windows.Forms.DialogResult.OK
        End If

    End Sub

    Private Sub btnC1_Click(sender As System.Object, e As System.EventArgs) Handles btnC1.Click
        Me.SelectedColor = ColorList(0)
        Me.Hide()
    End Sub

    Private Sub btnC2_Click(sender As System.Object, e As System.EventArgs) Handles btnC2.Click
        Me.SelectedColor = ColorList(1)
        Me.Hide()
    End Sub

    Private Sub btnC3_Click(sender As System.Object, e As System.EventArgs) Handles btnC3.Click
        Me.SelectedColor = ColorList(2)
        Me.Hide()
    End Sub

    Private Sub btnC4_Click(sender As System.Object, e As System.EventArgs) Handles btnC4.Click
        Me.SelectedColor = ColorList(3)
        Me.Hide()
    End Sub

    Private Sub btnC5_Click(sender As System.Object, e As System.EventArgs) Handles btnC5.Click
        Me.SelectedColor = ColorList(4)
        Me.Hide()
    End Sub

    Private Sub btnC6_Click(sender As System.Object, e As System.EventArgs) Handles btnC6.Click
        Me.SelectedColor = ColorList(5)
        Me.Hide()
    End Sub

    Private Sub btnC7_Click(sender As System.Object, e As System.EventArgs) Handles btnC7.Click
        Me.SelectedColor = ColorList(6)
        Me.Hide()
    End Sub

    Private Sub btnC8_Click(sender As System.Object, e As System.EventArgs) Handles btnC8.Click
        Me.SelectedColor = ColorList(7)
        Me.Hide()
    End Sub

    Private Sub ColorSelectorForm_MouseLeave(sender As Object, e As System.EventArgs) Handles Me.MouseLeave
        Me.Hide()
    End Sub

    Protected Overrides Sub OnMouseLeave(e As System.EventArgs)
        'over rides the default mouse leave action
        'when you enter a child control, it assumes leaving parent control
        'the if statment here checks if the mouse is within the parent 
        'if not then it executes mouseleave
        If Me.ClientRectangle.Contains(Me.PointToClient(Control.MousePosition)) Then
        Else
            MyBase.OnMouseLeave(e)
        End If

    End Sub

    Private Sub btnMore_Click(sender As System.Object, e As System.EventArgs) Handles btnMore.Click
        Me.ClrDialog.ShowDialog()
        Me.SelectedColor = ClrDialog.Color
        Me.Hide()
    End Sub
End Class
﻿Public Class SubmodelCollection
    Inherits Collections.CollectionBase

    Public Sub Add(ByVal submodel As SubmodelInfo)
        Me.List.Add(submodel)
    End Sub

    Public Sub Remove(ByVal submodel As SubmodelInfo)
        Me.List.Remove(submodel)
    End Sub

    Public Property Item(ByVal index As Integer) As SubmodelInfo
        Get
            Return CType(Me.List.Item(index), SubmodelInfo)
        End Get
        Set(ByVal value As SubmodelInfo)
            Me.List.Item(index) = value
        End Set
    End Property

    Public ReadOnly Property IndexOf(ByVal SubModelName As String)
        Get
            For i As Integer = 0 To Me.List.Count - 1
                If CType(Me.List(i), SubmodelInfo).SubModelName = SubModelName Then
                    Return i
                End If
            Next
            Return -1
        End Get
    End Property

    Public ReadOnly Property CountNumberOfColumnsRequired As Integer
        Get
            Dim count As Integer = 1
            For Each subm As SubmodelInfo In Me.List
                count += subm.GetAllNodes.Count()
            Next
            Return count
        End Get
    End Property
End Class

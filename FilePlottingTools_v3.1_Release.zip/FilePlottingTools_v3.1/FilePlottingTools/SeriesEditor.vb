﻿Imports System.Windows.Forms
Imports System.Collections
Imports System.Drawing

Public Class SeriesEditor
    Public ClrDiag As New ColorDialog
    Public DefaultButtonColorArray As ArrayList
    Public SeriesArray As ArrayList
    Public SeriesEditControlArray As ArrayList
    Private TheChart As Excel.Chart
    'SJS 04-30-15 ADDED FROM DECOMPILED CODE
    Private UpdateChartOnOkClick As Boolean

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()
        Me.AutoScaleMode = Windows.Forms.AutoScaleMode.Dpi
        'Add any initialization after the InitializeComponent() call.
        '------------------
        'SJS 04-30-15 ADDED FROM DECOMPILED CODE
        Me.UpdateChartOnOkClick = True
        '---------
        SetDefaultColorList()
        'Dim seriesControl As New CustomControlsLibrary.ExcelChartSeriesEditor(0, Me.ClrDiag, Me.ColorArray)
        'FlowLayoutPanel1.Controls.Add(seriesControl)

    End Sub

    Public Sub New(ByRef aChart As Excel.Chart)
        Me.New()
        Me.TheChart = aChart

        PopulateControl()

    End Sub

    Public Sub New(ByRef aChart As Excel.Chart, ByRef ButtonColors As ArrayList)
        Me.New()
        Me.TheChart = aChart
        Me.DefaultButtonColorArray = ButtonColors
        PopulateControl()
    End Sub

    Private Sub PopulateControl()
        Me.SeriesArray = New ArrayList
        Me.SeriesEditControlArray = New ArrayList

        For Each series As Excel.Series In Me.TheChart.SeriesCollection
            Me.SeriesArray.Add(series)
            Dim seriescontrol As New ExcelChartSeriesEditor(series, DefaultButtonColorArray, ClrDiag)
            Me.SeriesEditControlArray.Add(seriescontrol)
            FlowLayoutPanel1.Controls.Add(seriescontrol)
        Next

    End Sub

    Private Sub SetDefaultColorList()
        Me.DefaultButtonColorArray = New ArrayList
        Me.DefaultButtonColorArray.Add(Color.FromArgb(192, 80, 77))
        Me.DefaultButtonColorArray.Add(Color.FromArgb(155, 187, 89))
        Me.DefaultButtonColorArray.Add(Color.FromArgb(247, 150, 70))
        Me.DefaultButtonColorArray.Add(Color.FromArgb(31, 73, 125))
        Me.DefaultButtonColorArray.Add(Color.FromArgb(79, 129, 189))
        Me.DefaultButtonColorArray.Add(Color.FromArgb(255, 0, 0))
        Me.DefaultButtonColorArray.Add(Color.FromArgb(128, 100, 162))
        Me.DefaultButtonColorArray.Add(Color.FromArgb(75, 172, 198))
        Me.DefaultButtonColorArray.Add(Color.FromArgb(0, 0, 0))
    End Sub

    Private Sub ModifySeries()

        For i As Integer = 0 To Me.SeriesEditControlArray.Count - 1
            Dim theControl As ExcelChartSeriesEditor = Me.SeriesEditControlArray(i)
            Dim theSeries As Excel.Series = DirectCast(Me.SeriesArray(i), Excel.Series)


            theSeries.Border.Color = ColorTranslator.ToOle(theControl.btnColor.MyColor)
            theSeries.Format.Line.DashStyle = theControl.GetLineStyle
            '------------------
            'SJS 04-30-15 ADDED FROM DECOMPILED CODE
            theSeries.Format.Line.Weight = theControl.nudLineWeight.Value
            '--------------------------
        Next
    End Sub

    Private Sub btnOK_Click(sender As System.Object, e As System.EventArgs) Handles btnOK.Click

        'SJS 04-30-15 COMMENTED THIS OUT, REPLACED WITH DECOMPILED VERSION
        'Me.ModifySeries()
        'Me.Close()
        If Me.UpdateChartOnOkClick Then
            Me.ModifySeries()
            Me.Close()
        Else
            Me.UpdateSeriesFormats()
            Me.DialogResult = DialogResult.OK
            Me.Hide()
        End If

    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    'SJS 04-30-15 ADDED FROM DECOMPILED VERSION
    Private Sub UpdateSeriesFormats()
        Dim enumerator As IEnumerator = Nothing
        Dim num As Integer = 0
        Try
            enumerator = Me.SeriesArray.GetEnumerator()
            While enumerator.MoveNext()
                Dim current As SeriesFormatInfo = DirectCast(enumerator.Current, SeriesFormatInfo)
                Dim item As ExcelChartSeriesEditor = DirectCast(Me.SeriesEditControlArray(num), ExcelChartSeriesEditor)
                current.LineColor = item.btnColor.MyColor
                current.LineDashStyle = item.GetLineStyle
                current.LineWeight = Convert.ToDouble(item.nudLineWeight.Value)
                num = num + 1
            End While
            'SJS 04-30-15 THIS PORTION HAS ERRORS, SO I COMMENTED IT OUT, NOT SURE WHAT ALL THIS CODE DOES
            'Finally
            '    If (TypeOf enumerator Is IDisposable) Then
            '            TryCast(enumerator, IDisposable)).Dispose()
            '    End If
        Catch ex As Exception

        End Try
    End Sub

    'SJS 04-30-15 ADDED FROM DECOMPILED CODE, NEED TO USE C# FOR DECOMPILE
    Public Sub PopulateControlSeriesOnly(ByVal NumSeries As Integer)
        'Throw New NotImplementedException
        Me.UpdateChartOnOkClick = False
        Dim count As Integer = 0

        If Me.SeriesArray Is Nothing Then
            Me.SeriesArray = New ArrayList
            Me.SeriesEditControlArray = New ArrayList
        Else
            count = Me.SeriesArray.Count
        End If

        For i As Integer = count + 1 To NumSeries
            Dim SerFormat As New SeriesFormatInfo()
            Me.SeriesArray.Add(SerFormat)
            SerFormat.Name = "Series " + i.ToString
            SerFormat.PlotOrder = i


            Dim ExChartSerEdit As New ExcelChartSeriesEditor(SerFormat, Me.DefaultButtonColorArray, Me.ClrDiag)
            Me.SeriesEditControlArray.Add(ExChartSerEdit)
            Me.FlowLayoutPanel1.Controls.Add(ExChartSerEdit)
        Next


    End Sub



End Class
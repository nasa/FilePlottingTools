﻿Imports System.Windows.Forms

Public MustInherit Class GenericFileInfo
    Protected Friend Namep As String 'name of file
    Protected Friend Indexp As Integer = -1 '0 based index in the file manager list (order of the file)
    Protected Friend RowStartp As Integer = 27 'Formatted data sheet row that contains the first line of the file
    Protected Friend RowEndp As Integer = -1 'formatted data sheet row that contains the last line of the file
    Protected Friend ColStartp As Integer = 1 'formatted data sheet column that contains the first column in the file
    Protected Friend ColEndp As Integer = -1 'formatted data sheet column number that contains the last column in the file
    Protected Friend NumColsp As Integer = -1 'number of columns in the file
    Protected Friend NumRowsp As Integer = -1 'number of rows in the file
    Protected Friend FormattedSheetHeaderRow As Integer = 26 'Hardcoded header row in the formatted sheet, can access through property HeaderRow
    Protected Friend shtDataSheet As Excel.Worksheet
    Protected Friend shtImport As Excel.Worksheet 'this is the imported data sheet, need to rename everywhere
    Protected Friend shtFormatted As Excel.Worksheet

    Protected Friend DataSheetManager As DataSheetClass

    Public MustOverride Sub ReadFileIntoClipBoard()
    Public MustOverride Sub UpdateDataSheet()
    'Public MustOverride Sub UpdateDataForGroup()


    Public ReadOnly Property FolderAndFileNameOnly As String
        Get
            Dim SlashIndex As Integer
            Dim SecondSlash As Boolean = False
            For i As Integer = Me.Namep.Count - 1 To 0 Step -1

                If Me.Namep(i) = "\" And SecondSlash Then
                    SlashIndex = i
                    Exit For
                ElseIf Me.Namep(i) = "\" Then
                    SecondSlash = True
                End If
            Next

            FolderAndFileNameOnly = Me.Namep.Substring(SlashIndex + 1)

        End Get
    End Property

    Public ReadOnly Property FileNameOnly
        Get
            Dim LastSlashIndex As Integer = Me.Namep.LastIndexOf("\")

            Return Me.Namep.Substring(LastSlashIndex + 1)
        End Get
    End Property

    Public Sub ChangeRowAndColStarts(ByVal RowStart As Integer, ByVal ColStart As Integer)
        If Me.NumRowsp = -1 Or Me.NumColsp = -1 Then
            MessageBox.Show("ERROR from TEXTFILEINFO.ChangeRowAndColStarts(), numcolumns or numrows not specified.  Nothing updated.")
        Else
            Me.RowStartp = RowStart
            Me.ColStartp = ColStart

            Me.RowEndp = RowStart + NumRowsp - 1
            Me.ColEndp = ColStart + NumColsp - 1
        End If

    End Sub

    Protected Friend Sub ClearGroupRow()
        'dangerous hard code
        shtDataSheet.Range(shtDataSheet.Cells(10 + Me.Indexp, 4), shtDataSheet.Cells(10 + Me.Indexp, 3000)).Clear()

    End Sub

    Public ReadOnly Property NumberOfSeries As Integer
        Get
            Return ColEndp - ColStartp
        End Get
    End Property

    Public ReadOnly Property Name As String
        Get
            Return Me.Namep
        End Get
    End Property

    Public ReadOnly Property Index As Integer
        Get
            Return Me.Indexp
        End Get
    End Property

    Public ReadOnly Property RowStart As Integer
        Get
            Return Me.RowStartp
        End Get
    End Property

    Public ReadOnly Property RowEnd As Integer
        Get
            Return Me.RowEndp
        End Get
    End Property

    Public ReadOnly Property ColStart As Integer
        Get
            Return Me.ColStartp
        End Get
    End Property

    Public ReadOnly Property ColEnd As Integer
        Get
            Return Me.ColEndp
        End Get
    End Property

    Public ReadOnly Property NumRows As Integer
        Get
            Return Me.NumRowsp
        End Get
    End Property

    Public ReadOnly Property NumCols As Integer
        Get
            Return Me.NumColsp
        End Get
    End Property

    Public ReadOnly Property HeaderRowNumber As Integer
        Get
            Return FormattedSheetHeaderRow
        End Get
    End Property

    Public ReadOnly Property TimeColumn As Integer
        Get
            Return ColStart
        End Get
    End Property

    Public ReadOnly Property FirstSeriesColumn As Integer
        Get
            Return ColStart + 1
        End Get
    End Property

    Public ReadOnly Property LastSeriesColumn As Integer
        Get
            Return RowEnd
        End Get
    End Property

End Class

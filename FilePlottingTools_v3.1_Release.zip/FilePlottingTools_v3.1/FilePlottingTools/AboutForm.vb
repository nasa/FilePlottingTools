﻿Imports System.Diagnostics

Public Class AboutForm
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()
        Me.AutoScaleMode = Windows.Forms.AutoScaleMode.Dpi
        '
        '.Text = UsefulFunctions.GetVersionString
        lblVersion.Text = "3.1"

        ' Add any initialization after the InitializeComponent() call.

    End Sub

    Private Sub btnClose_Click(sender As System.Object, e As System.EventArgs) Handles btnClose.Click
        Me.DialogResult = Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub LinkLabel2_Click(sender As Object, e As EventArgs) Handles LinkLabel2.Click
        Process.Start("http://fileplottingtools.larc.nasa.gov")
    End Sub
End Class
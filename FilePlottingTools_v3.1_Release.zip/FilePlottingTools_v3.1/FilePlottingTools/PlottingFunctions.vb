﻿Imports System.Drawing
Imports System.Windows.Forms

Module PlottingFunctions
    Public Enum LegendLocation
        top
        right
    End Enum
    'Private ThisWorkbook As Excel.Workbook = Globals.ThisAddIn.Application.ActiveWorkbook

    Public Function CreateNewChartFromTemplate(ByVal NewChartName As String, ByRef TemplateChart As Excel.Chart, ByRef ThisWorkbook As Excel.Workbook) As Excel.Chart
        Dim NumberOfSheets = ThisWorkbook.Sheets.Count
        TemplateChart.Copy(, ThisWorkbook.Sheets.Item(NumberOfSheets))

        NumberOfSheets += 1

        Dim NewChart As Excel.Chart
        NewChart = ThisWorkbook.Sheets.Item(NumberOfSheets)

        NewChart.Name = NewChartName

        Return NewChart
    End Function

    Public Sub AddPlotSeriesCollectionToChart(ByRef NewChart As Excel.Chart, ByRef DataSheet As Excel.Worksheet, SeriesInfo As PlotSeriesInfoCollection)

        For i As Integer = 0 To SeriesInfo.Count - 1
            AddPlotSeriesToChart(NewChart, DataSheet, SeriesInfo.Item(i))
        Next

        NewChart.Activate()

        If NewChart.HasTitle Then
            NewChart.ChartTitle.Text = ""
        End If
        NewChart.ChartType = Excel.XlChartType.xlXYScatterLinesNoMarkers
        NewChart.Legend.Width = 560

    End Sub

    Public Sub AddLimitsToChart(ByRef chart As Excel.Chart, ByRef DataSheet As Excel.Worksheet, ByRef limitlist As PlotLimitInfoCollection, ByRef ThisWorkBook As Excel.Workbook)
        Try


            Dim NumSeries As Integer = chart.SeriesCollection.count + 1
            Dim NumLegendEnties As Integer = 1

            For Each legendentry As Object In chart.Legend.LegendEntries
                NumLegendEnties += 1
            Next



            For Each limit As PlotLimitInfo In limitlist

                'CreateChartLimits2(chart, DataSheet, "test", limit.TimeCol, limit.TimeRow1, limit.TimeRow2, limit.LimitCol, limit.LimitRow, limit.LimitRow)
                Dim XcolLetter As String = GetExcelColumnName(limit.TimeCol)
                Dim YcolLetter As String = GetExcelColumnName(limit.LimitCol)

                Dim t_SerCol As Excel.SeriesCollection = chart.SeriesCollection

                Dim t_Series As Excel.Series = t_SerCol.NewSeries
                t_Series.XValues = "=('" + DataSheet.Name + "'!$" + XcolLetter + "$" + limit.TimeRow1.ToString + ",'" + DataSheet.Name + "'!$" + XcolLetter + "$" + limit.TimeRow2.ToString + ")"
                t_Series.Values = "=('" + DataSheet.Name + "'!$" + YcolLetter + "$" + limit.LimitRow.ToString + ",'" + DataSheet.Name + "'!$" + YcolLetter + "$" + limit.LimitRow.ToString + ")"

                t_Series.Name = "Limit"
                t_Series.Border.Color = RGB(255, 0, 0)
                t_Series.MarkerStyle = Excel.XlMarkerStyle.xlMarkerStyleNone
                t_Series.Border.LineStyle = Excel.XlLineStyle.xlDash



                chart.Legend.LegendEntries(NumLegendEnties).Delete()
            Next
        Catch ex As Exception

        End Try
    End Sub

    Public Sub AddPlotSeriesToChart(ByRef Chart As Excel.Chart, ByRef DataSheet As Excel.Worksheet, ByRef SeriesInfo As PlotSeriesInfo)

        Dim t_SerCol As Excel.SeriesCollection = Chart.SeriesCollection
        Dim t_Series As Excel.Series = t_SerCol.NewSeries

        't_Series.PlotOrder = t_SerCol.Count

        t_Series.XValues = DataSheet.Range(DataSheet.Cells(SeriesInfo.RowStart, SeriesInfo.TimeColumn), DataSheet.Cells(SeriesInfo.RowEnd, SeriesInfo.TimeColumn))
        t_Series.Values = DataSheet.Range(DataSheet.Cells(SeriesInfo.RowStart, SeriesInfo.ValuesColumn), DataSheet.Cells(SeriesInfo.RowEnd, SeriesInfo.ValuesColumn))
        t_Series.Name = SeriesInfo.SeriesNameAddress(DataSheet)

    End Sub

    Public Function GetExcelColumnName(ByVal columnNumber As Integer) As String

        Dim dividend As Integer = columnNumber
        Dim columnName As String = String.Empty
        Dim modulo As Integer = 0

        While dividend > 0

            modulo = (dividend - 1) Mod 26
            columnName = Convert.ToChar(65 + modulo).ToString() + columnName
            dividend = CType(((dividend - modulo) / 26), Integer)

        End While

        Return columnName
    End Function

    Public Sub AddDashedGrayGridLines(ByRef aChart As Excel.Chart)
        Dim Xaxis As Excel.Axis = aChart.Axes(Excel.XlAxisType.xlCategory)
        Dim Yaxis As Excel.Axis = aChart.Axes(Excel.XlAxisType.xlValue)

        Xaxis.HasMajorGridlines = True
        Xaxis.MajorGridlines.Border.Color = Color.Gray.ToArgb
        Xaxis.MajorGridlines.Border.LineStyle = Excel.XlLineStyle.xlDot

        Yaxis.HasMajorGridlines = True
        Yaxis.MajorGridlines.Border.Color = Color.Gray.ToArgb
        Yaxis.MajorGridlines.Border.LineStyle = Excel.XlLineStyle.xlDot

    End Sub

    Public Sub TickMarksInside(ByRef aChart As Excel.Chart)
        Dim Xaxis As Excel.Axis = aChart.Axes(Excel.XlAxisType.xlCategory)
        Dim Yaxis As Excel.Axis = aChart.Axes(Excel.XlAxisType.xlValue)

        Xaxis.MajorTickMark = Excel.XlTickMark.xlTickMarkInside
        Yaxis.MajorTickMark = Excel.XlTickMark.xlTickMarkInside

    End Sub

    Public Sub ChangeChartGlobalFontSize(ByRef aChart As Excel.Chart, ByVal FontSize As Integer)
        aChart.ChartArea.Font.Size = FontSize
    End Sub

    Public Sub AddXAxisLabel(ByRef aChart As Excel.Chart, ByVal label As String)
        Dim Xaxis As Excel.Axis = aChart.Axes(Excel.XlAxisType.xlCategory)
        Xaxis.HasTitle = True
        Xaxis.AxisTitle.Text = label

    End Sub

    Public Sub AddYAxisLabel(ByRef aChart As Excel.Chart, ByVal label As String)
        Dim Yaxis As Excel.Axis = aChart.Axes(Excel.XlAxisType.xlValue)
        Yaxis.HasTitle = True
        Yaxis.AxisTitle.Text = label
    End Sub

    Public Sub ChangePlotAreaSize(ByRef aChart As Excel.Chart, ByVal width As Integer, height As Integer)
        aChart.PlotArea.Width = width
        aChart.PlotArea.Height = height
    End Sub

    Public Sub MovePlotAreaDown(ByRef aChart As Excel.Chart, ByVal NumPixels As Integer)
        aChart.PlotArea.Top = aChart.PlotArea.Top + NumPixels
    End Sub

    Public Sub MovePlotAreaRight(ByRef aChart As Excel.Chart, ByVal NumPixels As Integer)
        aChart.PlotArea.Left = aChart.PlotArea.Left + NumPixels
    End Sub

    Public Sub MoveXaxisLabelDown(ByRef aChart As Excel.Chart, ByVal NumPixels As Integer)
        Dim Xaxis As Excel.Axis = aChart.Axes(Excel.XlAxisType.xlCategory)
        Xaxis.AxisTitle.Top = Xaxis.AxisTitle.Top + NumPixels
    End Sub

    Public Sub MoveYaxisLabelLeft(ByRef aChart As Excel.Chart, ByVal NumPixels As Integer)
        Dim Yaxis As Excel.Axis = aChart.Axes(Excel.XlAxisType.xlValue)
        Yaxis.AxisTitle.Left = Yaxis.AxisTitle.Left - NumPixels
    End Sub

    Public Sub SetLegendPositionAndSize(ByRef aChart As Excel.Chart, ByVal Top As Double, ByVal Left As Double, ByVal Width As Double, ByVal Height As Double)
        'NOTE:  YOU MUST CHANGE WITDH AND HEIGHT BEFORE TOP AND LEFT
        'SET TOP AND LEFT TO 0 FIRST, THEN CHANGE WIDTH/HEIGHT, THEN MOVE
        'IF YOU DON'T, YOU MAY NOT BE ABLE TO CHANGE LEFT/TOP IF THE BOX SIZE IS TOO BIG
        aChart.Legend.Top = 0
        aChart.Legend.Left = 0
        aChart.Legend.Width = Width
        aChart.Legend.Height = Height

        aChart.Legend.Top = Top
        aChart.Legend.Left = Left

    End Sub

    Public Sub SetPlotAreaPositionAndSize(ByRef aChart As Excel.Chart, ByVal Top As Double, ByVal Left As Double, ByVal Width As Double, ByVal Height As Double)
        'NOTE:  YOU MUST CHANGE WITDH AND HEIGHT BEFORE TOP AND LEFT
        'SET TOP AND LEFT TO 0 FIRST, THEN CHANGE WIDTH/HEIGHT, THEN MOVE
        'IF YOU DON'T, YOU MAY NOT BE ABLE TO CHANGE LEFT/TOP IF THE BOX SIZE IS TOO BIG
        aChart.PlotArea.Top = 0
        aChart.PlotArea.Left = 0
        aChart.PlotArea.Width = Width
        aChart.PlotArea.Height = Height

        aChart.PlotArea.Top = Top
        aChart.PlotArea.Left = Left

    End Sub

    Public Sub XaxisCrossesAt(ByRef aChart As Excel.Chart, ByVal Yvalue As Double)
        Dim Yaxis As Excel.Axis = aChart.Axes(Excel.XlAxisType.xlValue)
        Yaxis.CrossesAt = Yvalue
    End Sub

    Public Sub YaxisCrossesAt(ByRef aChart As Excel.Chart, ByVal Xvalue As Double)
        Dim Xaxis As Excel.Axis = aChart.Axes(Excel.XlAxisType.xlCategory)
        Xaxis.CrossesAt = Xvalue
    End Sub

    Public Sub YaxisNumberFormat(ByRef aChart As Excel.Chart, ByVal NumDecimals As Integer)
        Dim Yaxis As Excel.Axis = aChart.Axes(Excel.XlAxisType.xlValue)
        Yaxis.TickLabels.NumberFormat = GetNumberFormatString(NumDecimals)
    End Sub

    Public Sub XaxisNumberFormat(ByRef aChart As Excel.Chart, ByVal NumDecimals As Integer)
        Dim Xaxis As Excel.Axis = aChart.Axes(Excel.XlAxisType.xlCategory)
        Xaxis.TickLabels.NumberFormat = GetNumberFormatString(NumDecimals)
    End Sub

    Public Function GetNumberFormatString(ByVal NumDigits As Integer) As String
        Dim FormatString As String = "0"
        If NumDigits > 0 Then
            FormatString += "."
            For i As Integer = 1 To NumDigits
                FormatString += "0"
            Next
        End If
        Return FormatString
    End Function

    Public Sub ChangeSeriesRanges(ByRef aChart As Excel.Chart, ByRef aWorkBook As Excel.Workbook)

        Dim dataSheet As Excel.Worksheet

        For Each chart_series As Excel.Series In aChart.SeriesCollection


            'SJS 10-15-15
            'added the front part of the if statement so that only series that are
            'linked to the formatted data sheet get updated. Users may have other charts that are linked elsewhere,
            'so those should not be updated.  In addition, it removes the problem associated with 
            'the datasheets having a comma in the name when parsing the forumla string.  See ChartSeriesModifier.

            'had to replace the commented line with the line below, split formulation doesn't work
            'Dim numFormattedDataStrings As Integer = chart_series.Formula.Split("Formatted Data").Length - 1
            Dim containsFormattedDataString As Boolean = chart_series.Formula.Contains("Formatted Data")

            'SJS 10-15-15
            'modified if statement for new boolean contains funciton
            'If chart_series.Formula.Contains("Formatted Data") = False Then
            If containsFormattedDataString = False Then
                'do nothing, this series is not linked to the formatted data sheet
                'note, this test fails if the series name is linked to formatted, and only x or y is linked to 
                'formatted
            ElseIf String.Compare(chart_series.Name, "LIMIT", True) = 0 Then

                Dim OldFormula As String = chart_series.Formula
                Dim thisPlotSeries As New ChartSeriesModifier(OldFormula, True)
                dataSheet = UsefulFunctions.GetWorkSheetByName(thisPlotSeries.SheetName, aWorkBook)
                Dim NewLastRow As Integer = UsefulFunctions.GetLastRowNumberWithData(dataSheet, 27, thisPlotSeries.ColumnLetter)

                If NewLastRow = 27 Then
                    'the file was deleted, or column removed.  the data for this series no longer exists
                Else
                    thisPlotSeries.ChangeLastCellInXvalues(NewLastRow)
                    'MessageBox.Show(thisPlotSeries.Xvalues)
                    chart_series.XValues = thisPlotSeries.XvaluesReference
                End If

            Else

                Dim OldFormula As String = chart_series.Formula
                Dim thisPlotSeries As New ChartSeriesModifier(OldFormula, False)

                dataSheet = UsefulFunctions.GetWorkSheetByName(thisPlotSeries.SheetName, aWorkBook)
                Dim x1 As Excel.Range = dataSheet.Range(thisPlotSeries.XRangeString)
                Dim x2 As Excel.Range = UsefulFunctions.ExpandRangeToLastRow(x1)

                Dim y1 As Excel.Range = dataSheet.Range(thisPlotSeries.YRangeString)
                Dim y2 As Excel.Range = UsefulFunctions.ExpandRangeToLastRow(y1)

                'SJS 07-15-15
                'this if statement was incorect, fixed it
                If x2 Is Nothing Or y2 Is Nothing Then
                    'the file was deleted, or column removed.  Don't change the range
                    chart_series.XValues = x1
                    chart_series.Values = y1
                Else
                    chart_series.XValues = x2
                    chart_series.Values = y2
                End If

            End If

        Next

    End Sub
    Public Function UpdateChartRangeVersion(ByVal theChart As Excel.Chart) As String
        Dim updatedFormula As String = ""

        For Each chart_series As Excel.Series In theChart.SeriesCollection
            ' Call SplitFormattedDataValues
            Dim formula As String
            Dim splitValues() As String

            formula = chart_series.Formula
            splitValues = SplitFormattedDataValues(formula)

            If Not splitValues Is Nothing Then
                updatedFormula = String.Join("Formatted Data", splitValues)
                chart_series.Formula = updatedFormula
            Else
                ' No 'Formatted Data' found in the formula
            End If
        Next

        Return updatedFormula
    End Function

    Public Function SplitFormattedDataValues(ByVal formula As String) As String()
        Dim containsFormattedDataString As Boolean = formula.Contains("Formatted Data")

        If containsFormattedDataString Then
            Dim splitValues As String() = formula.Split(New String() {"Formatted Data"}, StringSplitOptions.None)

            ' Increment the numeric value that comes after the "Formatted Data" substring by 7
            For i = 1 To UBound(splitValues)
                Dim match As System.Text.RegularExpressions.Match
                match = System.Text.RegularExpressions.Regex.Match(splitValues(i), "(\d+)")
                If match.Success Then
                    Dim value As Integer = Integer.Parse(match.Value) + 7
                    splitValues(i) = System.Text.RegularExpressions.Regex.Replace(splitValues(i), "(\d+)", value.ToString())
                End If
            Next i

            Return splitValues
        Else
            Return Nothing
        End If
    End Function

    Public Sub ArrangeChartArea(ByRef aChart As Excel.Chart, ByVal loc As LegendLocation, ByVal TopMargin As Double, ByVal LegendWidthOrHeight As Double)
        Dim ChartTop As Double
        Dim ChartLeft As Double = 55 'always the same
        Dim ChartWidth As Double
        Dim ChartHeight As Double
        Dim LegendTop As Double
        Dim LegendLeft As Double
        Dim LegendWidth As Double
        Dim LegendHeight As Double

        If loc = LegendLocation.top Then
            LegendTop = TopMargin
            LegendLeft = 96
            LegendHeight = LegendWidthOrHeight
            LegendWidth = 565

            ChartTop = TopMargin + LegendHeight
            ChartHeight = aChart.ChartArea.Height - TopMargin - LegendHeight - 40
            ChartWidth = 620

        ElseIf loc = LegendLocation.right Then
            LegendWidth = LegendWidthOrHeight
            LegendLeft = aChart.ChartArea.Width - LegendWidth - 5
            ChartTop = TopMargin
            ChartHeight = aChart.ChartArea.Height - TopMargin - 50


            ChartWidth = 620 - LegendWidth - 5
            LegendTop = TopMargin
            'LegendLeft = ChartLeft + ChartWidth + 5

            LegendHeight = aChart.ChartArea.Height - TopMargin - 50



        End If
        PlottingFunctions.SetPlotAreaPositionAndSize(aChart, ChartTop, ChartLeft, ChartWidth, ChartHeight)
        PlottingFunctions.SetLegendPositionAndSize(aChart, LegendTop, LegendLeft, LegendWidth, LegendHeight)
    End Sub

    'Public Sub SetLegendLocation(ByRef aChart As Excel.Chart, ByVal loc As LegendLocation, Optional ByVal HasTitle As Boolean = False, Optional ByVal WidthLegend As Double = 100, Optional ByVal HeightLegend As Double = 62)
    '    Dim TopChart As Double
    '    Dim LeftChart As Double
    '    Dim WidthChart As Double
    '    Dim HeightChart As Double
    '    Dim TopLegend As Double
    '    Dim LeftLegend As Double
    '    'Dim WidthLegend As Double
    '    'Dim HeightLegend As Double

    '    If loc = LegendLocation.top Then

    '        TopLegend = 3
    '        LeftLegend = 96
    '        WidthLegend = 565
    '        'HeightLegend = 62

    '        TopChart = 57
    '        LeftChart = 55
    '        WidthChart = 620

    '        'default top legend height is 62
    '        HeightChart = 400 - (HeightLegend - 62)

    '        If HasTitle Then

    '            Dim MoveDown As Double = 50
    '            TopChart += MoveDown
    '            HeightChart -= MoveDown
    '            TopLegend += MoveDown

    '        End If

    '    ElseIf loc = LegendLocation.right Then
    '        TopChart = 0
    '        TopLegend = 10

    '        LeftChart = 52
    '        LeftLegend = 0
    '        WidthChart = aChart.ChartArea.Width - WidthLegend
    '        LeftLegend = LeftChart + WidthChart - 5

    '        'LeftLegend = aChart.PlotArea.Left + aChart.PlotArea.Width - 5

    '        'WidthLegend = aChart.ChartArea.Width - aChart.PlotArea.Width - aChart.PlotArea.Left - 5
    '        'WidthLegend = aChart.ChartArea.Width - WidthChart - LeftChart - 5
    '        'WidthLegend = 100
    '        HeightLegend = 410
    '        HeightChart = 450

    '        'WidthChart = 500




    '        If HasTitle Then

    '            Dim MoveDown As Double = 50
    '            TopChart += MoveDown
    '            HeightChart -= MoveDown
    '            TopLegend += MoveDown
    '            HeightLegend += MoveDown

    '        End If

    '    End If

    '    PlottingFunctions.SetPlotAreaPositionAndSize(aChart, TopChart, LeftChart, WidthChart, HeightChart)
    '    PlottingFunctions.SetLegendPositionAndSize(aChart, TopLegend, LeftLegend, WidthLegend, HeightLegend)
    'End Sub

    Public Sub YAxisMinorTicks(ByRef aChart As Excel.Chart, ByVal MinorTicks As Boolean)
        Dim Yaxis As Excel.Axis = aChart.Axes(Excel.XlAxisType.xlValue)
        If MinorTicks Then
            Yaxis.MinorTickMark = Excel.XlTickMark.xlTickMarkInside
        Else
            Yaxis.MinorTickMark = Excel.XlTickMark.xlTickMarkNone
        End If

    End Sub

    Public Sub XAxisMinorTicks(ByRef aChart As Excel.Chart, ByVal MinorTicks As Boolean)
        Dim Xaxis As Excel.Axis = aChart.Axes(Excel.XlAxisType.xlCategory)
        If MinorTicks Then
            Xaxis.MinorTickMark = Excel.XlTickMark.xlTickMarkInside
        Else
            Xaxis.MinorTickMark = Excel.XlTickMark.xlTickMarkNone
        End If

    End Sub

    'Public Sub CreateChartSeries(ByRef Chart As Excel.Chart, ByRef DataSheet As Excel.Worksheet, ByVal Xcol As Integer, Ycol As Integer, ByVal RowStart As Integer, ByVal RowEnd As Integer)

    '    Dim t_SerCol As Excel.SeriesCollection = Chart.SeriesCollection

    '    Dim t_Series As Excel.Series = t_SerCol.NewSeries
    '    t_Series.XValues = DataSheet.Range(DataSheet.Cells(RowStart, Xcol), DataSheet.Cells(RowEnd, Xcol))
    '    t_Series.Values = DataSheet.Range(DataSheet.Cells(RowStart, Ycol), DataSheet.Cells(RowEnd, Ycol))
    '    Dim NameString = "='" + DataSheet.Name + "'!$"
    '    Dim NameCellAddress = DataSheet.Cells(RowStart - 1, Ycol).Address.ToString

    '    For i As Integer = 1 To NameCellAddress.Count - 1
    '        If NameCellAddress(i) = "$" Then
    '            NameString += NameCellAddress(i)
    '            Exit For
    '        Else
    '            NameString += NameCellAddress(i)
    '        End If
    '    Next

    '    NameString += (RowStart - 1).ToString
    '    t_Series.Name = NameString

    'End Sub

    'Public Sub CreateChartLimits(ByRef Chart As Excel.Chart, ByRef sheet As Excel.Worksheet, ByVal LimitName As String, ByVal Xcol As Integer, ByVal Xrow1 As Integer, ByVal Xrow2 As Integer, Ycol As Integer, ByVal Yrow1 As Integer, ByVal Yrow2 As Integer)

    '    Dim xtest(1) As Excel.Range
    '    xtest(0) = sheet.Cells(Xrow1, Xcol)
    '    xtest(1) = sheet.Cells(Xrow2, Xcol)

    '    Dim ytest(1) As Excel.Range
    '    ytest(0) = sheet.Cells(Yrow1, Ycol)
    '    ytest(1) = sheet.Cells(Yrow2, Ycol)

    '    Dim t_SerCol As Excel.SeriesCollection = Chart.SeriesCollection

    '    Dim t_Series As Excel.Series = t_SerCol.NewSeries
    '    t_Series.XValues = xtest
    '    t_Series.Values = ytest

    '    t_Series.Name = LimitName
    '    t_Series.Border.Color = RGB(255, 0, 0)
    '    t_Series.MarkerStyle = Excel.XlMarkerStyle.xlMarkerStyleNone
    '    t_Series.Border.LineStyle = Excel.XlLineStyle.xlDash

    'End Sub

    'Public Sub CreateChartLimits2(ByRef Chart As Excel.Chart, ByRef DataSheet As Excel.Worksheet, ByVal LimitName As String, ByVal Xcol As Integer, ByVal Xrow1 As Integer, ByVal Xrow2 As Integer, Ycol As Integer, ByVal Yrow1 As Integer, ByVal Yrow2 As Integer)

    '    Dim XcolLetter As String = GetExcelColumnName(Xcol)
    '    Dim YcolLetter As String = GetExcelColumnName(Ycol)

    '    Dim t_SerCol As Excel.SeriesCollection = Chart.SeriesCollection

    '    Dim t_Series As Excel.Series = t_SerCol.NewSeries
    '    t_Series.XValues = "=('" + DataSheet.Name + "'!$" + XcolLetter + "$" + Xrow1.ToString + ",'" + DataSheet.Name + "'!$" + XcolLetter + "$" + Xrow2.ToString + ")"
    '    t_Series.Values = "=('" + DataSheet.Name + "'!$" + YcolLetter + "$" + Yrow1.ToString + ",'" + DataSheet.Name + "'!$" + YcolLetter + "$" + Yrow2.ToString + ")"

    '    t_Series.Name = LimitName
    '    t_Series.Border.Color = RGB(255, 0, 0)
    '    t_Series.MarkerStyle = Excel.XlMarkerStyle.xlMarkerStyleNone
    '    t_Series.Border.LineStyle = Excel.XlLineStyle.xlDash

    'End Sub

    'Public Sub GenerateChart(ByVal chtName As String)
    '    Dim IndexFormatted As Integer = ThisWorkbook.Sheets.Count

    '    ThisWorkbook.Sheets(2).Copy(, ThisWorkbook.Sheets(IndexFormatted))

    '    Dim IndexNewChart = ThisWorkbook.Sheets.Count
    '    Dim NewChart As Excel.Chart = ThisWorkbook.Sheets(IndexNewChart)

    '    NewChart.Name = chtName

    '    For i As Integer = 2 To 3
    '        CreateChartSeries(NewChart, ThisWorkbook.Sheets(IndexFormatted), 1, i, FirstDataRowNumber)
    '    Next

    '    NewChart.Activate()

    '    If NewChart.HasTitle Then
    '        NewChart.ChartTitle.Text = ""
    '    End If

    'End Sub

    'Public Sub CreateChartSeries(ByRef Chart As Excel.Chart, ByRef sheet As Excel.Worksheet, ByRef Xrange As Excel.Range, ByRef Yrange As Excel.Range, ByRef Legend As Excel.Range)

    'SJS 05-07-15 THIS IS THE SAME FUNCTION AS WORKBOOKMANAGER.CREATETEMPLATECHART.
    'MODIFIED TO MAKE WORK HERE
    'MOVED HERE SO CHARTS COULD BE CREATED WITHOUT A TEMPLATE
    'WILL MAKE THINGS SIMPLER

    Public Function CreateTemplateChart(ByVal sheetname As String, ByRef ThisWorkbook As Excel.Workbook, ByVal shtFormatted As String) As Excel.Chart

        'SJS 05-08-15 FOR SOME REASON, WHEN YOU CREATE A NEW PLOT, IT AUTOMATICALLY POPULATES
        'IT WITH DATA ON THE ACTIVE WORKSHEET.  THIS CODE CREATES A BLANKWORKSHEET SO THE
        'CHARTS ARE BLANK ON CREATION
        Dim TempBlankWorkBook As Excel.Worksheet = ThisWorkbook.Worksheets.Add()
        TempBlankWorkBook.Name = "TempBlnkWkSht195"

        Dim NewChart As Excel.Chart = ThisWorkbook.Charts.Add()
        Dim NumberOfSheets = ThisWorkbook.Sheets.Count
        NewChart.Move(, ThisWorkbook.Sheets(NumberOfSheets))
        NewChart.Name = sheetname

        NewChart.ChartType = Excel.XlChartType.xlXYScatterLinesNoMarkers
        PlottingFunctions.AddDashedGrayGridLines(NewChart)
        PlottingFunctions.ChangeChartGlobalFontSize(NewChart, 18)
        PlottingFunctions.TickMarksInside(NewChart)

        'SJS TODO 05-07-15 CONSIDER MOVING THIS SOMEWHERE ELSE TO MAKE THIS NEW PLOT GENERIC
        PlottingFunctions.AddXAxisLabel(NewChart, "='" + shtFormatted + "'!$E$2")
        PlottingFunctions.AddYAxisLabel(NewChart, "='" + shtFormatted + "'!$E$3")



        'PlottingFunctions.ChangePlotAreaSize(NewChart, 620, 400)
        'PlottingFunctions.MovePlotAreaDown(NewChart, 50)
        'PlottingFunctions.MovePlotAreaRight(NewChart, 45)
        PlottingFunctions.MoveYaxisLabelLeft(NewChart, 20)
        PlottingFunctions.MoveXaxisLabelDown(NewChart, 7)
        PlottingFunctions.SetLegendPositionAndSize(NewChart, 3, 90, 565, 62)
        PlottingFunctions.XaxisCrossesAt(NewChart, -1000)
        PlottingFunctions.XaxisNumberFormat(NewChart, 0)
        PlottingFunctions.YaxisNumberFormat(NewChart, 0)
        PlottingFunctions.YAxisMinorTicks(NewChart, True)
        PlottingFunctions.XAxisMinorTicks(NewChart, True)

        'SJS 05/01/2017: 
        'These two function calls used to be below the ADDxy label calls above,
        'but for some reason excel 2016 throws an exception if they are there
        'moving below the other calls fixes the issue
        PlottingFunctions.SetPlotAreaPositionAndSize(NewChart, 57, 55, 620, 400)
        PlottingFunctions.SetLegendPositionAndSize(NewChart, 3, 96, 565, 62)

        'SJS 05-07-15 DELETING SERIES IS NOT NEEDED WITH THE TEMPORARY BLANK
        'WORKSHEET CREATION
        'For Each series As Excel.Series In NewChart.SeriesCollection
        '    series.Delete()
        'Next

        'SJS 05-08-15 DELETE THE TEMPORARY BLANK WORKSHEET
        'NEED TO DISABLE THE ALERTS, OTHERWISE EXCEL ASKS YOU IF YOUR SURE YOU WANT TO DELETE
        ThisWorkbook.Application.DisplayAlerts = False
        TempBlankWorkBook.Delete()
        ThisWorkbook.Application.DisplayAlerts = True


        ''NewChart.Visible = Excel.XlSheetVisibility.xlSheetVeryHidden
        Return NewChart
    End Function

    'SJS 05-08-15 MOVED FROM WORKBOOK MANAGER TO HERE
    'DON'T NEED A WORKBOOK MANAGER TO FORMAT PLOTS
    'THIS WILL ALLOW USE OF PLOT MANAGER EVEN IF YOUR NOT USING 
    'FILEPLOTTING TOOLS AT ALL
    Public Sub FormatPlots()

        Dim PlotManager As New ChartEditor
        PlotManager.StartPosition = FormStartPosition.Manual
        Dim LocPoint As Point = PointsToPixelsAsPoint(Globals.ThisAddIn.Application.Left, Globals.ThisAddIn.Application.Top)
        LocPoint.Offset(40, 40)

        PlotManager.Location = LocPoint
        PlotManager.Focus()

        'SJS 05-08-15 MODIFIED THIS TO BE SHOW ONLY SO THAT APPLY BUTTON WILL FUNCTION
        'THIS IS NICE ALSO BECAUSE YOU CAN SWITCH BETWEEN PLOTS WHILE THE FORM IS OPEN 
        'TO CHECK EACH ONE TO SEE IF YOU LIKE WHAT YOU DID.
        'If PlotManager.ShowDialog = DialogResult.OK Then

        'End If

        PlotManager.Show()
        PlotManager.TopMost = True
    End Sub
End Module

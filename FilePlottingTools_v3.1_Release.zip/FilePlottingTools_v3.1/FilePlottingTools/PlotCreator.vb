﻿Imports System.Collections
Imports System.Windows.Forms

Public Class PlotCreator
    Private TextFileList As TextFileCollection
    Public PlotName As String

    Private SelectorCollection As New ArrayList
    Private FlowLayoutPanel1 As SplitterPanel
    Private LastFileIndex As Integer = 0

    Public ChartSeriesCollections As New ArrayList
    Public ChartLimitCollections As New ArrayList
    Public ThisWorkbook As Excel.Workbook = Globals.ThisAddIn.Application.ActiveWorkbook
    Private shtDataSheet As Excel.Worksheet

    Enum ChartType
        Custom = 0
        Multi = 1
        Compare = 2
    End Enum

    Private TypeOfChart As New ChartType

    Private Sub New()

        ' This call is required by the designer.
        InitializeComponent()
        Me.AutoScaleMode = Windows.Forms.AutoScaleMode.Dpi

        ' Add any initialization after the InitializeComponent() call.
        Me.FlowLayoutPanel1 = SplitContainer03.Panel2
        txtPlotName.Text = "NewPlot"
        Me.PlotName = txtPlotName.Text
        CheckForDuplicatNames()

    End Sub

    Public Sub New(ByRef Filelist As TextFileCollection, ByRef DataSheet As Excel.Worksheet)
        Me.New()
        Me.TextFileList = Filelist
        Me.shtDataSheet = DataSheet
        SplitContainer002.Visible = False
        Dim PlotType As String = shtDataSheet.Cells(11, 2).value.ToString

        If PlotType = "S" Then
            btnPlotCompare.Enabled = False
            btnPlotForEachFile.Enabled = False
            btnCustomPlot.Enabled = False
            PlotForEachFileUpdateControl()
            txtDescription.Text = "Select series to plot."
        End If
    End Sub

    Private Sub btnCustomPlot_Click(sender As System.Object, e As System.EventArgs) Handles btnCustomPlot.Click
        CustomButtonUpdateControl()
    End Sub

    Private Sub CustomButtonUpdateControl()
        TypeOfChart = ChartType.Custom
        SplitContainer002.Visible = True
        SplitContainer03.Panel1Collapsed = False
        FileListBox.Enabled = True
        FileListBox.CheckOnClick = False
        ClearContainers()
        PopulateFiles()
        txtDescription.Text = "Make a single plot.  Can select any series or any limit from any file.  Select a file in the list, then select the series you want to add.  Repeat for other files/series."
    End Sub

    Private Sub btnPlotForEachFile_Click(sender As System.Object, e As System.EventArgs) Handles btnPlotForEachFile.Click
        PlotForEachFileUpdateControl()
    End Sub

    Private Sub PlotForEachFileUpdateControl()
        TypeOfChart = ChartType.Multi
        SplitContainer002.Visible = True
        SplitContainer03.Panel1Collapsed = True
        FileListBox.Enabled = False
        FileListBox.CheckOnClick = False
        ClearContainers()

        Dim sall As New SeriesAndLimitList(TextFileList.Item(0))
        Me.SelectorCollection.Add(sall)

        FlowLayoutPanel1.Controls.Add(sall)
        sall.Dock = DockStyle.Fill
        Me.ActiveControl = sall
        txtDescription.Text = "Make a plot for each text file, based on the selected series below.  Only works if all files have the same number of series."
    End Sub

    Private Sub btnPlotCompare_Click(sender As System.Object, e As System.EventArgs) Handles btnPlotCompare.Click
        TypeOfChart = ChartType.Compare
        SplitContainer002.Visible = True
        SplitContainer03.Panel1Collapsed = False
        FileListBox.Enabled = True
        FileListBox.CheckOnClick = True
        ClearContainers()

        Dim sall As New SeriesAndLimitList(TextFileList.Item(0))
        SelectorCollection.Add(sall)

        FlowLayoutPanel1.Controls.Add(sall)
        sall.Dock = DockStyle.Fill
        PopulateFiles()
        txtDescription.Text = "Make a comparison plot between files.  Check the files you want to compare, then select the series to be plotted.  Only works if all files have the same number of series."
    End Sub

    Private Sub PopulateFiles()

        For Each textfile As TextFileInfo In Me.TextFileList
            FileListBox.Items.Add(textfile.FolderAndFileNameOnly)
            Dim sall As New SeriesAndLimitList(textfile)
            'sall.Dock = DockStyle.Fill
            SelectorCollection.Add(sall)
        Next
        FileListBox.SelectedIndex = 0

    End Sub

    Private Sub ClearContainers()
        FileListBox.Items.Clear()
        FlowLayoutPanel1.Controls.Clear()
        SelectorCollection.Clear()
        LastFileIndex = 0
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub btnOk_Click(sender As System.Object, e As System.EventArgs) Handles btnOk.Click
        'SJS 05-01-15 DIDN'T COMPARE TO DECOMPILED CODE, IT WAS TOO MODIFIED
        If SelectorCollection.Count = 0 Then
            MessageBox.Show("No chart type selected.  Select chart type, or cancel.")
            Exit Sub
        End If

        Me.PlotName = txtPlotName.Text

        If TypeOfChart = ChartType.Custom Then
            Dim SeriesList As New PlotSeriesInfoCollection
            Dim LimitList As New PlotLimitInfoCollection
            For i As Integer = 0 To TextFileList.Count - 1
                Dim textfile As TextFileInfo = TextFileList.Item(i)
                Dim CountSeries As Integer = 0
                For Each SeriesControl As SeriesAndLimitSelector In CType(SelectorCollection(i), SeriesAndLimitList).GetSeriesControls
                    If SeriesControl.chkPlot.Checked = True Then
                        Dim plotseries As New PlotSeriesInfo(textfile.TimeColumn, textfile.FirstSeriesColumn + CountSeries, textfile.RowStart, textfile.RowEnd)
                        SeriesList.Add(plotseries)
                    End If
                    If SeriesControl.chkHS.Checked = True Then
                        Dim limitseries As New PlotLimitInfo(textfile.TimeColumn, textfile.RowStart, textfile.RowEnd, textfile.FirstSeriesColumn + CountSeries, 10)
                        LimitList.Add(limitseries)
                    End If

                    If SeriesControl.chkHO.Checked = True Then
                        Dim limitseries As New PlotLimitInfo(textfile.TimeColumn, textfile.RowStart, textfile.RowEnd, textfile.FirstSeriesColumn + CountSeries, 11)
                        LimitList.Add(limitseries)
                    End If

                    If SeriesControl.chkCO.Checked = True Then
                        Dim limitseries As New PlotLimitInfo(textfile.TimeColumn, textfile.RowStart, textfile.RowEnd, textfile.FirstSeriesColumn + CountSeries, 12)
                        LimitList.Add(limitseries)
                    End If
                    If SeriesControl.chkCS.Checked = True Then
                        Dim limitseries As New PlotLimitInfo(textfile.TimeColumn, textfile.RowStart, textfile.RowEnd, textfile.FirstSeriesColumn + CountSeries, 13)
                        LimitList.Add(limitseries)
                    End If

                    CountSeries += 1
                Next
            Next
            ChartSeriesCollections.Add(SeriesList)
            ChartLimitCollections.Add(LimitList)
        ElseIf TypeOfChart = ChartType.Multi Then

            For i As Integer = 0 To TextFileList.Count - 1
                Dim SeriesList As New PlotSeriesInfoCollection
                Dim LimitList As New PlotLimitInfoCollection
                Dim textfile As TextFileInfo = TextFileList.Item(i)
                Dim CountSeries As Integer = 0
                For Each SeriesControl As SeriesAndLimitSelector In CType(SelectorCollection(0), SeriesAndLimitList).GetSeriesControls
                    If SeriesControl.chkPlot.Checked = True Then
                        Dim plotseries As New PlotSeriesInfo(textfile.TimeColumn, textfile.FirstSeriesColumn + CountSeries, textfile.RowStart, textfile.RowEnd)
                        SeriesList.Add(plotseries)
                    End If
                    If SeriesControl.chkHS.Checked = True Then
                        Dim limitseries As New PlotLimitInfo(textfile.TimeColumn, textfile.RowStart, textfile.RowEnd, textfile.FirstSeriesColumn + CountSeries, 10)
                        LimitList.Add(limitseries)
                    End If

                    If SeriesControl.chkHO.Checked = True Then
                        Dim limitseries As New PlotLimitInfo(textfile.TimeColumn, textfile.RowStart, textfile.RowEnd, textfile.FirstSeriesColumn + CountSeries, 11)
                        LimitList.Add(limitseries)
                    End If

                    If SeriesControl.chkCO.Checked = True Then
                        Dim limitseries As New PlotLimitInfo(textfile.TimeColumn, textfile.RowStart, textfile.RowEnd, textfile.FirstSeriesColumn + CountSeries, 12)
                        LimitList.Add(limitseries)
                    End If
                    If SeriesControl.chkCS.Checked = True Then
                        Dim limitseries As New PlotLimitInfo(textfile.TimeColumn, textfile.RowStart, textfile.RowEnd, textfile.FirstSeriesColumn + CountSeries, 13)
                        LimitList.Add(limitseries)
                    End If

                    CountSeries += 1
                Next

                ChartSeriesCollections.Add(SeriesList)
                ChartLimitCollections.Add(LimitList)
            Next
        ElseIf TypeOfChart = ChartType.Compare Then
            If FileListBox.CheckedIndices.Count = 0 Then
                MessageBox.Show("Select at least two files to compare.")
                Exit Sub
            Else
                For Each i As Integer In FileListBox.CheckedIndices
                    Dim SeriesList As New PlotSeriesInfoCollection
                    Dim LimitList As New PlotLimitInfoCollection
                    Dim textfile As TextFileInfo = TextFileList.Item(i)
                    Dim CountSeries As Integer = 0
                    For Each SeriesControl As SeriesAndLimitSelector In CType(SelectorCollection(0), SeriesAndLimitList).GetSeriesControls
                        If SeriesControl.chkPlot.Checked = True Then
                            Dim plotseries As New PlotSeriesInfo(textfile.TimeColumn, textfile.FirstSeriesColumn + CountSeries, textfile.RowStart, textfile.RowEnd, textfile.FileNameOnly, True)
                            SeriesList.Add(plotseries)
                        End If
                        If SeriesControl.chkHS.Checked = True Then
                            Dim limitseries As New PlotLimitInfo(textfile.TimeColumn, textfile.RowStart, textfile.RowEnd, textfile.FirstSeriesColumn + CountSeries, 10)
                            LimitList.Add(limitseries)
                        End If

                        If SeriesControl.chkHO.Checked = True Then
                            Dim limitseries As New PlotLimitInfo(textfile.TimeColumn, textfile.RowStart, textfile.RowEnd, textfile.FirstSeriesColumn + CountSeries, 11)
                            LimitList.Add(limitseries)
                        End If

                        If SeriesControl.chkCO.Checked = True Then
                            Dim limitseries As New PlotLimitInfo(textfile.TimeColumn, textfile.RowStart, textfile.RowEnd, textfile.FirstSeriesColumn + CountSeries, 12)
                            LimitList.Add(limitseries)
                        End If
                        If SeriesControl.chkCS.Checked = True Then
                            Dim limitseries As New PlotLimitInfo(textfile.TimeColumn, textfile.RowStart, textfile.RowEnd, textfile.FirstSeriesColumn + CountSeries, 13)
                            LimitList.Add(limitseries)
                        End If

                        CountSeries += 1
                    Next

                    ChartSeriesCollections.Add(SeriesList)
                    ChartLimitCollections.Add(LimitList)
                Next
            End If

        End If

        
        If IsAnythingSelected() Then
            Me.DialogResult = Windows.Forms.DialogResult.OK
            Me.Close()
        Else
            MessageBox.Show("No series selected for plotting.  Select at least one series, or cancel")
            'SJS 05-07-15 ADDED THIS TO CLEAR THE SERIES ARRAYS TO AVOID 
            'BLANK CHART CREATION BUG
            ChartSeriesCollections.Clear()
            ChartLimitCollections.Clear()
        End If


    End Sub

    Private Sub PlotCreator_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
        'For Each SelectControl As SeriesAndLimitList In FlowLayoutPanel1.Controls
        '    SelectControl.Width = FlowLayoutPanel1.Width
        'Next
    End Sub

    Private Sub ListBox1_ItemCheck(sender As Object, e As System.Windows.Forms.ItemCheckEventArgs) Handles FileListBox.ItemCheck
        'Dim selectionlist As SeriesAndLimitList = SelectorCollection(ListBox1.SelectedIndex)
        'If selectionlist.HasSelections Then
        '    ListBox1.SetItemCheckState(ListBox1.SelectedIndex, CheckState.Checked)
        'Else
        '    ListBox1.SetItemCheckState(ListBox1.SelectedIndex, CheckState.Unchecked)
        'End If
    End Sub

    Private Sub ListBox1_SelectedIndexChanged1(sender As Object, e As System.EventArgs) Handles FileListBox.SelectedIndexChanged
        If Me.TypeOfChart = ChartType.Compare Then
            'do nothing
        Else
            Dim selectionlist As SeriesAndLimitList = SelectorCollection(FileListBox.SelectedIndex)
            UpdateChecksOnFileList()
            FlowLayoutPanel1.Controls.Add(selectionlist)
            selectionlist.Dock = DockStyle.Fill
            LastFileIndex = FileListBox.SelectedIndex
        End If


    End Sub

    Private Sub UpdateChecksOnFileList()
        For i As Integer = 0 To FlowLayoutPanel1.Controls.Count - 1
            If CType(FlowLayoutPanel1.Controls(i), SeriesAndLimitList).HasSelections Then
                FileListBox.SetItemCheckState(LastFileIndex, CheckState.Checked)
            Else
                FileListBox.SetItemCheckState(LastFileIndex, CheckState.Unchecked)
            End If
            FlowLayoutPanel1.Controls.RemoveAt(i)
        Next
    End Sub

    Public Sub CheckForDuplicatNames()
        Dim increment As Integer = 1

        While IsDuplicateName(txtPlotName.Text)
            Dim CurrentNumber As String = String.Empty
            If txtPlotName.Text.Last = ")" Then
                Dim index = txtPlotName.Text.LastIndexOf("(")
                For i As Integer = index + 1 To txtPlotName.Text.Count - 2
                    CurrentNumber += txtPlotName.Text(i)
                Next
                increment = CType(CurrentNumber, Integer) + 1
                txtPlotName.Text = txtPlotName.Text.Remove(index)

            End If
            txtPlotName.Text = txtPlotName.Text + "(" + increment.ToString() + ")"
            Me.PlotName = txtPlotName.Text
            increment += 1
        End While
    End Sub

    Private Function IsDuplicateName(ByVal Name As String) As Boolean

        Dim FoundDuplicate = False

        For i As Integer = 1 To ThisWorkbook.Sheets.Count()
            If ThisWorkbook.Sheets.Item(i).Name = Name Then

                FoundDuplicate = True
                Exit For

            End If
        Next

        Return FoundDuplicate
    End Function

    Private Sub btnCustomPlot_MouseHover(sender As Object, e As System.EventArgs) Handles btnCustomPlot.MouseHover
        'ToolTipCustomButton.Show(
    End Sub

    Public ReadOnly Property GetTypeOfChart As ChartType
        Get
            Return TypeOfChart
        End Get
    End Property

    Private Function IsAnythingSelected() As Boolean
        Dim NumSeries As Integer = 0
        'Dim NumLimits As Integer = 0

        For Each Collection As PlotSeriesInfoCollection In ChartSeriesCollections
            If Collection.Count = 0 Then
            Else
                NumSeries = 1
                Exit For
            End If
        Next

        If NumSeries = 0 Then
            Return False
        Else
            Return True
        End If

    End Function

    'SJS 04-30-15 ADDED TO CREATE A PLOT AUTOMATICALLY
    Public Sub DebugAutoPlot(ByVal NumSeries As Integer)
        Dim SeriesList As New PlotSeriesInfoCollection
        Dim LimitList As New PlotLimitInfoCollection
        For i As Integer = 0 To TextFileList.Count - 1
            Dim textfile As TextFileInfo = TextFileList.Item(i)
            Dim CountSeries As Integer = 0

            Dim sall As New SeriesAndLimitList(TextFileList.Item(i))
            Me.SelectorCollection.Add(sall)

            For Each SeriesControl As SeriesAndLimitSelector In CType(SelectorCollection(i), SeriesAndLimitList).GetSeriesControls
                'If SeriesControl.chkPlot.Checked = True Then
                Dim plotseries As New PlotSeriesInfo(textfile.TimeColumn, textfile.FirstSeriesColumn + CountSeries, textfile.RowStart, textfile.RowEnd)
                SeriesList.Add(plotseries)
                'End If
                'If SeriesControl.chkHS.Checked = True Then
                '    Dim limitseries As New PlotLimitInfo(textfile.TimeColumn, textfile.RowStart, textfile.RowEnd, textfile.FirstSeriesColumn + CountSeries, 10)
                '    LimitList.Add(limitseries)
                'End If

                'If SeriesControl.chkHO.Checked = True Then
                '    Dim limitseries As New PlotLimitInfo(textfile.TimeColumn, textfile.RowStart, textfile.RowEnd, textfile.FirstSeriesColumn + CountSeries, 11)
                '    LimitList.Add(limitseries)
                'End If

                'If SeriesControl.chkCO.Checked = True Then
                '    Dim limitseries As New PlotLimitInfo(textfile.TimeColumn, textfile.RowStart, textfile.RowEnd, textfile.FirstSeriesColumn + CountSeries, 12)
                '    LimitList.Add(limitseries)
                'End If
                'If SeriesControl.chkCS.Checked = True Then
                '    Dim limitseries As New PlotLimitInfo(textfile.TimeColumn, textfile.RowStart, textfile.RowEnd, textfile.FirstSeriesColumn + CountSeries, 13)
                '    LimitList.Add(limitseries)
                'End If

                CountSeries += 1
                If CountSeries = NumSeries Then
                    Exit For
                End If
            Next
        Next
        ChartSeriesCollections.Add(SeriesList)
        ChartLimitCollections.Add(LimitList)
    End Sub
End Class
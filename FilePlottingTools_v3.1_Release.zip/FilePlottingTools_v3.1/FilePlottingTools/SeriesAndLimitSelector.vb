﻿Imports System.Windows.Forms

Public Class SeriesAndLimitSelector

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()
        Me.AutoScaleMode = Windows.Forms.AutoScaleMode.Dpi
        ' Add any initialization after the InitializeComponent() call.

    End Sub

    Public Sub New(ByVal SeriesName As String)
        Me.New()
        chkPlot.Text = SeriesName
    End Sub
    Public Function LimitsAreSelected() As Boolean
        If chkCO.CheckState = CheckState.Checked Or chkCS.CheckState = CheckState.Checked Or chkHO.CheckState = CheckState.Checked Or chkHS.CheckState = CheckState.Checked Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Function PlotHotSurvLimit() As Boolean
        If chkHS.CheckState = CheckState.Checked Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Function PlotHotOpLimit() As Boolean
        If chkHO.CheckState = CheckState.Checked Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Function PlotColdSurvLimit() As Boolean
        If chkCS.CheckState = CheckState.Checked Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Function PlotColdOpLimit() As Boolean
        If chkCO.CheckState = CheckState.Checked Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Sub ModifyMargin(ByVal ContainerWidth As Integer)

        Me.Margin = New Padding(Margin.Left, Margin.Top, ContainerWidth - Me.Right - 40, Margin.Bottom)

    End Sub
End Class

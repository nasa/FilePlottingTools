﻿Imports System.Collections
Imports System.IO
Imports System.Windows.Forms


Public Class FileGroupManager
    Private GroupTypeVal As String = "C"
    Public WorksheetName As String
    Private Delimiter As String
    Public IsSavFilePlot As Boolean = False

    Private shtDataSheet As Excel.Worksheet
    'SJS 05-11-15 ADDED TO INCORPORATE DATASHEETMANAGER
    Public DataSheetManager As DataSheetClass

    'SJS 05-01-15 ADDED BACK FROM DECOMPILED CODE
    Public DisableSavFileRead As Boolean
    'SJS 05-01-15 ADDED OPTIONAL INPUT BACK FROM DECOMPILED CODE
    Public Enum StitchType
        FileTimesInOrder = 0
        FilesStartAt0 = 1
    End Enum

    Public Sub New(ByRef DataSheet As Excel.Worksheet, Optional ByVal DisableSavFileRead As Boolean = False)

        ' This call is required by the designer.
        InitializeComponent()
        Me.AutoScaleMode = Windows.Forms.AutoScaleMode.Dpi

        ' Add any initialization after the InitializeComponent() call.
        Me.shtDataSheet = DataSheet
        'SJS 05-11-15 ADDED TO INCORPORATE DATASHEETMANAGER
        Me.DataSheetManager = New DataSheetClass(CType(Me.shtDataSheet, Excel.Worksheet))


        'SJS 05-01-15 ADDED BACK FROM DECOMPILED CODE
        Me.DisableSavFileRead = DisableSavFileRead
    End Sub

    'SJS 05-11-15 ADDED TO INCORPORATE DATASHEETMANAGER
    Public Sub New(ByRef DataSheetManager As DataSheetClass, Optional ByVal DisableSavFileRead As Boolean = False)

        ' This call is required by the designer.
        InitializeComponent()
        Me.AutoScaleMode = Windows.Forms.AutoScaleMode.Dpi
        ' Add any initialization after the InitializeComponent() call.
        Me.DataSheetManager = DataSheetManager
        shtDataSheet = Me.DataSheetManager.TheDataSheet

        'SJS 05-01-15 ADDED BACK FROM DECOMPILED CODE
        Me.DisableSavFileRead = DisableSavFileRead
        Me.LoadFilesAndSettingsFromDataSheet()
    End Sub

    Public Property GroupType As String
        Get
            Return GroupTypeVal
        End Get
        Set(value As String)
            GroupTypeVal = value
            If value = "C" Then
                radCompare.Checked = True
            Else
                radStitch.Checked = True
            End If
        End Set
    End Property

    Public Property DelimiterType As String
        Get
            Return Me.Delimiter
        End Get
        Set(value As String)
            Me.Delimiter = value
            If value = vbTab Then
                rdbTab.Checked = True
            ElseIf value = " " Then
                rdbSpace.Checked = True
            ElseIf value = "," Then
                rdbComma.Checked = True
            Else
                rdbOther.Checked = True
                txtOther.Text = value
            End If
        End Set
    End Property

    Private Sub lstFiles_DragDrop(sender As Object, e As System.Windows.Forms.DragEventArgs) Handles lstFiles.DragDrop
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            Dim MyFiles As New ArrayList
            Dim MyDirectories As New ArrayList
            ' Assign the files to an array.

            Dim DropedItems() As String

            DropedItems = e.Data.GetData(DataFormats.FileDrop)

            'Dim listItems As ArrayList
            For i = 0 To DropedItems.Length - 1
                If Directory.Exists(DropedItems(i)) Then
                    MyDirectories.Add(DropedItems(i))
                Else
                    MyFiles.Add(DropedItems(i))
                End If
            Next

            If MyDirectories.Count > 0 Then
                'SJS 05-01-15 ADDED THE ME.DISABLESAVFILEREAD BELOW
                Dim DirFileSelect As New GetFileTypeFromFolders(Me.DisableSavFileRead)
                DirFileSelect.StartPosition = FormStartPosition.Manual
                DirFileSelect.Location = New Drawing.Point(Me.Location.X + 20, Me.Location.Y + 20)
                DirFileSelect.Focus()
                Me.TopMost = True
                DirFileSelect.TopMost = True
                If DirFileSelect.ShowDialog = Windows.Forms.DialogResult.OK Then
                    For Each dir As String In MyDirectories
                        Dim DirInfo As New DirectoryInfo(dir)
                        Dim FileList As FileInfo() = DirInfo.GetFiles()

                        For Each File As FileInfo In FileList
                            If File.Extension = DirFileSelect.SelectedFilter Then
                                Dim a As New ListViewItem
                                a.Text = File.FullName
                                lstFiles.Items.Add(a)
                            End If
                        Next
                    Next

                End If
            End If
            Me.TopMost = False
            Me.Focus()


            If MyFiles.Count > 0 Then
                ' Loop through the array and add the files to the list.
                For Each File As String In MyFiles
                    Dim a As New ListViewItem
                    a.Text = File
                    lstFiles.Items.Add(a)
                Next
            End If



        End If
        VerifySavOrTextOnly()

    End Sub

    Private Sub lstFiles_DragEnter(sender As Object, e As System.Windows.Forms.DragEventArgs) Handles lstFiles.DragEnter
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            e.Effect = DragDropEffects.All
        Else
            e.Effect = DragDropEffects.None
        End If
    End Sub

    Private Sub btnOk_Click(sender As System.Object, e As System.EventArgs) Handles btnOk.Click

        If Me.lstFiles.Items.Count = 0 Then
            MessageBox.Show("No files, please add files")
            Exit Sub
        Else
            'sjs 07-15-2015
            'check to make sure files exists
            For Each plotfile As ListViewItem In Me.lstFiles.Items
                If FileExists(plotfile.Text) = False Then
                    MessageBox.Show("The file:" + vbNewLine + vbNewLine + plotfile.Text + vbNewLine + vbNewLine + " does not exist.  Remove this file from list, or cancel.")
                    Exit Sub
                End If
            Next
        End If

        If radCompare.Checked = True Then
            Me.GroupTypeVal = "C"
        ElseIf radStitch.Checked Then
            Me.GroupTypeVal = "S"
        Else
            MessageBox.Show("Error, no radio buttons checked")
            Exit Sub
        End If

        If rdbComma.Checked = True Then
            Me.Delimiter = ","
        ElseIf rdbSpace.Checked = True Then
            Me.Delimiter = " "
        ElseIf rdbTab.Checked = True Then
            Me.Delimiter = vbTab
        ElseIf rdbOther.Checked = True Then
            If txtOther.Text = String.Empty Then
                MessageBox.Show("Error, must specify other delimiter in text box")
                Exit Sub
            Else
                Me.Delimiter = txtOther.Text
            End If
        Else
            MessageBox.Show("Error, no radio buttons checked")
            Exit Sub
        End If

        Me.DataSheetManager.ClearDataSheet()
        Me.DataSheetManager.CellCompareOrStich.Value = GroupType

        'SJS 05-08-15 ADD STITCHOPTION IDENTIFIER ABOVE THE GROUPTYPE CELL
        Me.DataSheetManager.CellTypeOfStitch.Value = Me.StitchOption.ToString
        Me.DataSheetManager.CellDelimiter.Value = Delimiter


        Dim FileList() As String = GetFileNames()
        Dim Count As Integer = 0
        For Each file As String In FileList

            Me.DataSheetManager.CellFirstFileName.Offset(Count).Value = file
            Count += 1
        Next
        '04/16/2017 SJS: probably don't need this verify function; this is done when you add files
        VerifySavOrTextOnly()
        Me.DialogResult = Windows.Forms.DialogResult.OK

        Me.Close()


    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Public Function GetFileNames() As String()
        Dim NumFiles As Integer = lstFiles.Items.Count

        If NumFiles = 0 Then
            Dim FileList(1) As String
            Return FileList
        Else
            Dim FileList(NumFiles) As String


            For i As Integer = 0 To NumFiles - 1
                FileList(i) = lstFiles.Items(i).Text


            Next
            Return FileList
        End If


    End Function

    'Private Sub ClearDataSheet()
    '    'SJS TODO 05-01-15 CHECK THE RANGE OF THE CLEAR, SHOULD BE FINE BUT ITS
    '    'NOT THE WHOLE SHEET
    '    shtDataSheet.Range("B10:C30000").Clear()

    'End Sub

    Public Sub LoadFilesAndSettingsFromDataSheet()

        Dim NumFiles As Integer = Me.DataSheetManager.CellNumberOfFiles.Value
        If NumFiles = 0 Then
            Exit Sub
        Else
            'SJS 05-11-15 ADDED TO INCORPORATE DATASHEETMANAGER
            Me.GroupType = Me.DataSheetManager.CellCompareOrStich.Value.ToString
            Me.DelimiterType = Me.DataSheetManager.CellDelimiter.Value.ToString


            If Me.DataSheetManager.CellTypeOfStitch.Value.ToString = [Enum].GetName(GetType(StitchType), StitchType.FileTimesInOrder) Then
                radFileTimesInOrder.Checked = True
            ElseIf Me.DataSheetManager.CellTypeOfStitch.Value.ToString = [Enum].GetName(GetType(StitchType), StitchType.FilesStartAt0) Then
                radAllFilesStartTime0.Checked = True
            End If

            For i As Integer = 0 To Me.DataSheetManager.CellNumberOfFiles.Value - 1
                Me.lstFiles.Items.Add(Me.DataSheetManager.CellFirstFileName.Offset(i).Value.ToString)
                If lstFiles.Items(lstFiles.Items.Count - 1).Text.Substring(lstFiles.Items(lstFiles.Items.Count - 1).Text.Count - 4) = ".sav" Then
                    Me.grpDelimiters.Enabled = False
                End If
            Next

        End If

    End Sub

    Private Sub lstFiles_KeyUp(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles lstFiles.KeyUp

        If lstFiles.SelectedIndices.Count = 0 Then
        Else

            If e.KeyCode = Keys.Delete Then
                For Each i As ListViewItem In lstFiles.SelectedItems
                    lstFiles.Items.Remove(i)
                Next

            ElseIf e.KeyCode = Keys.Add Then
                UsefulFunctions.MoveItemsInListView(lstFiles, True)
            ElseIf e.KeyCode = Keys.Subtract Then
                UsefulFunctions.MoveItemsInListView(lstFiles, False)

            End If

        End If
    End Sub

    Private Sub VerifySavOrTextOnly()
        'SJS 05-01-15 ADDED FIRST IF STATEMENT BACK FROM DECOMPILED CODE
        If Me.DisableSavFileRead = False Then
            Dim SavIndexList As New ArrayList
            Dim TextIndexList As New ArrayList
            For i As Integer = 0 To lstFiles.Items.Count - 1
                If lstFiles.Items(i).Text.Substring(lstFiles.Items(i).Text.Count - 4) = ".sav" Then
                    SavIndexList.Add(i)
                Else
                    TextIndexList.Add(i)
                End If
            Next
            If SavIndexList.Count > 0 And TextIndexList.Count > 0 Then
                MessageBox.Show("You have selected files of type .sav, and text files.  All Text files will be removed")
                Me.IsSavFilePlot = True
                'need to go through list from largest indext to smallest, and remove non-sav files
                For i As Integer = TextIndexList.Count - 1 To 0 Step -1
                    lstFiles.Items.RemoveAt(TextIndexList.Item(i))
                Next
            ElseIf SavIndexList.Count > 0 Then
                Me.IsSavFilePlot = True
            ElseIf TextIndexList.Count > 0 Then
                Me.IsSavFilePlot = False
            End If

            If Me.IsSavFilePlot Then
                grpDelimiters.Enabled = False
            Else
                grpDelimiters.Enabled = True
            End If
        End If


    End Sub


    Private Sub FileGroupManager_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
        lstFiles.Columns(0).Width = Me.Width - 20
    End Sub

    Private Sub radStitch_CheckedChanged(sender As Object, e As EventArgs) Handles radStitch.CheckedChanged
        'enable or disable the stitch options depending on whether stitch radio
        'button is checked or not
        If radStitch.Checked Then
            grpStitchOptions.Enabled = True
        Else
            grpStitchOptions.Enabled = False
        End If
    End Sub

    Public ReadOnly Property StitchOption As StitchType
        Get
            If radFileTimesInOrder.Checked Then
                Return StitchType.FileTimesInOrder
            ElseIf radAllFilesStartTime0.Checked Then
                Return StitchType.FilesStartAt0
            Else
                Return StitchType.FileTimesInOrder
            End If
        End Get

    End Property
End Class
﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SavFileImport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SplitContainer02 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer002 = New System.Windows.Forms.SplitContainer()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.SplitContainer03 = New System.Windows.Forms.SplitContainer()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ListBox1 = New System.Windows.Forms.CheckedListBox()
        Me.SplitContainer01 = New System.Windows.Forms.SplitContainer()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOk = New System.Windows.Forms.Button()
        CType(Me.SplitContainer02, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer02.Panel2.SuspendLayout()
        Me.SplitContainer02.SuspendLayout()
        CType(Me.SplitContainer002, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer002.Panel1.SuspendLayout()
        Me.SplitContainer002.Panel2.SuspendLayout()
        Me.SplitContainer002.SuspendLayout()
        CType(Me.SplitContainer03, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer03.Panel1.SuspendLayout()
        Me.SplitContainer03.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.SplitContainer01, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer01.Panel1.SuspendLayout()
        Me.SplitContainer01.Panel2.SuspendLayout()
        Me.SplitContainer01.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer02
        '
        Me.SplitContainer02.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer02.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer02.IsSplitterFixed = True
        Me.SplitContainer02.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer02.Name = "SplitContainer02"
        '
        'SplitContainer02.Panel1
        '
        Me.SplitContainer02.Panel1.BackColor = System.Drawing.SystemColors.Control
        Me.SplitContainer02.Panel1Collapsed = True
        '
        'SplitContainer02.Panel2
        '
        Me.SplitContainer02.Panel2.Controls.Add(Me.SplitContainer002)
        Me.SplitContainer02.Size = New System.Drawing.Size(503, 423)
        Me.SplitContainer02.SplitterDistance = 138
        Me.SplitContainer02.TabIndex = 3
        '
        'SplitContainer002
        '
        Me.SplitContainer002.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer002.IsSplitterFixed = True
        Me.SplitContainer002.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer002.Name = "SplitContainer002"
        Me.SplitContainer002.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer002.Panel1
        '
        Me.SplitContainer002.Panel1.Controls.Add(Me.txtDescription)
        '
        'SplitContainer002.Panel2
        '
        Me.SplitContainer002.Panel2.Controls.Add(Me.SplitContainer03)
        Me.SplitContainer002.Size = New System.Drawing.Size(503, 423)
        Me.SplitContainer002.SplitterDistance = 54
        Me.SplitContainer002.TabIndex = 4
        '
        'txtDescription
        '
        Me.txtDescription.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtDescription.Enabled = False
        Me.txtDescription.Location = New System.Drawing.Point(0, 0)
        Me.txtDescription.Multiline = True
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(503, 54)
        Me.txtDescription.TabIndex = 0
        Me.txtDescription.Text = "Select all Nodes and Registers to Plot"
        '
        'SplitContainer03
        '
        Me.SplitContainer03.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer03.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer03.IsSplitterFixed = True
        Me.SplitContainer03.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer03.Name = "SplitContainer03"
        Me.SplitContainer03.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer03.Panel1
        '
        Me.SplitContainer03.Panel1.Controls.Add(Me.GroupBox1)
        Me.SplitContainer03.Size = New System.Drawing.Size(503, 365)
        Me.SplitContainer03.SplitterDistance = 215
        Me.SplitContainer03.TabIndex = 3
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ListBox1)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(503, 215)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Submodel List"
        '
        'ListBox1
        '
        Me.ListBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(3, 16)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(497, 196)
        Me.ListBox1.TabIndex = 2
        '
        'SplitContainer01
        '
        Me.SplitContainer01.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer01.FixedPanel = System.Windows.Forms.FixedPanel.Panel2
        Me.SplitContainer01.IsSplitterFixed = True
        Me.SplitContainer01.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer01.Name = "SplitContainer01"
        Me.SplitContainer01.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer01.Panel1
        '
        Me.SplitContainer01.Panel1.Controls.Add(Me.SplitContainer02)
        '
        'SplitContainer01.Panel2
        '
        Me.SplitContainer01.Panel2.Controls.Add(Me.TableLayoutPanel1)
        Me.SplitContainer01.Size = New System.Drawing.Size(503, 475)
        Me.SplitContainer01.SplitterDistance = 423
        Me.SplitContainer01.TabIndex = 5
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 3
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.btnCancel, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.btnOk, 1, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(503, 48)
        Me.TableLayoutPanel1.TabIndex = 5
        '
        'btnCancel
        '
        Me.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnCancel.Location = New System.Drawing.Point(420, 12)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 23)
        Me.btnCancel.TabIndex = 3
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnOk
        '
        Me.btnOk.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnOk.Location = New System.Drawing.Point(330, 12)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.Size = New System.Drawing.Size(75, 23)
        Me.btnOk.TabIndex = 4
        Me.btnOk.Text = "Ok"
        Me.btnOk.UseVisualStyleBackColor = True
        '
        'SavFileImport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(503, 475)
        Me.Controls.Add(Me.SplitContainer01)
        Me.Name = "SavFileImport"
        Me.Text = "SavFileImport"
        Me.SplitContainer02.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer02, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer02.ResumeLayout(False)
        Me.SplitContainer002.Panel1.ResumeLayout(False)
        Me.SplitContainer002.Panel1.PerformLayout()
        Me.SplitContainer002.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer002, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer002.ResumeLayout(False)
        Me.SplitContainer03.Panel1.ResumeLayout(False)
        CType(Me.SplitContainer03, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer03.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.SplitContainer01.Panel1.ResumeLayout(False)
        Me.SplitContainer01.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer01, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer01.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer02 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer002 As System.Windows.Forms.SplitContainer
    Friend WithEvents txtDescription As System.Windows.Forms.TextBox
    Friend WithEvents SplitContainer03 As System.Windows.Forms.SplitContainer
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents ListBox1 As System.Windows.Forms.CheckedListBox
    Friend WithEvents SplitContainer01 As System.Windows.Forms.SplitContainer
    Friend WithEvents btnOk As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
End Class

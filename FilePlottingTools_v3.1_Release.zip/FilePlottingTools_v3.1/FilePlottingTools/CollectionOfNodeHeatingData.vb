﻿Public Class CollectionOfNodeHeatingData
    Inherits Collections.CollectionBase

    Public Sub Add(ByVal NodeHeatData As NodeHeatingData)
        Me.List.Add(NodeHeatData)
    End Sub

    Public Sub Remove(ByVal NodeHeatData As NodeHeatingData)
        Me.List.Remove(NodeHeatData)
    End Sub

    Public Property Item(ByVal index As Integer) As NodeHeatingData
        Get
            Return CType(Me.List.Item(index), NodeHeatingData)
        End Get
        Set(ByVal value As NodeHeatingData)
            Me.List.Item(index) = value
        End Set
    End Property
End Class

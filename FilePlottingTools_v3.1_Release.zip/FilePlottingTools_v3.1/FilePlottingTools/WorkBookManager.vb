﻿Imports System.Windows.Forms
Imports System.Collections
Imports System.Drawing
Imports System.Windows.Markup.Primitives

Public Class WorkBookManager
    Private NameOfDataSheet As String
    Private NameOfImportSheet As String
    Private NameOfFormattedSheet As String = "Formatted Data"
    Private ThisWorkbook As Excel.Workbook
    Public shtDataSheet As Excel.Worksheet
    Public shtFormatted As Excel.Worksheet
    Public shtImport As New Excel.Worksheet
    Public FirstDataRowNumber As Integer = 27
    Public FileNameRowNumber As Integer = 7
    Private Cell_IsSavFile As Excel.Range
    Public RefreshOnOpen As Boolean = False
    Private DebugMode As Boolean = False
    Private FormattedShtReferenceCell As Excel.Range
    Private FormattedShtReferenceCellstr As String = "A" + FirstDataRowNumber.ToString

    Public DataSheetManager As DataSheetClass

    'there is some kind of bug with Excel 2007, where the conditional format statement pushes ahead one column.  If you type =B$8, you get =C$8 when it applies
    'use this to move one back from where you want, need way to check 
    'FOR 2010:  USE B
    'FOR 2007:  USE A
    Dim ConditionalFormatStartColLetter As String = "B"

    'FPT1.1
    Private DisableSavFileRead As Boolean

    Public Enum PlotType As Integer
        Compare = 0
        Stitch = 1
    End Enum

    Public Sub New(ByRef CurrentWorkbook As Excel.Workbook, ByVal NameOfDataSheet As String, ByVal NameOfImportSheet As String, Optional ByVal Debug As Boolean = False)

        PrepareWorkbook(CurrentWorkbook, NameOfDataSheet, NameOfImportSheet)
        UpdateWorkbookVersion(CType(Me.DataSheetManager.CellFilePlotterVersion.Value, Double), CType(UsefulFunctions.GetVersionString, Double))


            If Debug Then
            Me.DebugMode = True
            Me.shtDataSheet.Visible = Excel.XlSheetVisibility.xlSheetVisible
        End If
    End Sub

    Public Overridable Sub PrepareWorkbook(ByRef CurrentWorkbook As Excel.Workbook, ByVal NameOfDataSheet As String, ByVal NameOfImportSheet As String)
        'This is the first function called in the constructor

        Me.ThisWorkbook = CurrentWorkbook
        Me.NameOfDataSheet = NameOfDataSheet
        Me.NameOfImportSheet = NameOfImportSheet


        CreateDataSheet(Me.NameOfDataSheet)
        CreateImportSheet(Me.NameOfImportSheet)
        CreateFormattedDataSheet(Me.NameOfFormattedSheet)

        Me.Cell_IsSavFile = Me.shtDataSheet.Cells(3, 2)
        Me.FormattedShtReferenceCell = Me.shtFormatted.Range(Me.FormattedShtReferenceCellstr)
    End Sub

    Public Function CreateNewWorksheet(ByVal SheetName As String) As Excel.Worksheet
        'FPT1.1 HAS THIS CODE, NOT SURE IF ITS THE SAME
        'Dim worksheets As Sheets = Me.ThisWorkbook.Worksheets
        'worksheets.Add(, worksheets.Count)
        'Dim count As Worksheet = DirectCast(worksheets(worksheets.Count), Worksheet)
        'count.Name = SheetName
        'Return count

        Dim Sheets As Microsoft.Office.Interop.Excel.Sheets
        Sheets = Me.ThisWorkbook.Worksheets
        Sheets.Add(, Sheets(Sheets.Count))
        Dim NewSheet As Excel.Worksheet = Sheets(Sheets.Count)
        NewSheet.Name = SheetName
        Return NewSheet
    End Function

    Public Function CreateNewChartSheet(ByVal sheetName As String) As Excel.Chart
        'MATCHES FPT1.1
        Dim NewChart As Excel.Chart = Me.ThisWorkbook.Charts.Add()
        NewChart.Name = sheetName
        Return NewChart

    End Function

    Public Overridable Sub CreateFormattedDataSheet(ByVal SheetName As String)

        'create sheet, or set reference to sheet
        Try

            Dim IndexOfFormattedSheet As Integer = FindSheetIndex(SheetName)
            If IndexOfFormattedSheet = 0 Then
                'sheet does not exist, create it
                Me.shtFormatted = CreateNewWorksheet(SheetName)
                'create modules for worksheet


                'Check to make sure macro's don't already exist before tyring to recreate them:

                'Pull this section of the code out to make updating New data sheet easier 
                FillInFormattedSht()
            Else
                Me.shtFormatted = ThisWorkbook.Sheets(IndexOfFormattedSheet)
            End If


        Catch ex As Exception
            MessageBox.Show("Exception thrown in CreateFormattedDataSheet():" + vbNewLine + vbNewLine + ex.Message)
        End Try

    End Sub
    Public Sub FillInFormattedSht()
        Dim oModule = Me.ThisWorkbook.VBProject
        If UsefulFunctions.CheckIfExcelMacroExists("Tconvert") Then
            'do not re-create
        Else
            'create macro
            Dim TconvertString As String = My.Resources.TconvertModuletxt.ToString
            Dim Module1 As Microsoft.Vbe.Interop.VBComponent = oModule.VBComponents.Add(Microsoft.Vbe.Interop.vbext_ComponentType.vbext_ct_StdModule)
            Module1.CodeModule.AddFromString(TconvertString)
        End If

        If UsefulFunctions.CheckIfExcelMacroExists("timeconv") Then
            'do not re-create
        Else
            'create macro
            Dim TimeConvertString As String = My.Resources.TimeConvertModuletxt.ToString
            Dim Module2 As Microsoft.Vbe.Interop.VBComponent = oModule.VBComponents.Add(Microsoft.Vbe.Interop.vbext_ComponentType.vbext_ct_StdModule)
            Module2.CodeModule.AddFromString(TimeConvertString)
        End If

        If UsefulFunctions.CheckIfExcelMacroExists("TTL") Then
            'do not re-create
        Else
            'create macro
            Dim TTLString As String = My.Resources.TTLModuletxt.ToString
            Dim Module3 As Microsoft.Vbe.Interop.VBComponent = oModule.VBComponents.Add(Microsoft.Vbe.Interop.vbext_ComponentType.vbext_ct_StdModule)
            Module3.CodeModule.AddFromString(TTLString)
        End If

        'create formatted references to control sheet
        Dim Col1 As Excel.Range = shtFormatted.Range("A1")
        Col1.EntireColumn.ColumnWidth = 22.6

        shtFormatted.Range("A2").Value = "Time Convert"
        shtFormatted.Range("A3").Value = "Temp Convert"
        shtFormatted.Range("A5").Value = "Time Shift"
        shtFormatted.Range("A6").Value = "Chart Labels"
        shtFormatted.Range("A8").Value = "Component Description"
        shtFormatted.Range("A9").Value = "Node Number"
        shtFormatted.Range("A10").Value = "Non-Op Max"
        shtFormatted.Range("A11").Value = "Op Max"
        shtFormatted.Range("A12").Value = "Op Min"
        shtFormatted.Range("A13").Value = "Non-Op Min"
        shtFormatted.Range("A15").Value = "Max:"
        shtFormatted.Range("A16").Value = "Min:"
        shtFormatted.Range("A17").Value = "Average:"
        shtFormatted.Range("A18").Value = "TTL:"
        shtFormatted.Range("A26").Value = "Time"
        shtFormatted.Range("A27").Value = "=timeconv('" + shtImport.Name + "'!" + Me.FormattedShtReferenceCellstr + ",$B$2,$C$2)-$B$5"


        ''Create Margin Table'
        shtFormatted.Range("A20").Value = "Non-Op Max Margin"
        shtFormatted.Range("A21").Value = "Op Max Margin"
        shtFormatted.Range("A22").Value = "Op Min Margin"
        shtFormatted.Range("A23").Value = "Non-Op Min Margin"

        'ADD COMMENTS
        UsefulFunctions.AddCommentToExcelCell(shtFormatted.Range("A2"), "Convert time FROM PlotInfo units TO desired units.  Acceptable input is s,m,h,d")
        UsefulFunctions.AddCommentToExcelCell(shtFormatted.Range("A3"), "Convert FROM PlotInfo units TO desired units.  Acceptable input is C,K,F,R")
        UsefulFunctions.AddCommentToExcelCell(shtFormatted.Range("A5"), "This is subtracted from time value in this worksheet (must be in 'To:'  units from above)")
        UsefulFunctions.AddCommentToExcelCell(shtFormatted.Range("A6"), "Chart Legend Labels." + vbNewLine + "0: use node number" + vbNewLine + "1:      use(description)" + vbNewLine + "2: use both")
        UsefulFunctions.AddCommentToExcelCell(shtFormatted.Range("A9"), "Enter a descriptive label, such as ""Transmitter"".  What label is shown on the chart is controlled in the ""Chart Labels"" cell above.")
        UsefulFunctions.AddCommentToExcelCell(shtFormatted.Range("A10"), "Enter Component Limits.  Max Limits will turn red if component exceeds limit, and min limits will turn blue.  Make sure you drag across as there is conditional formatting")
        UsefulFunctions.AddCommentToExcelCell(shtFormatted.Range("A15"), "Max component temperature")
        UsefulFunctions.AddCommentToExcelCell(shtFormatted.Range("A16"), "Min component temperature")
        UsefulFunctions.AddCommentToExcelCell(shtFormatted.Range("A17"), "Average component temperature")
        UsefulFunctions.AddCommentToExcelCell(shtFormatted.Range("A18"), "Time to Limit.  Indicates time that component first exceeds a limit.  Select which limits to check in cell E5")
        UsefulFunctions.AddCommentToExcelCell(shtFormatted.Range("A20"), "Non-Op Max Margin = Non-Op Max - Max")
        UsefulFunctions.AddCommentToExcelCell(shtFormatted.Range("A21"), "Op Max Margin = Op Max - Max")
        UsefulFunctions.AddCommentToExcelCell(shtFormatted.Range("A22"), "Op Min Margin = Min - Op Min")
        UsefulFunctions.AddCommentToExcelCell(shtFormatted.Range("A23"), ")Non-Op Min Margin = Min - Non-Op Min")
        UsefulFunctions.AddCommentToExcelCell(shtFormatted.Range("D5"), "0: Check all Limits" + vbNewLine + "1:      Check Op Limits Only" + vbNewLine + "2: Check Non-Op Limits only")
        UsefulFunctions.AddCommentToExcelCell(shtFormatted.Range("E1"), "Automatically updates axis labels on chart, DO NOT CHANGE")


        shtFormatted.Range("B1").Value = "From:"
        shtFormatted.Range("B2").Value = "s"
        shtFormatted.Range("B3").Value = "C"
        shtFormatted.Range("B5").Value = 0
        shtFormatted.Range("B6").Value = 1
        shtFormatted.Range("B8").Value = "='" + shtImport.Name + "'!B$8"
        shtFormatted.Range("B9").Value = "='" + shtImport.Name + "'!B$9"
        shtFormatted.Range("B10").Value = "=Tconvert('" + shtImport.Name + "'!B$10,$B$3,$C$3)"
        shtFormatted.Range("B11").Value = "=Tconvert('" + shtImport.Name + "'!B$11,$B$3,$C$3)"
        shtFormatted.Range("B12").Value = "=Tconvert('" + shtImport.Name + "'!B$12,$B$3,$C$3)"
        shtFormatted.Range("B13").Value = "=Tconvert('" + shtImport.Name + "'!B$13,$B$3,$C$3)"
        shtFormatted.Range("B15").Value = "=MAX(B27:B65537)"
        shtFormatted.Range("B16").Value = "=MIN(B27:B65537)"
        shtFormatted.Range("B17").Value = "=Average(B27:B65537)"
        shtFormatted.Range("B18").Value = "=TTL(B$10:B$13,$A$27:$A$1048576,B$27:B$1048576,$E$5)"

        shtFormatted.Range("B26").Value = "=IF($B$6=0,B9,IF($B$6=1,B8,IF($B$6=2,B8& "" ("" &B9&"")"",""ERORR"")))"
        shtFormatted.Range("B27").Value = "=Tconvert('" + shtImport.Name + "'!B" + Me.FirstDataRowNumber.ToString + ",$C$3,$C$3)"

        shtFormatted.Range("B20").Formula = "=B10 - B15" ' Non-Op Max Margin
        shtFormatted.Range("B21").Formula = "=B11 - B15" ' Op Max Margin
        shtFormatted.Range("B22").Formula = "=B16 - B12" ' Op Min Margin
        shtFormatted.Range("B23").Formula = "=B16 - B13" ' Non-Op Min Margin


        shtFormatted.Range("C1").Value = "To:"
        shtFormatted.Range("C2").Value = "s"
        shtFormatted.Range("C3").Value = "C"

        shtFormatted.Range("D5").Value = "TTL Flag"

        shtFormatted.Range("E1").Value = "Chart Axis Labels:"
        shtFormatted.Range("E2").Value = "=CONCATENATE(""Time ["",IF(C2=""s"",""s"",IF(C2=""m"",""min"",IF(C2=""h"",""hours"",IF(C2=""d"",""days"",C2)))),""]"")"
        shtFormatted.Range("E3").Value = "=""Temperature [""&IF(OR(C3=""C"",C3=""F""),""°"","""") &UPPER(C3)&""]"""
        shtFormatted.Range("E5").Value = "0"

        MakeRangeBold(shtFormatted.Range("A2:A23"))
        MakeRangeBold(shtFormatted.Range("B1:E1"))
        MakeRangeBold(shtFormatted.Range("D5"))
        MakeRangeBold(shtFormatted.Range("A26"))
        MakeRangeBold(shtFormatted.Range("B26"))

        AddBordersToRange(shtFormatted.Range("B1:C3"))
        AddBordersToRange(shtFormatted.Range("A2:A3"))
        AddBordersToRange(shtFormatted.Range("A5:B6"))
        AddBordersToRange(shtFormatted.Range("A8:B13"))
        AddBordersToRange(shtFormatted.Range("A15:B18"))
        AddBordersToRange(shtFormatted.Range("A20:B23"))
        AddBordersToRange(shtFormatted.Range("D5:E5"))

        SetNumberOfDecimalPlaces(shtFormatted.Range("A26:B26"), 2)
        SetNumberOfDecimalPlaces(shtFormatted.Range("B15:B18"), 2)
        SetNumberOfDecimalPlaces(shtFormatted.Range("B20:B23"), 2)
        SetNumberOfDecimalPlaces(shtFormatted.Range("B10:B13"), 0)

        Dim ConditionalFormatCell As Excel.Range = shtFormatted.Range("B10")

        'non-op max
        Dim cf1 As Excel.FormatCondition = ConditionalFormatCell.FormatConditions.Add(Excel.XlFormatConditionType.xlCellValue, Excel.XlFormatConditionOperator.xlLessEqual, "=" + Me.ConditionalFormatStartColLetter + "$15")
        cf1.Interior.Color = Color.FromArgb(192, 80, 77)

        'op max
        ConditionalFormatCell = shtFormatted.Range("B11")
        Dim cf2 As Excel.FormatCondition = ConditionalFormatCell.FormatConditions.Add(Excel.XlFormatConditionType.xlCellValue, Excel.XlFormatConditionOperator.xlLessEqual, "=" + Me.ConditionalFormatStartColLetter + "$15")
        cf2.Interior.Color = Color.FromArgb(230, 184, 183)

        'op min
        ConditionalFormatCell = shtFormatted.Range("B12")
        Dim cf3 As Excel.FormatCondition = ConditionalFormatCell.FormatConditions.Add(Excel.XlFormatConditionType.xlCellValue, Excel.XlFormatConditionOperator.xlGreaterEqual, "=" + Me.ConditionalFormatStartColLetter + "$16")
        cf3.Interior.Color = Color.FromArgb(184, 204, 228)

        'non-op min
        ConditionalFormatCell = shtFormatted.Range("B13")
        Dim cf4 As Excel.FormatCondition = ConditionalFormatCell.FormatConditions.Add(Excel.XlFormatConditionType.xlCellValue, Excel.XlFormatConditionOperator.xlGreaterEqual, "=" + Me.ConditionalFormatStartColLetter + "$16")
        cf4.Interior.Color = Color.FromArgb(79, 129, 189)

    End Sub
    Public Overridable Sub CreateDataSheet(ByVal sheetname As String)
        Me.DataSheetManager = New DataSheetClass(sheetname)
        Me.shtDataSheet = DataSheetManager.TheDataSheet
    End Sub

    Public Overridable Sub CreateImportSheet(ByVal sheetName As String)
        Dim IndexOfImportSheet As Integer = FindSheetIndex(Me.NameOfImportSheet)
        If IndexOfImportSheet = 0 Then
            Me.shtImport = CreateNewWorksheet(NameOfImportSheet)
        Else
            Me.shtImport = ThisWorkbook.Sheets(IndexOfImportSheet)
            Exit Sub
        End If

        shtImport.Range("A8").Value = "Component Description"
        shtImport.Range("A9").Value = "Node Number"
        shtImport.Range("A10").Value = "Non-Op Max"
        shtImport.Range("A11").Value = "Op Max"
        shtImport.Range("A12").Value = "Op Min"
        shtImport.Range("A13").Value = "Non-Op Min"

    End Sub

    Public Overridable Function CreateMaxMinComparisonSheet(ByVal sheetname As String) As Excel.Worksheet
        Dim CompareSheet As Excel.Worksheet = Me.ThisWorkbook.Sheets.Add()
        CompareSheet.Move(, Me.ThisWorkbook.Sheets(Me.ThisWorkbook.Sheets.Count))
        CompareSheet.Name = ReturnNewNameIfSheetExists(Me.ThisWorkbook, sheetname)

        With CompareSheet

            SetColumnWidth(.Range("A1"), 40)

            .Range("A1").Value = "Component Description"
            .Range("A2").Value = "Node Number"
            .Range("A3").Value = "Non-Op Max"
            .Range("A4").Value = "Op Max"
            .Range("A5").Value = "Op Min"
            .Range("A6").Value = "Non-Op Min"

            MakeRangeBold(.Range("A1:A6"))
            AddBordersToRange(.Range("A1:B6"))

            .Range("A8").Value = "OVERALL MAX"
            .Range("A9").Value = "OVERALL MIN"
            .Range("A11").Value = "MAXIMUM TEMPERATURES"
            MakeRangeBold(.Range("A8:A11"))

            .Range("B1").Value = "='" + shtFormatted.Name + "'!B8"
            .Range("B2").Value = "='" + shtFormatted.Name + "'!B9"
            .Range("B3").Value = "='" + shtFormatted.Name + "'!B10"
            .Range("B4").Value = "='" + shtFormatted.Name + "'!B11"
            .Range("B5").Value = "='" + shtFormatted.Name + "'!B12"
            .Range("B6").Value = "='" + shtFormatted.Name + "'!B13"

            .Range("B8").Value = "=MAX(B11:B1048576)"
            .Range("B9").Value = "=MIN(B11:B1048576)"

            SetNumberOfDecimalPlaces(.Range("B8:B9"), 1)

        End With

        FreezePanes(CompareSheet, 1, 10)
        Try

            Dim ConditionalFormatCell As Excel.Range = CompareSheet.Range("B12")

            'Border around max cell
            Dim cf5 As Excel.FormatCondition = ConditionalFormatCell.FormatConditions.Add(Excel.XlFormatConditionType.xlCellValue, Excel.XlFormatConditionOperator.xlEqual, "=" + Me.ConditionalFormatStartColLetter + "$8")
            cf5.Borders.Color = Color.FromArgb(255, 192, 0)
            cf5.StopIfTrue = False
            'Border around min cell
            Dim cf6 As Excel.FormatCondition = ConditionalFormatCell.FormatConditions.Add(Excel.XlFormatConditionType.xlCellValue, Excel.XlFormatConditionOperator.xlEqual, "=" + Me.ConditionalFormatStartColLetter + "$9")
            cf6.Borders.Color = Color.FromArgb(255, 192, 0)
            cf6.StopIfTrue = False

            'non-op max
            Dim cf1 As Excel.FormatCondition = ConditionalFormatCell.FormatConditions.Add(Excel.XlFormatConditionType.xlCellValue, Excel.XlFormatConditionOperator.xlGreaterEqual, "=" + Me.ConditionalFormatStartColLetter + "$3")
            cf1.Interior.Color = Color.FromArgb(192, 80, 77)
            'non-op min
            Dim cf2 As Excel.FormatCondition = ConditionalFormatCell.FormatConditions.Add(Excel.XlFormatConditionType.xlCellValue, Excel.XlFormatConditionOperator.xlLessEqual, "=" + Me.ConditionalFormatStartColLetter + "$6")
            cf2.Interior.Color = Color.FromArgb(79, 129, 189)
            'op max
            Dim cf3 As Excel.FormatCondition = ConditionalFormatCell.FormatConditions.Add(Excel.XlFormatConditionType.xlCellValue, Excel.XlFormatConditionOperator.xlGreaterEqual, "=" + Me.ConditionalFormatStartColLetter + "$4")
            cf3.Interior.Color = Color.FromArgb(230, 184, 183)
            'op min
            Dim cf4 As Excel.FormatCondition = ConditionalFormatCell.FormatConditions.Add(Excel.XlFormatConditionType.xlCellValue, Excel.XlFormatConditionOperator.xlLessEqual, "=" + Me.ConditionalFormatStartColLetter + "$5")
            cf4.Interior.Color = Color.FromArgb(184, 204, 228)

            Return CompareSheet
        Catch ex As Exception
            MessageBox.Show("an exception was encountered while applying conditional formatting to the comparison sheet:" + vbNewLine + vbNewLine + ex.Message)
            Return CompareSheet
        End Try
    End Function

    Public Function FindSheetIndex(ByVal sheetname As String) As Integer
        'RETURNS 0 IF SHEET NOT FOUND, OTHERWISE RETURN INDEX
        For Each sheet As Excel.Worksheet In Me.ThisWorkbook.Worksheets
            If sheet.Name = sheetname Then
                Return sheet.Index
            End If


        Next
        Return 0
    End Function

    Public Overridable Sub ImportFiles()
        'THIS FUNTION IS CALLED WHEN THE IMPORT FILES BUTTON IS PRESSED
        Me.shtImport.Activate()

        Dim FileManager As New FileGroupManager(Me.DataSheetManager)

        FileManager.StartPosition = FormStartPosition.Manual
        Dim LocPoint As Point = PointsToPixelsAsPoint(Globals.ThisAddIn.Application.Left, Globals.ThisAddIn.Application.Top)
        LocPoint.Offset(40, 40)

        FileManager.Location = LocPoint
        FileManager.Focus()

        If FileManager.ShowDialog() = DialogResult.OK Then
            If FileManager.IsSavFilePlot Then
                Cell_IsSavFile.Value = 1
            Else
                Cell_IsSavFile.Value = 0
            End If
            UpdateDataForGroup(False)
        End If

    End Sub

    Public Sub UpdateDataForGroup(ByVal IsRefresh As Boolean, Optional ByVal RefreshImportSheet As Boolean = True, Optional ByVal RefreshFormattedSheet As Boolean = True)
        Me.shtImport.Activate()
        Dim IsSav As Boolean
        If Me.Cell_IsSavFile.Value = 1 Then
            IsSav = True
        Else
            IsSav = False
        End If

        Dim DataColIndex As Integer = 2
        Dim Files As New GenericFileCollection
        Dim SavFileList As New SavFileInfoCollection
        Dim Delimiter As String
        Dim GroupType As String

        If DataColIndex = -1 Then
            '04/16/2017 SJS:  Not sure why this part of IF statement is needed?  old code maybe?
            'data was not found, exit subroutine
            MessageBox.Show("Error, could not update files.  No dataset was found.")
            Exit Sub

        ElseIf Me.DataSheetManager.CellFirstFileName.Value Is Nothing Then
            'make sure there is at least one file in the file list on the groupinfo hidden sheet
            'if there are no files, exit with message
            MessageBox.Show("Error, no files found.  Make sure there are specified files in the file manager")
            Exit Sub
        Else
            'get the group type (compare or stitch)

            GroupType = Me.DataSheetManager.CellCompareOrStich.Value
            'get the delimiter
            Delimiter = Me.DataSheetManager.CellDelimiter.Value

            'create counter for the index of the file
            Dim index As Integer = 0

            'Load all files in teh data sheet
            While True

                If Me.DataSheetManager.CellFirstFileName.Offset(index).Value Is Nothing Then
                    Exit While
                Else
                    'Get data for file
                    Dim name As String = Me.DataSheetManager.CellFirstFileName.Offset(index).Value

                    'sjs 07-15-2015
                    'check to make sure file exists, if it doesn't, exit
                    If FileExists(name) = False Then
                        MessageBox.Show("The file:" + vbNewLine + vbNewLine + name + vbNewLine + vbNewLine + " does not exist.  Remove this file using the file manager.")
                        Exit Sub
                    End If


                    If IsSav Then
                        'create a new sav file
                        Dim sav As New SavFileInfo(name, index, Me.DataSheetManager, Me.shtImport)
                        Files.Add(sav)
                    Else
                        'create new textfileinfo
                        Dim Tfi As New TextFileInfo(name, index, Delimiter, Me.DataSheetManager, Me.shtImport, Me.shtFormatted, Me.FirstDataRowNumber - 1)
                        'Add textfileinfo to the list
                        Files.Add(Tfi)


                    End If
                    'increment counters
                    index += 1

                End If
            End While

        End If

        If IsSav Then
            If IsRefresh Then
                'refresh button was pressed
                For Each savfile As SavFileInfo In Files
                    savfile.GetPlotListFromDataSheet()
                Next
            Else
                Dim FirstSavFile As SavFileInfo = Files(0)
                FirstSavFile.GetPlotListFromDataSheet()

                Dim SavImporter As New SavFileImport(FirstSavFile.Submodels, FirstSavFile.ItemsToPlot)
                If SavImporter.ShowDialog = DialogResult.OK Then
                    For Each savfile As SavFileInfo In Files
                        savfile.ItemsToPlot = SavImporter.GetSelectedSubmodels
                    Next
                Else
                    Exit Sub
                End If
            End If

        End If


        If GroupType = "C" Then
            'comaprison files

            If RefreshImportSheet Then
                Try
                    PopulateImportSheet(Files, Delimiter, PlotType.Compare)
                Catch ex As System.ApplicationException
                    Exit Sub
                End Try

            End If

            If RefreshFormattedSheet Then
                PopulateFormattedSheet(Files, Delimiter, PlotType.Compare)
            End If

        ElseIf GroupType = "S" Then
            'stitch files

            If RefreshImportSheet Then
                Try
                    PopulateImportSheet(Files, Delimiter, PlotType.Stitch)
                Catch ex As System.ApplicationException
                    Exit Sub
                End Try
            End If

            If RefreshFormattedSheet Then
                PopulateFormattedSheet(Files, Delimiter, PlotType.Stitch)
            End If

        End If

        'SJS 05-28-15 MOVED THIS FROM POPULATEFORMATTEDSHEET FUNCTION
        'TO HERE FOR MORE CLARITY
        UpdateChartSeriesRanges()

        Me.shtImport.Activate()

    End Sub

    Private Sub PopulateImportSheet(ByVal files As GenericFileCollection, ByVal Delim As String, ByVal TypeOfPlot As PlotType)
        ClearControlSheet()
        If TypeOfPlot = PlotType.Stitch Then
            Dim StitchOption As FileGroupManager.StitchType
            'Dim OptionCellString As String = shtDataSheet.Cells(10, 2).Value().ToString
            Dim OptionCellString As String = Me.DataSheetManager.CellTypeOfStitch.Value().ToString
            If OptionCellString = [Enum].GetName(GetType(FileGroupManager.StitchType), FileGroupManager.StitchType.FileTimesInOrder) Then
                StitchOption = FileGroupManager.StitchType.FileTimesInOrder
            ElseIf OptionCellString = [Enum].GetName(GetType(FileGroupManager.StitchType), FileGroupManager.StitchType.FilesStartAt0) Then
                StitchOption = FileGroupManager.StitchType.FilesStartAt0
            End If
            'reference for the previous file in the array
            Dim LastFile As GenericFileInfo = Nothing

            With Me.shtImport

                For Each file As GenericFileInfo In files

                    file.ReadFileIntoClipBoard()
                    If FileHasDataAndDelimCorrect(file.Name, file.NumCols) Then
                    Else
                        Throw New System.ApplicationException
                    End If

                    'textfile now knows the number of rows and columns, but doesn't know where to start
                    'this block sets the start row and col in the textfile
                    If file.Index = 0 Then
                        'if its the first file in the list
                        file.ChangeRowAndColStarts(FirstDataRowNumber, 1)
                    Else
                        'its not the first file, base the first column on the previous files last column
                        file.ChangeRowAndColStarts(LastFile.RowEnd + 1, LastFile.ColStart)
                    End If

                    'Paste the copied data into the worksheet
                    Dim rngPasteCell As Excel.Range = .Cells(file.RowStart, file.ColStart)
                    rngPasteCell.PasteSpecial()

                    If StitchOption = FileGroupManager.StitchType.FilesStartAt0 Then
                        If file.Index = 0 Then
                        Else
                            Dim LastTimeOfLastFile As Double = CType(.Cells(LastFile.RowEnd, LastFile.TimeColumn).value(), Double)
                            For i As Integer = file.RowStart To file.RowEnd
                                .Cells(i, file.TimeColumn).Value() = .Cells(i, file.TimeColumn).Value() + LastTimeOfLastFile
                            Next

                        End If


                    End If


                    'update the GroupInfo sheet
                    file.UpdateDataSheet()

                    'set reference to current file for use in next iteration
                    LastFile = file

                Next

                .Cells(1, 1).Activate()

            End With

        ElseIf TypeOfPlot = PlotType.Compare Then
            With Me.shtImport

                'reference for the previous file in the array
                Dim LastFile As GenericFileInfo = Nothing

                For Each file As GenericFileInfo In files

                    'read file into clipboard and get the number of rows and columns in the file
                    file.ReadFileIntoClipBoard()
                    If FileHasDataAndDelimCorrect(file.Name, file.NumCols) Then
                    Else
                        Throw New System.ApplicationException
                    End If

                    'file now knows the number of rows and columns, but doesn't know where to start
                    'this block sets the start row and col in the textfile
                    If file.Index = 0 Then
                        'if its the first file in the list
                        file.ChangeRowAndColStarts(FirstDataRowNumber, 1)
                    Else
                        'its not the first file, base the first column on the previous files last column
                        file.ChangeRowAndColStarts(FirstDataRowNumber, LastFile.ColEnd + 2)
                    End If

                    'Paste the copied data into the worksheet
                    Dim rngPasteCell As Excel.Range = .Cells(file.RowStart, file.ColStart)
                    'SJS 07/27/2018 added the sleep statement below to fix a paste exception that was happening randomly on windows 10.  
                    'this seems to work, but i don't know what is causing the underlying issue
                    System.Threading.Thread.Sleep(1000)
                    rngPasteCell.PasteSpecial(Microsoft.Office.Interop.Excel.XlPasteType.xlPasteAll)

                    'update the GroupInfo sheet
                    file.UpdateDataSheet()
                    'Print file name to control sheet
                    .Cells(7, file.ColStart + 2).Value = file.FolderAndFileNameOnly
                    .Cells(7, file.ColStart + 2).Font.Bold = True

                    'set reference to current file for use in next iteration
                    LastFile = file

                Next

                .Cells(1, 1).Activate()

            End With
        End If


    End Sub

    Private Sub PopulateFormattedSheet(ByVal files As GenericFileCollection, ByVal Delim As String, ByVal TypeOfPlot As PlotType)
        ClearFormattedSheet()
        If TypeOfPlot = PlotType.Stitch Then
            Dim LastFile As GenericFileInfo = files.Item(files.Count - 1)
            Me.shtFormatted.Activate()
            FillFormattedSheetSection(1, LastFile.RowEnd, LastFile.ColEnd)
            Me.shtFormatted.Cells(1, 1).Activate()

        ElseIf TypeOfPlot = PlotType.Compare Then
            With Me.shtFormatted

                For Each file As GenericFileInfo In files
                    If file.Index = 0 Then

                        Me.shtFormatted.Activate()

                        CreateFormattedSheetFormulas()

                        FillFormattedSheetSection(file.ColStart, file.RowEnd, file.ColEnd)

                        AddFileNameAndCombinedFileNameRow(file)

                        'Print file name to Formatted sheet
                        '.Cells(7, file.ColStart + 2).Value = file.FolderAndFileNameOnly
                        '.Cells(7, file.ColStart + 2).Font.Bold = True

                    Else
                        'copy and pased the first part of the formatted sheet headers and limits to the next spot
                        Dim CopyRange As Excel.Range = .Range(.Cells(8, 1), .Cells(FirstDataRowNumber, 2))
                        Dim PasteRange As Excel.Range = .Cells(8, file.ColStart)

                        CopyRange.Copy()
                        PasteRange.PasteSpecial()
                        FixTTLTimeColumnLetter(file.ColStart)
                        'set the copied limits equal to the first set
                        'note that this assumes all files have equivalent nodes and limits
                        'was originally looping through cells to do this, but it is WAY slower.  Never loop through cells
                        Dim HeaderCellStart As Excel.Range = .Cells(8, file.ColStart + 1)
                        HeaderCellStart.Value = "=B8"
                        Dim HeaderFillRange As Excel.Range = .Range(HeaderCellStart, .Cells(13, file.ColStart + 1))
                        HeaderCellStart.AutoFill(HeaderFillRange, Excel.XlAutoFillType.xlFillValues)

                        FillFormattedSheetSection(file.ColStart, file.RowEnd, file.ColEnd)

                        AddFileNameAndCombinedFileNameRow(file)

                    End If
                Next
                Me.shtFormatted.Cells(1, 1).Activate()

            End With
        End If

        'SJS 05-28-15 MOVED TO END OF UPDATEDATAFORGROUP FUNCTION FOR CLARITY
        'UpdateChartSeriesRanges()


    End Sub

    Public Sub AddFileNameAndCombinedFileNameRow(ByVal file As GenericFileInfo)
        With Me.shtFormatted
            'Print file name to Formatted sheet
            .Cells(7, file.ColStart + 2).Value = file.FolderAndFileNameOnly
            .Cells(7, file.ColStart + 2).Font.Bold = True

            Dim FileNameOnly As String = UsefulFunctions.GetFileNameFromFullPathText(file.FolderAndFileNameOnly)


            .Cells(25, file.ColStart + 1).Value = "=""" + FileNameOnly + " ""&" + .Cells(26, file.ColStart + 1).Address.ToString.Replace("$", "")

            Dim CombinedRow As Excel.Range = .Range(.Cells(25, file.ColStart + 1), .Cells(25, file.ColEnd))

            'the IF statement here is to avoid a strange behavior
            'if your range has the same column values (one col selected), and you try to fill right,
            'it will fill the previous columns data into the selected columns data
            'seems like a bug
            If file.ColStart + 1 = file.ColEnd Then
            Else
                CombinedRow.FillRight()
            End If


        End With
    End Sub



    Public Sub ClearFormattedSheet()
        With Me.shtFormatted
            Dim StartCell As String = "A" + (FirstDataRowNumber + 1).ToString
            .Range("C" + FileNameRowNumber.ToString, "XFD1048576").Clear()
            .Range("C" + FileNameRowNumber.ToString, "XFD1048576").ClearOutline()
            'clear the filename+header cells for compare plots
            .Range("A" + (FirstDataRowNumber - 2).ToString, "XFD" + (FirstDataRowNumber - 2).ToString).Clear()
            .Range(StartCell, "B1048576").Clear()

            'add cell for Delta time for kaitlin
            .Range("A25").Value = "=LOOKUP(9.99999999999999E+307,A" + Me.FirstDataRowNumber.ToString + ": A1048576)-" + Me.FormattedShtReferenceCellstr + " "

        End With
    End Sub

    Public Sub ClearControlSheet()
        With Me.shtImport
            Dim StartCell As String = "A" + FirstDataRowNumber.ToString
            .Range(StartCell, "XFD1048576").Clear()

            'clear file names from sheet
            Dim FileNameStartCell As String = "A" + FileNameRowNumber.ToString
            Dim FileEndCell As String = "XFD" + FileNameRowNumber.ToString
            .Range(FileNameStartCell, FileEndCell).Clear()

        End With
    End Sub

    Public Sub CreateFormattedSheetFormulas()
        'Recreate these formulas in case someone changes them accidentally:
        shtFormatted.Range("A27").Value = "=timeconv('" + shtImport.Name + "'!A" + Me.FirstDataRowNumber.ToString + ",$B$2,$C$2)-$B$5"
        shtFormatted.Range("B8").Value = "='" + shtImport.Name + "'!B$8"
        shtFormatted.Range("B9").Value = "='" + shtImport.Name + "'!B$9"
        shtFormatted.Range("B10").Value = "=Tconvert('" + shtImport.Name + "'!B$10,$B$3,$C$3)"
        shtFormatted.Range("B11").Value = "=Tconvert('" + shtImport.Name + "'!B$11,$B$3,$C$3)"
        shtFormatted.Range("B12").Value = "=Tconvert('" + shtImport.Name + "'!B$12,$B$3,$C$3)"
        shtFormatted.Range("B13").Value = "=Tconvert('" + shtImport.Name + "'!B$13,$B$3,$C$3)"
        shtFormatted.Range("B15").Value = "=MAX(B" + Me.FirstDataRowNumber.ToString + ":B65537)"
        shtFormatted.Range("B16").Value = "=MIN(B" + Me.FirstDataRowNumber.ToString + ":B65537)"
        shtFormatted.Range("B17").Value = "=Average(B" + Me.FirstDataRowNumber.ToString + ":B65537)"
        shtFormatted.Range("B18").Value = "=TTL(B$10:B$13,$A$" + Me.FirstDataRowNumber.ToString + ":$A$1048576,B$" + Me.FirstDataRowNumber.ToString + ":B$1048576,$E$5)"

        shtFormatted.Range("B26").Value = "=IF($B$6=0,B9,IF($B$6=1,B8,IF($B$6=2,B8& "" ("" &B9&"")"",""ERORR"")))"
        shtFormatted.Range("B27").Value = "=Tconvert('" + shtImport.Name + "'!B" + Me.FirstDataRowNumber.ToString + ",$B$3,$C$3)"
        shtFormatted.Range("E2").Value = "=CONCATENATE(""Time ["",IF(C2=""s"",""s"",IF(C2=""m"",""min"",IF(C2=""h"",""hours"",IF(C2=""d"",""days"",C2)))),""]"")"
        shtFormatted.Range("E3").Value = "=""Temperature [""&IF(OR(C3=""C"",C3=""F""),""°"","""") &UPPER(C3)&""]"""
    End Sub


    Public Sub FillFormattedSheetSection(ByVal TimeCol As Integer, ByVal LastRow As Integer, ByVal LastCol As Integer)
        With Me.shtFormatted

            Dim TimeRange As Excel.Range = .Range(.Cells(FirstDataRowNumber, TimeCol), .Cells(LastRow, TimeCol))
            Dim TempRange As Excel.Range = .Range(.Cells(FirstDataRowNumber, TimeCol + 1), .Cells(LastRow, LastCol))

            'the IF statement here is to avoid a strange behavior
            'if your range has the same row values (one row selected), and you try to fill down,
            'it will fill the previous rows data into the selected rows data
            'seems like a bug
            If LastRow = FirstDataRowNumber Then
            Else
                TimeRange.FillDown()
                TempRange.FillDown()
            End If

            'This IF statement is to avoid another strange behaviour, probably bug
            'if there is only one node in a file, FILLRIGHT fills from the previous column into itself
            'same type of bug as above
            If LastCol - TimeCol = 1 Then
            Else
                TempRange.FillRight()
            End If


            Dim HeaderRange As Excel.Range = .Range(.Cells(8, TimeCol + 1), .Cells(Me.FirstDataRowNumber - 1, LastCol))

            'the IF statement here is to avoid a strange behavior
            'if your range has the same column values (one col selected), and you try to fill right,
            'it will fill the previous columns data into the selected columns data
            'seems like a bug
            If TimeCol + 1 = LastCol Then
            Else
                HeaderRange.FillRight()
            End If

        End With
    End Sub

    Public Function FileHasDataAndDelimCorrect(ByVal FileName As String, ByVal NumCols As Integer) As Boolean
        If NumCols = 1 Then
            MessageBox.Show("Only 1 column of data found in file:" + vbNewLine + FileName + vbNewLine + "There must be at least 2 columns of data (Time, Temp).  If this file has more than 1 column of data, you may have selected the wrong delimeter", "Found Only 1 Column")
            Return False
        ElseIf NumCols = 0 Then
            MessageBox.Show(FileName + " is empty.  Import aborted, remove this file from the file manager.", "File Is Empty")
            Return False
        Else

            Return True
        End If
    End Function

    Public Sub StoreTextFilesInArray(ByRef FileArray As TextFileCollection)

        'create counter for the first row containing file names
        'Dim row As Integer = 10
        'create counter for the index of the file
        Dim index As Integer = 0
        'Dim PlotType As String = Me.shtDataSheet.Cells(11, 2).Value.ToString
        Dim PlotType As String = Me.DataSheetManager.CellCompareOrStich.Value.ToString

        'Dim Delimiter As String = Me.shtDataSheet.Cells(12, 2).Value
        Dim Delimiter As String = Me.DataSheetManager.CellDelimiter.Value.ToString
        If PlotType = "C" Then
            'create multiple textfiles
            While True
                'If Me.shtDataSheet.Cells(row, 3).Value Is Nothing Then
                If Me.DataSheetManager.CellFirstFileName.Offset(index).Value Is Nothing Then
                    Exit While
                Else
                    'Get data for file
                    'Dim name As String = Me.shtDataSheet.Cells(row, 3).Value
                    'Dim RowStart As Integer = Me.shtDataSheet.Cells(row, 4).Value
                    'Dim RowEnd As Integer = Me.shtDataSheet.Cells(row, 5).Value
                    'Dim ColStart As Integer = Me.shtDataSheet.Cells(row, 6).Value
                    'Dim ColEnd As Integer = Me.shtDataSheet.Cells(row, 7).Value

                    Dim name As String = Me.DataSheetManager.CellFirstFileName.Offset(index).Value
                    Dim RowStart As Integer = Me.DataSheetManager.CellFirstFileRowStart.Offset(index).Value
                    Dim RowEnd As Integer = Me.DataSheetManager.CellFirstFileRowEnd.Offset(index).Value
                    Dim ColStart As Integer = Me.DataSheetManager.CellFirstFileColStart.Offset(index).Value
                    Dim ColEnd As Integer = Me.DataSheetManager.CellFirstFileColEnd.Offset(index).Value

                    'create new textfileinfo
                    'Dim Tfi As New TextFileInfo(name, index, Delimiter, RowStart, RowEnd, ColStart, ColEnd, Me.shtDataSheet, Me.shtImport, Me.shtFormatted, Me.FirstDataRowNumber - 1)
                    Dim Tfi As New TextFileInfo(name, index, Delimiter, RowStart, RowEnd, ColStart, ColEnd, Me.DataSheetManager, Me.shtImport, Me.shtFormatted, Me.FirstDataRowNumber - 1)

                    'Add textfileinfo to the list
                    FileArray.Add(Tfi)
                    'increment counters
                    'row += 1
                    index += 1
                End If
            End While

        Else
            'create single text file
            Dim name As String = "Stitched Files"
            'Dim RowStart As Integer = Me.shtDataSheet.Cells(row, 4).Value
            'Dim ColStart As Integer = Me.shtDataSheet.Cells(row, 6).Value

            Dim RowStart As Integer = Me.DataSheetManager.CellFirstFileRowStart.Value
            Dim ColStart As Integer = Me.DataSheetManager.CellFirstFileColStart.Value
            While True
                'If Me.shtDataSheet.Cells(row, 3).Value Is Nothing Then
                If Me.DataSheetManager.CellFirstFileName.Offset(index).Value Is Nothing Then
                    'row -= 1
                    index -= 1
                    Exit While
                Else
                    'row += 1
                    index += 1
                End If
            End While

            'Dim RowEnd As Integer = Me.shtDataSheet.Cells(index, 5).Value
            'Dim ColEnd As Integer = Me.shtDataSheet.Cells(index, 7).Value

            Dim RowEnd As Integer = Me.DataSheetManager.CellFirstFileRowEnd.Offset(index).Value
            Dim ColEnd As Integer = Me.DataSheetManager.CellFirstFileColEnd.Offset(index).Value

            'create new textfileinfo
            'Dim Tfi As New TextFileInfo(name, index, Delimiter, RowStart, RowEnd, ColStart, ColEnd, Me.shtDataSheet, Me.shtImport, Me.shtFormatted, Me.FirstDataRowNumber - 1)
            Dim Tfi As New TextFileInfo(name, index, Delimiter, RowStart, RowEnd, ColStart, ColEnd, Me.DataSheetManager, Me.shtImport, Me.shtFormatted, Me.FirstDataRowNumber - 1)
            'Add textfileinfo to the list
            FileArray.Add(Tfi)
        End If

    End Sub

    Public Function FilesExist() As Boolean
        'If shtDataSheet.Cells(10, 3).Value Is Nothing Then
        If Me.DataSheetManager.CellFirstFileName.Value Is Nothing Then
            Return False
        Else
            Return True
        End If
    End Function

    Public Sub CompareFiles()

        'If Me.shtDataSheet.Cells(11, 2).Value = "S" Then
        If Me.DataSheetManager.CellCompareOrStich.Value = "S" Then
            MessageBox.Show("Not available for stiched files")
        ElseIf Not FilesExist() Then
            MessageBox.Show("No Files have been added")
        Else
            Me.shtImport.Activate()
            Dim shtComp As Excel.Worksheet = CreateMaxMinComparisonSheet("Max Min Compare")

            'shtComp.Visible = Excel.XlSheetVisibility.xlSheetVisible
            'Dim NumberOfSheets = Me.ThisWorkbook.Sheets.Count
            'Me.ThisWorkbook.Sheets(3).Copy(, Me.ThisWorkbook.Sheets.Item(NumberOfSheets))
            'NumberOfSheets += 1
            'shtComp.Visible = Excel.XlSheetVisibility.xlSheetVeryHidden

            With shtComp
                'Dim ColStart As Integer = Me.shtDataSheet.Cells(10, 6).Value()
                'Dim ColEnd As Integer = Me.shtDataSheet.Cells(10, 7).Value()
                Dim ColStart As Integer = Me.DataSheetManager.CellFirstFileColStart.Value
                Dim ColEnd As Integer = Me.DataSheetManager.CellFirstFileColEnd.Value
                Dim NumCols As Integer = ColEnd - ColStart
                'Dim NumFiles As Integer = Me.shtDataSheet.Cells(1, 2).value()
                Dim NumFiles As Integer = Me.DataSheetManager.CellNumberOfFiles.Value

                Dim StartRowMax As Integer = 12
                Dim EndRowRangeMax As Integer = StartRowMax + NumFiles - 1

                Dim StartRowRangeMin As Integer = EndRowRangeMax + 3
                Dim EndRowRangeMin As Integer = StartRowMax + 2 * NumFiles + 1

                'set minimum name cell, make it bold
                .Cells(StartRowMax + NumFiles + 1, 1).Value = "MINIMUM TEMPERATURES"
                .Cells(StartRowMax + NumFiles + 1, 1).Font.Bold = True

                'Fill limits accross top of page
                Dim LimitRange As Excel.Range = .Range(.Cells(1, 2), .Cells(9, ColEnd))
                If NumCols = 1 Then
                Else
                    LimitRange.FillRight()
                End If

                'fill conditional formatting cell over full range of max/min data
                Dim FormatRangeMax As Excel.Range = .Range(.Cells(StartRowMax, 2), .Cells(EndRowRangeMax, ColEnd))
                FormatRangeMax.FillDown()

                Dim CopyLastMaxCell As Excel.Range = .Cells(EndRowRangeMax, 2)
                CopyLastMaxCell.Copy()
                Dim FormatRangeMin As Excel.Range = .Range(.Cells(StartRowRangeMin, 2), .Cells(EndRowRangeMin, ColEnd))
                FormatRangeMin.PasteSpecial(Excel.XlPasteType.xlPasteAll)

                'Set RunTime Name
                .Cells(StartRowMax - 2, ColEnd + 2).Value = "RunTime"
                .Cells(StartRowMax - 2, ColEnd + 2).Font.Bold = True

                'Set TTL Headers
                .Cells(StartRowMax - 3, ColEnd + 4).Value = "TTL"
                .Cells(StartRowMax - 3, ColEnd + 4).Font.Bold = True
                .Cells(StartRowMax - 2, ColEnd + 4).Value = "=B1"
                .Cells(StartRowMax - 2, ColEnd + 4).Font.Bold = True

                'fill range for TTL
                Dim TTLRange As Excel.Range = .Range(.Cells(StartRowMax - 3, ColEnd + 4), .Cells(EndRowRangeMin, ColEnd + 3 + NumCols))

                For i As Integer = 1 To NumFiles
                    'Dim ColStart1 As Integer = Me.shtDataSheet.Cells(10 + i - 1, 6).Value()
                    'Dim ColEnd1 As Integer = Me.shtDataSheet.Cells(10 + i - 1, 7).Value()
                    Dim ColStart1 As Integer = Me.DataSheetManager.CellFirstFileColStart.Offset(i - 1).Value()
                    Dim ColEnd1 As Integer = Me.DataSheetManager.CellFirstFileColEnd.Offset(i - 1).Value()

                    'Set maximimum value cells and file names
                    Dim MaxCellLocation As String = "='Formatted Data'!" + GetExcelColumnName(ColStart1 + 1) + (15).ToString
                    '.Cells(StartRowMax, 1).Value = Me.shtDataSheet.Cells(10 + i - 1, 3).Value()
                    .Cells(StartRowMax, 1).Value = Me.DataSheetManager.CellFirstFileName.Offset(i - 1).Value()
                    .Range("A" & StartRowMax).HorizontalAlignment = Excel.XlHAlign.xlHAlignRight

                    .Cells(StartRowMax, 2).Value = MaxCellLocation

                    'Set RunTime (for Kaitlin)
                    Dim RunTimeLocation As String = "='Formatted Data'!" + GetExcelColumnName(ColStart1) + (18).ToString
                    'next to max table
                    .Cells(StartRowMax, ColEnd + 2).Value = RunTimeLocation
                    'next to min table
                    .Cells(StartRowMax + NumFiles + 2, ColEnd + 2).Value = RunTimeLocation

                    'Set TTL data 
                    Dim TTLCellLocation As String = "='Formatted Data'!" + GetExcelColumnName(ColStart1 + 1) + (17).ToString
                    'next to max table
                    .Cells(StartRowMax, ColEnd + 4).Value = TTLCellLocation
                    'next to min table
                    .Cells(StartRowMax + NumFiles + 2, ColEnd + 4).Value = TTLCellLocation



                    'set minimum value cells and file names
                    Dim MinCellLocation As String = "='Formatted Data'!" + GetExcelColumnName(ColStart1 + 1) + (16).ToString
                    ' .Cells(StartRowMax + NumFiles + 2, 1).Value = Me.shtDataSheet.Cells(10 + i - 1, 3).Value()
                    .Cells(StartRowMax + NumFiles + 2, 1).Value = Me.DataSheetManager.CellFirstFileName.Offset(i - 1).Value()
                    .Cells(StartRowMax + NumFiles + 2, 1).HorizontalAlignment = Excel.XlHAlign.xlHAlignRight ' Added line for horizontal alignment
                    .Cells(StartRowMax + NumFiles + 2, 2).Value = MinCellLocation



                    StartRowMax += 1
                Next

                If NumCols = 1 Then
                Else
                    'fill all remaining max/min values
                    FormatRangeMax.FillRight()
                    FormatRangeMin.FillRight()
                    'fill TTL range
                    TTLRange.FillRight()
                End If


            End With
        End If
    End Sub


    '=============================
    'PLOTTING FUNCTIONS

    Public Sub NewPlot()
        Dim FileArray As New TextFileCollection

        'Get all files in data set and store in array
        Try
            StoreTextFilesInArray(FileArray)
        Catch ex As Exception
            MessageBox.Show("No Files, Cannot Make Plot")
            Exit Sub
        End Try


        For Each textfile As TextFileInfo In FileArray
            textfile.GetHeadersForEachSeries()
        Next

        Dim ChartMaker As New PlotCreator(FileArray, Me.shtDataSheet)
        ChartMaker.StartPosition = FormStartPosition.Manual
        Dim LocPoint As Point = PointsToPixelsAsPoint(Globals.ThisAddIn.Application.Left, Globals.ThisAddIn.Application.Top)
        LocPoint.Offset(40, 40)

        ChartMaker.Location = LocPoint
        ChartMaker.Focus()

        Dim NameTest As String = Me.ThisWorkbook.Name

        'ChartMaker.SeriesLimitList.RefreshList(FileArray.Item(0))
        If ChartMaker.ShowDialog() = DialogResult.OK Then
            'SJS 05-08-15 ELIMINATE TEMPLATE CHART
            'CREATE NEW CHART DIRECTLY
            'Me.chtTemplate.Visible = Excel.XlSheetVisibility.xlSheetVisible
            Dim ChartCollections As ArrayList = ChartMaker.ChartSeriesCollections
            Dim LimitCollections As ArrayList = ChartMaker.ChartLimitCollections
            Dim IndexFormatted As Integer = Me.shtFormatted.Index

            If ChartMaker.GetTypeOfChart = PlotCreator.ChartType.Compare Then
                ChartMaker.CheckForDuplicatNames()
                'SJS 05-08-15 ELIMINATE TEMPLATE CHART
                'CREATE NEW CHART DIRECTLY
                'Dim NewChart As Excel.Chart = CreateNewChartFromTemplate(ChartMaker.PlotName, Me.ThisWorkbook.Sheets(2), Me.ThisWorkbook)
                Dim NewChart As Excel.Chart = PlottingFunctions.CreateTemplateChart(ChartMaker.PlotName, Me.ThisWorkbook, shtFormatted.Name)

                AddPlotSeriesCollectionToChart(NewChart, Me.ThisWorkbook.Sheets(IndexFormatted), CType(ChartCollections(0), PlotSeriesInfoCollection))
                AddLimitsToChart(Me.ThisWorkbook.ActiveChart, Me.ThisWorkbook.Sheets(IndexFormatted), CType(LimitCollections(0), PlotLimitInfoCollection), Me.ThisWorkbook)

                For i As Integer = 1 To ChartCollections.Count - 1
                    Dim SeriesCollection As PlotSeriesInfoCollection = CType(ChartCollections(i), PlotSeriesInfoCollection)
                    For j As Integer = 0 To SeriesCollection.Count - 1
                        AddPlotSeriesToChart(NewChart, Me.ThisWorkbook.Sheets(IndexFormatted), SeriesCollection.Item(j))
                    Next
                Next

            Else
                For i As Integer = 0 To ChartCollections.Count - 1
                    ChartMaker.CheckForDuplicatNames()

                    'SJS 05-08-15 ELIMINATE TEMPLATE CHART
                    'CREATE NEW CHART DIRECTLY
                    'Dim NewChart As Excel.Chart = CreateNewChartFromTemplate(ChartMaker.PlotName, Me.ThisWorkbook.Sheets(2), Me.ThisWorkbook)
                    Dim NewChart As Excel.Chart = PlottingFunctions.CreateTemplateChart(ChartMaker.PlotName, Me.ThisWorkbook, shtFormatted.Name)

                    AddPlotSeriesCollectionToChart(NewChart, Me.ThisWorkbook.Sheets(IndexFormatted), CType(ChartCollections(i), PlotSeriesInfoCollection))
                    AddLimitsToChart(NewChart, Me.ThisWorkbook.Sheets(IndexFormatted), CType(LimitCollections(i), PlotLimitInfoCollection), Me.ThisWorkbook)
                Next
            End If

            'SJS 05-08-15 ELIMINATE TEMPLATE CHART
            'CREATE NEW CHART DIRECTLY
            'Me.chtTemplate.Visible = Excel.XlSheetVisibility.xlSheetVeryHidden
        End If

    End Sub

    'SJS 05-01-15 ADDED TO CREATE A PLOT AUTOMATICALLY IN DEBUG MODE
    Public Sub DebugNewPlot(ByVal NumSeries As Integer)
        Dim FileArray As New TextFileCollection

        'Get all files in data set and store in array
        Try
            StoreTextFilesInArray(FileArray)
        Catch ex As Exception
            MessageBox.Show("No Files, Cannot Make Plot")
            Exit Sub
        End Try


        For Each textfile As TextFileInfo In FileArray
            textfile.GetHeadersForEachSeries()
        Next

        Dim ChartMaker As New PlotCreator(FileArray, Me.shtDataSheet)
        ChartMaker.StartPosition = FormStartPosition.Manual
        Dim LocPoint As Point = PointsToPixelsAsPoint(Globals.ThisAddIn.Application.Left, Globals.ThisAddIn.Application.Top)
        LocPoint.Offset(40, 40)

        ChartMaker.Location = LocPoint
        ChartMaker.Focus()

        Dim NameTest As String = Me.ThisWorkbook.Name

        'ChartMaker.SeriesLimitList.RefreshList(FileArray.Item(0))

        ChartMaker.DebugAutoPlot(NumSeries)
        'SJS 05-08-15 ELIMINATE TEMPLATE CHART
        'CREATE NEW CHART DIRECTLY
        'Me.chtTemplate.Visible = Excel.XlSheetVisibility.xlSheetVisible
        Dim ChartCollections As ArrayList = ChartMaker.ChartSeriesCollections
        Dim LimitCollections As ArrayList = ChartMaker.ChartLimitCollections
        Dim IndexFormatted As Integer = Me.shtFormatted.Index

        'If ChartMaker.GetTypeOfChart = PlotCreator.ChartType.Compare Then
        ChartMaker.CheckForDuplicatNames()

        'SJS 05-08-15 ELIMINATE TEMPLATE CHART
        'CREATE NEW CHART DIRECTLY
        'Dim NewChart As Excel.Chart = CreateNewChartFromTemplate(ChartMaker.PlotName, Me.ThisWorkbook.Sheets(2), Me.ThisWorkbook)
        Dim NewChart As Excel.Chart = PlottingFunctions.CreateTemplateChart(ChartMaker.PlotName, Me.ThisWorkbook, shtFormatted.Name)

        AddPlotSeriesCollectionToChart(NewChart, Me.ThisWorkbook.Sheets(IndexFormatted), CType(ChartCollections(0), PlotSeriesInfoCollection))
        AddLimitsToChart(Me.ThisWorkbook.ActiveChart, Me.ThisWorkbook.Sheets(IndexFormatted), CType(LimitCollections(0), PlotLimitInfoCollection), Me.ThisWorkbook)

        For i As Integer = 1 To ChartCollections.Count - 1
            Dim SeriesCollection As PlotSeriesInfoCollection = CType(ChartCollections(i), PlotSeriesInfoCollection)
            For j As Integer = 0 To SeriesCollection.Count - 1
                AddPlotSeriesToChart(NewChart, Me.ThisWorkbook.Sheets(IndexFormatted), SeriesCollection.Item(j))
            Next
        Next

        'If ChartMaker.ShowDialog() = DialogResult.OK Then


        'Else
        '    For i As Integer = 0 To ChartCollections.Count - 1
        '        ChartMaker.CheckForDuplicatNames()
        '        Dim NewChart As Excel.Chart = CreateNewChartFromTemplate(ChartMaker.PlotName, Me.ThisWorkbook.Sheets(2), Me.ThisWorkbook)
        '        AddPlotSeriesCollectionToChart(NewChart, Me.ThisWorkbook.Sheets(IndexFormatted), CType(ChartCollections(i), PlotSeriesInfoCollection))
        '        AddLimitsToChart(NewChart, Me.ThisWorkbook.Sheets(IndexFormatted), CType(LimitCollections(i), PlotLimitInfoCollection), Me.ThisWorkbook)
        '    Next
        'End If

        'SJS 05-08-15 ELIMINATE TEMPLATE CHART
        'CREATE NEW CHART DIRECTLY
        'Me.chtTemplate.Visible = Excel.XlSheetVisibility.xlSheetVeryHidden
        'End If

    End Sub

    Public Sub AddSeriesToPlot(ByRef aChart As Excel.Chart, ByVal PlotFileType As String)
        Dim FileArray As New TextFileCollection

        'Get all files in data set and store in array
        Try
            StoreTextFilesInArray(FileArray)
        Catch ex As Exception
            MessageBox.Show("No Files, Cannot Make Plot")
            Exit Sub
        End Try


        For Each textfile As TextFileInfo In FileArray
            textfile.GetHeadersForEachSeries()
        Next

        Dim ChartSeriesAdder As AddSeriesForm

        If PlotFileType = "C" Then
            ChartSeriesAdder = New AddSeriesForm(FileArray, AddSeriesForm.PlotType.Compare, aChart)
        Else
            ChartSeriesAdder = New AddSeriesForm(FileArray, AddSeriesForm.PlotType.Stitch, aChart)
        End If

        ChartSeriesAdder.StartPosition = FormStartPosition.Manual
        Dim LocPoint As Point = PointsToPixelsAsPoint(Globals.ThisAddIn.Application.Left, Globals.ThisAddIn.Application.Top)
        LocPoint.Offset(40, 40)

        ChartSeriesAdder.Location = LocPoint
        ChartSeriesAdder.Focus()

        If ChartSeriesAdder.ShowDialog() = DialogResult.OK Then

            Dim ChartCollections As ArrayList = ChartSeriesAdder.ChartSeriesCollections
            Dim LimitCollections As ArrayList = ChartSeriesAdder.ChartLimitCollections
            Dim IndexFormatted As Integer = Me.shtFormatted.Index

            If ChartSeriesAdder.GetTypeOfChart = PlotCreator.ChartType.Compare Then

            Else
                For i As Integer = 0 To ChartCollections.Count - 1
                    AddPlotSeriesCollectionToChart(aChart, Me.ThisWorkbook.Sheets(IndexFormatted), CType(ChartCollections(i), PlotSeriesInfoCollection))
                    AddLimitsToChart(aChart, Me.ThisWorkbook.Sheets(IndexFormatted), CType(LimitCollections(i), PlotLimitInfoCollection), Me.ThisWorkbook)
                Next
            End If

        End If

    End Sub

    Public Sub AddSeriesToPlot(ByRef aChart As Excel.Chart)
        Dim FileArray As New TextFileCollection

        'Get all files in data set and store in array
        Try
            StoreTextFilesInArray(FileArray)
        Catch ex As Exception
            MessageBox.Show("No Files, Cannot Make Plot")
            Exit Sub
        End Try


        For Each textfile As TextFileInfo In FileArray
            textfile.GetHeadersForEachSeries()
        Next

        Dim ChartSeriesAdder As AddSeriesForm

        If Me.DataSheetManager.CellCompareOrStich.Value = "C" Then
            ChartSeriesAdder = New AddSeriesForm(FileArray, AddSeriesForm.PlotType.Compare, aChart)
        Else
            ChartSeriesAdder = New AddSeriesForm(FileArray, AddSeriesForm.PlotType.Stitch, aChart)
        End If

        ChartSeriesAdder.StartPosition = FormStartPosition.Manual
        Dim LocPoint As Point = PointsToPixelsAsPoint(Globals.ThisAddIn.Application.Left, Globals.ThisAddIn.Application.Top)
        LocPoint.Offset(40, 40)

        ChartSeriesAdder.Location = LocPoint
        ChartSeriesAdder.Focus()

        If ChartSeriesAdder.ShowDialog() = DialogResult.OK Then

            Dim ChartCollections As ArrayList = ChartSeriesAdder.ChartSeriesCollections
            Dim LimitCollections As ArrayList = ChartSeriesAdder.ChartLimitCollections
            Dim IndexFormatted As Integer = Me.shtFormatted.Index

            If ChartSeriesAdder.GetTypeOfChart = PlotCreator.ChartType.Compare Then

            Else
                For i As Integer = 0 To ChartCollections.Count - 1
                    AddPlotSeriesCollectionToChart(aChart, Me.ThisWorkbook.Sheets(IndexFormatted), CType(ChartCollections(i), PlotSeriesInfoCollection))
                    AddLimitsToChart(aChart, Me.ThisWorkbook.Sheets(IndexFormatted), CType(LimitCollections(i), PlotLimitInfoCollection), Me.ThisWorkbook)
                Next
            End If

        End If

    End Sub


    Public Sub ModifyChartSeries(ByRef aChart As Excel.Chart)
        Dim SeriesEditForm As New SeriesEditor(aChart)
        SeriesEditForm.StartPosition = FormStartPosition.Manual
        Dim LocPoint As Point = PointsToPixelsAsPoint(Globals.ThisAddIn.Application.Left, Globals.ThisAddIn.Application.Top)

        LocPoint.Offset(40, 40)
        SeriesEditForm.Location = LocPoint
        SeriesEditForm.ShowDialog()

    End Sub

    'Private Sub CreateTemplateChart(ByVal sheetname As String)

    '    If Me.ThisWorkbook.Sheets(2).Name = sheetname Then
    '        Me.chtTemplate = ThisWorkbook.Sheets(2)
    '        Exit Sub
    '    Else
    '        Me.chtTemplate = CreateNewChartSheet(sheetname)
    '        Me.chtTemplate.Move(, ThisWorkbook.Sheets(1))
    '    End If

    '    Me.chtTemplate.ChartType = Excel.XlChartType.xlXYScatterLinesNoMarkers
    '    PlottingFunctions.AddDashedGrayGridLines(Me.chtTemplate)
    '    PlottingFunctions.ChangeChartGlobalFontSize(Me.chtTemplate, 18)
    '    PlottingFunctions.TickMarksInside(Me.chtTemplate)
    '    PlottingFunctions.AddXAxisLabel(Me.chtTemplate, "='" + Me.shtFormatted.Name + "'!$E$2")
    '    PlottingFunctions.AddYAxisLabel(Me.chtTemplate, "='" + Me.shtFormatted.Name + "'!$E$3")

    '    PlottingFunctions.SetPlotAreaPositionAndSize(Me.chtTemplate, 57, 55, 620, 400)
    '    PlottingFunctions.SetLegendPositionAndSize(Me.chtTemplate, 3, 96, 565, 62)

    '    'PlottingFunctions.ChangePlotAreaSize(Me.chtTemplate, 620, 400)
    '    'PlottingFunctions.MovePlotAreaDown(Me.chtTemplate, 50)
    '    'PlottingFunctions.MovePlotAreaRight(Me.chtTemplate, 45)
    '    PlottingFunctions.MoveYaxisLabelLeft(Me.chtTemplate, 20)
    '    PlottingFunctions.MoveXaxisLabelDown(Me.chtTemplate, 7)
    '    PlottingFunctions.SetLegendPositionAndSize(Me.chtTemplate, 3, 90, 565, 62)
    '    PlottingFunctions.XaxisCrossesAt(Me.chtTemplate, -1000)
    '    PlottingFunctions.XaxisNumberFormat(Me.chtTemplate, 0)
    '    PlottingFunctions.YaxisNumberFormat(Me.chtTemplate, 0)
    '    PlottingFunctions.YAxisMinorTicks(Me.chtTemplate, True)
    '    PlottingFunctions.XAxisMinorTicks(Me.chtTemplate, True)


    '    For Each series As Excel.Series In Me.chtTemplate.SeriesCollection
    '        series.Delete()
    '    Next

    '    Me.chtTemplate.Visible = Excel.XlSheetVisibility.xlSheetVeryHidden

    'End Sub

    'SJS 05-08-15 MOVED TO PLOTTINGFUNCTIONS
    'DON'T NEED A WORKBOOK MANAGER TO FORMAT PLOTS
    'THIS WILL ALLOW USE OF PLOT MANAGER EVEN IF YOUR NOT USING 
    'FILEPLOTTING TOOLS AT ALL
    'Public Sub FormatPlots()

    '    Dim PlotManager As New ChartEditor
    '    PlotManager.StartPosition = FormStartPosition.Manual
    '    Dim LocPoint As Point = PointsToPixelsAsPoint(Globals.ThisAddIn.Application.Left, Globals.ThisAddIn.Application.Top)
    '    LocPoint.Offset(40, 40)

    '    PlotManager.Location = LocPoint
    '    PlotManager.Focus()

    '    If PlotManager.ShowDialog = DialogResult.OK Then

    '    End If
    'End Sub

    Sub CreateDebugCase(ListOfFiles As ArrayList, ByVal PlotFileType As String)
        'Set type to compare, and delimitator to space
        'Me.shtDataSheet.Cells(11, 2).Value = PlotFileType
        'Me.shtDataSheet.Cells(12, 2).Value = " "
        Me.DataSheetManager.CellCompareOrStich.Value = PlotFileType
        Me.DataSheetManager.CellDelimiter.Value = " "

        'add list of files to sheet
        For i As Integer = 0 To ListOfFiles.Count - 1
            'Me.shtDataSheet.Cells(i + 10, 3).value = ListOfFiles.Item(i)
            Me.DataSheetManager.CellFirstFileName.Offset(i).Value = ListOfFiles.Item(i)
        Next

        UpdateDataForGroup(False)

    End Sub

    Private Sub UpdateChartSeriesRanges()
        'SJS 05-28-15 CHANGE START OF LOOP TO 1 FROM 2
        'FIXED BUG AFTER HIDDEN TEMPLATE CHART WAS REMOVED
        For i As Integer = 1 To Me.ThisWorkbook.Charts.Count
            'SJS 07-15-15 Some exceptions get thrown when trying to update chart series ranges
            Dim thechart As Excel.Chart = Me.ThisWorkbook.Charts(i)
            'MessageBox.Show(thechart.Name)
            Try
                PlottingFunctions.ChangeSeriesRanges(Me.ThisWorkbook.Charts(i), Me.ThisWorkbook)
            Catch ex As Exception
                MessageBox.Show(ex.ToString)
            End Try

        Next
    End Sub

    Public Sub ImportHeatingFiles()
        Dim HeatDialog As New ImportHeating()
        If HeatDialog.ShowDialog = DialogResult.OK Then
            Dim Heating As New HeatingFileInfo(HeatDialog.FileName)
            Heating.ReadFileIntoClipBoard()

        End If

        Dim HeatSheet As Excel.Worksheet = CreateNewWorksheet("EnvHeat " + HeatDialog.FileName.Substring(HeatDialog.FileName.LastIndexOf("\") + 1))

        Dim PasteCell As Excel.Range = HeatSheet.Range("A1")

        PasteCell.PasteSpecial()


    End Sub

    Public Sub UpdateWorkbookVersion(ByVal lastVersion As Double, ByVal targetVersion As Double)

        ' Convert 1.0 or 1.1 workbook into version 2.0
        If (lastVersion = 1.1 Or lastVersion = 1.0) Then
            ' The only required modification is to delete the template chart, and update
            ' the version of the current sheet.
            For Each theChart As Excel.Chart In ThisWorkbook.Charts
                If theChart.Name = "chtTemplate" Then
                    theChart.Visible = Excel.XlSheetVisibility.xlSheetVisible
                    ThisWorkbook.Application.DisplayAlerts = False
                    theChart.Delete()
                    ThisWorkbook.Application.DisplayAlerts = True
                End If
            Next

            Me.DataSheetManager.CellFilePlotterVersion.Value = 2.0
            Globals.ThisAddIn.Application.StatusBar = "Converted to FPT2.0"
            Globals.ThisAddIn.Application.StatusBar = False
        End If

        ' Clear rows 20 to 26 in shtImport sheet and update to version 3.1
        If (lastVersion >= 2.0 And lastVersion < 3.1) Then
            ' Clear rows 20 to 26 in shtImport sheet
            Me.shtImport.Rows("20:26").Clear()
            Me.shtFormatted.Range("A1:XFD26").Clear()
            FillInFormattedSht()

            'This is to update formatted sheet when an workbook with and older version of FilePlottingTool is used
            'This is required if someone pressed the Import Only the formatted sheet will not be formatted correctly
            Me.UpdateDataForGroup(True, True, True)

            ' Update to version 3.1
            Me.DataSheetManager.CellFilePlotterVersion.Value = 3.1

            ' Call UpdateChartSeriesRanges for each chart in the workbook
            For Each theChart As Excel.Chart In ThisWorkbook.Charts
                Dim newFormula As String
                newFormula = UpdateChartRangeVersion(theChart)


                'This is a parse function and increment that was used to test the parsing 

                'UpdateChartRangesVersion(theChart, ThisWorkbook)
                'For Each chart_series As Excel.Series In theChart.SeriesCollection
                '    ' Call SplitFormattedDataValues and display the result
                '    Dim formula As String
                '    Dim splitValues() As String

                '    formula = chart_series.Formula
                '    splitValues = SplitFormattedDataValues(formula)

                '    If Not splitValues Is Nothing Then
                '        Dim result As String
                '        result = "Split values for the formula:" & vbCrLf

                '        For i = LBound(splitValues) To UBound(splitValues)
                '            result = result & "Value " & i & ": " & splitValues(i) & vbCrLf
                '        Next i

                '        'MsgBox(result)
                '    Else
                '        'MsgBox("No 'Formatted Data' found in the formula")
                '    End If
                'Next

            Next


            Globals.ThisAddIn.Application.StatusBar = "Converted to FPT3.1"
            Globals.ThisAddIn.Application.StatusBar = False
        End If
    End Sub

    Public Sub FixTTLTimeColumnLetter(ByVal TimeColNumber)
        'This function modifies the the time columns for the TTL function
        'makes sure the TTL function references the time column for the specific file
        Dim ColLetter As String = PlottingFunctions.GetExcelColumnName(TimeColNumber)
        'Hardcoded cell value for the first TTL formula, in row 17, and the column after the time column
        Dim TTLCell As Excel.Range = shtFormatted.Cells(17, TimeColNumber + 1)
        'Formula that needs to be modified:
        '"=TTL(B$10:B$13,$A$20:$A$1048576,B$20:B$1048576,$E$5)"
        Dim TTLCellFormula As String = TTLCell.Formula
        'Replace the first part of the time range with the new time column
        TTLCellFormula = TTLCellFormula.Replace(",$A$", ",$" + ColLetter + "$")
        'Replace the second part of the time range with the new time column
        TTLCellFormula = TTLCellFormula.Replace(":$A$", ":$" + ColLetter + "$")
        TTLCell.Formula = TTLCellFormula
    End Sub

End Class

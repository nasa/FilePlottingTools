﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ChartEditor
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.lstFiles = New System.Windows.Forms.ListBox()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.rdbYTickPosNoChange = New System.Windows.Forms.RadioButton()
        Me.rdbYTickPosCross = New System.Windows.Forms.RadioButton()
        Me.rdbYTickPosOutside = New System.Windows.Forms.RadioButton()
        Me.rdbYTickPosInside = New System.Windows.Forms.RadioButton()
        Me.chkYMinorTicks = New System.Windows.Forms.CheckBox()
        Me.chkAutoYMinorTicks = New System.Windows.Forms.CheckBox()
        Me.chkAutoYMajorTicks = New System.Windows.Forms.CheckBox()
        Me.txtYMinorTicks = New System.Windows.Forms.TextBox()
        Me.txtYMajorTicks = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.rdbXTickPosNoChange = New System.Windows.Forms.RadioButton()
        Me.rdbXTickPosCross = New System.Windows.Forms.RadioButton()
        Me.rdbXTickPosOutside = New System.Windows.Forms.RadioButton()
        Me.rdbXTickPosInside = New System.Windows.Forms.RadioButton()
        Me.chkXMinorTicks = New System.Windows.Forms.CheckBox()
        Me.chkAutoXMinorTicks = New System.Windows.Forms.CheckBox()
        Me.chkAutoXMajorTicks = New System.Windows.Forms.CheckBox()
        Me.txtXMinorTicks = New System.Windows.Forms.TextBox()
        Me.txtXMajorTicks = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.chkYAutoScale = New System.Windows.Forms.CheckBox()
        Me.chkYlimSameForAll = New System.Windows.Forms.CheckBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtYlimMax = New System.Windows.Forms.TextBox()
        Me.txtYlimMin = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chkXAutoScale = New System.Windows.Forms.CheckBox()
        Me.chkXlimSameForAll = New System.Windows.Forms.CheckBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtXlimMax = New System.Windows.Forms.TextBox()
        Me.txtXlimMin = New System.Windows.Forms.TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtYLabelFontSize = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtSizeTitle = New System.Windows.Forms.TextBox()
        Me.txtGlobalFontSize = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtXLabelFontSize = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtLegendFontSize = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtXAxisFontSize = New System.Windows.Forms.TextBox()
        Me.txtYAxisFontSize = New System.Windows.Forms.TextBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel6 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel5 = New System.Windows.Forms.TableLayoutPanel()
        Me.rdbTitleYes = New System.Windows.Forms.RadioButton()
        Me.rdbTitleNo = New System.Windows.Forms.RadioButton()
        Me.rdbTitleNoChange = New System.Windows.Forms.RadioButton()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtLegendWidth = New System.Windows.Forms.TextBox()
        Me.txtLegendHeight = New System.Windows.Forms.TextBox()
        Me.chkTopLegend = New System.Windows.Forms.CheckBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.chkRightLegend = New System.Windows.Forms.CheckBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.chkXGridNone = New System.Windows.Forms.CheckBox()
        Me.chkYGridNone = New System.Windows.Forms.CheckBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.rdbXGridNoChange = New System.Windows.Forms.RadioButton()
        Me.rdbXGridDash = New System.Windows.Forms.RadioButton()
        Me.rdbXGridSolid = New System.Windows.Forms.RadioButton()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.rdbYGridNoChange = New System.Windows.Forms.RadioButton()
        Me.rdbYGridDash = New System.Windows.Forms.RadioButton()
        Me.rdbYGridSolid = New System.Windows.Forms.RadioButton()
        Me.chkXGridMinor = New System.Windows.Forms.CheckBox()
        Me.chkYGridMinor = New System.Windows.Forms.CheckBox()
        Me.chkXGridMajor = New System.Windows.Forms.CheckBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.chkYGridMajor = New System.Windows.Forms.CheckBox()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.btnFormatSeries = New System.Windows.Forms.Button()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.btnOk = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnApply = New System.Windows.Forms.Button()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.TableLayoutPanel6.SuspendLayout()
        Me.TableLayoutPanel5.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.IsSplitterFixed = True
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Margin = New System.Windows.Forms.Padding(4)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.lstFiles)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.SplitContainer2)
        Me.SplitContainer1.Size = New System.Drawing.Size(851, 745)
        Me.SplitContainer1.SplitterDistance = 252
        Me.SplitContainer1.SplitterWidth = 5
        Me.SplitContainer1.TabIndex = 0
        '
        'lstFiles
        '
        Me.lstFiles.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lstFiles.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lstFiles.FormattingEnabled = True
        Me.lstFiles.ItemHeight = 16
        Me.lstFiles.Location = New System.Drawing.Point(0, 0)
        Me.lstFiles.Margin = New System.Windows.Forms.Padding(4)
        Me.lstFiles.Name = "lstFiles"
        Me.lstFiles.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.lstFiles.Size = New System.Drawing.Size(252, 745)
        Me.lstFiles.TabIndex = 0
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel2
        Me.SplitContainer2.IsSplitterFixed = True
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Margin = New System.Windows.Forms.Padding(4)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.AutoScroll = True
        Me.SplitContainer2.Panel1.Controls.Add(Me.TableLayoutPanel2)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.Panel3)
        Me.SplitContainer2.Size = New System.Drawing.Size(594, 745)
        Me.SplitContainer2.SplitterDistance = 690
        Me.SplitContainer2.SplitterWidth = 5
        Me.SplitContainer2.TabIndex = 0
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.AutoScroll = True
        Me.TableLayoutPanel2.ColumnCount = 1
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.GroupBox5, 0, 6)
        Me.TableLayoutPanel2.Controls.Add(Me.GroupBox4, 0, 5)
        Me.TableLayoutPanel2.Controls.Add(Me.GroupBox2, 0, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.GroupBox1, 0, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.GroupBox3, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.GroupBox7, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.GroupBox6, 0, 7)
        Me.TableLayoutPanel2.Controls.Add(Me.GroupBox8, 0, 8)
        Me.TableLayoutPanel2.Controls.Add(Me.GroupBox9, 0, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.Padding = New System.Windows.Forms.Padding(0, 0, 27, 0)
        Me.TableLayoutPanel2.RowCount = 9
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 246.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 197.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 148.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 148.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 148.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 148.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(594, 690)
        Me.TableLayoutPanel2.TabIndex = 11
        '
        'GroupBox5
        '
        Me.GroupBox5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox5.Controls.Add(Me.Label23)
        Me.GroupBox5.Controls.Add(Me.rdbYTickPosNoChange)
        Me.GroupBox5.Controls.Add(Me.rdbYTickPosCross)
        Me.GroupBox5.Controls.Add(Me.rdbYTickPosOutside)
        Me.GroupBox5.Controls.Add(Me.rdbYTickPosInside)
        Me.GroupBox5.Controls.Add(Me.chkYMinorTicks)
        Me.GroupBox5.Controls.Add(Me.chkAutoYMinorTicks)
        Me.GroupBox5.Controls.Add(Me.chkAutoYMajorTicks)
        Me.GroupBox5.Controls.Add(Me.txtYMinorTicks)
        Me.GroupBox5.Controls.Add(Me.txtYMajorTicks)
        Me.GroupBox5.Controls.Add(Me.Label14)
        Me.GroupBox5.Controls.Add(Me.Label15)
        Me.GroupBox5.Location = New System.Drawing.Point(4, 901)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox5.Size = New System.Drawing.Size(538, 140)
        Me.GroupBox5.TabIndex = 8
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Y Axis Tick Marks"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(11, 97)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(119, 17)
        Me.Label23.TabIndex = 19
        Me.Label23.Text = "TickMark Position"
        '
        'rdbYTickPosNoChange
        '
        Me.rdbYTickPosNoChange.AutoSize = True
        Me.rdbYTickPosNoChange.Checked = True
        Me.rdbYTickPosNoChange.Location = New System.Drawing.Point(362, 95)
        Me.rdbYTickPosNoChange.Name = "rdbYTickPosNoChange"
        Me.rdbYTickPosNoChange.Size = New System.Drawing.Size(100, 21)
        Me.rdbYTickPosNoChange.TabIndex = 18
        Me.rdbYTickPosNoChange.TabStop = True
        Me.rdbYTickPosNoChange.Text = "No Change"
        Me.rdbYTickPosNoChange.UseVisualStyleBackColor = True
        '
        'rdbYTickPosCross
        '
        Me.rdbYTickPosCross.AutoSize = True
        Me.rdbYTickPosCross.Location = New System.Drawing.Point(291, 95)
        Me.rdbYTickPosCross.Name = "rdbYTickPosCross"
        Me.rdbYTickPosCross.Size = New System.Drawing.Size(65, 21)
        Me.rdbYTickPosCross.TabIndex = 17
        Me.rdbYTickPosCross.Text = "Cross"
        Me.rdbYTickPosCross.UseVisualStyleBackColor = True
        '
        'rdbYTickPosOutside
        '
        Me.rdbYTickPosOutside.AutoSize = True
        Me.rdbYTickPosOutside.Location = New System.Drawing.Point(207, 95)
        Me.rdbYTickPosOutside.Name = "rdbYTickPosOutside"
        Me.rdbYTickPosOutside.Size = New System.Drawing.Size(78, 21)
        Me.rdbYTickPosOutside.TabIndex = 16
        Me.rdbYTickPosOutside.Text = "Outside"
        Me.rdbYTickPosOutside.UseVisualStyleBackColor = True
        '
        'rdbYTickPosInside
        '
        Me.rdbYTickPosInside.AutoSize = True
        Me.rdbYTickPosInside.Location = New System.Drawing.Point(136, 95)
        Me.rdbYTickPosInside.Name = "rdbYTickPosInside"
        Me.rdbYTickPosInside.Size = New System.Drawing.Size(66, 21)
        Me.rdbYTickPosInside.TabIndex = 15
        Me.rdbYTickPosInside.Text = "Inside"
        Me.rdbYTickPosInside.UseVisualStyleBackColor = True
        '
        'chkYMinorTicks
        '
        Me.chkYMinorTicks.AutoSize = True
        Me.chkYMinorTicks.Location = New System.Drawing.Point(331, 60)
        Me.chkYMinorTicks.Margin = New System.Windows.Forms.Padding(4)
        Me.chkYMinorTicks.Name = "chkYMinorTicks"
        Me.chkYMinorTicks.Size = New System.Drawing.Size(64, 21)
        Me.chkYMinorTicks.TabIndex = 10
        Me.chkYMinorTicks.Text = "None"
        Me.chkYMinorTicks.UseVisualStyleBackColor = True
        '
        'chkAutoYMinorTicks
        '
        Me.chkAutoYMinorTicks.AutoSize = True
        Me.chkAutoYMinorTicks.Location = New System.Drawing.Point(236, 62)
        Me.chkAutoYMinorTicks.Margin = New System.Windows.Forms.Padding(4)
        Me.chkAutoYMinorTicks.Name = "chkAutoYMinorTicks"
        Me.chkAutoYMinorTicks.Size = New System.Drawing.Size(59, 21)
        Me.chkAutoYMinorTicks.TabIndex = 8
        Me.chkAutoYMinorTicks.Text = "Auto"
        Me.chkAutoYMinorTicks.UseVisualStyleBackColor = True
        '
        'chkAutoYMajorTicks
        '
        Me.chkAutoYMajorTicks.AutoSize = True
        Me.chkAutoYMajorTicks.Location = New System.Drawing.Point(236, 30)
        Me.chkAutoYMajorTicks.Margin = New System.Windows.Forms.Padding(4)
        Me.chkAutoYMajorTicks.Name = "chkAutoYMajorTicks"
        Me.chkAutoYMajorTicks.Size = New System.Drawing.Size(59, 21)
        Me.chkAutoYMajorTicks.TabIndex = 7
        Me.chkAutoYMajorTicks.Text = "Auto"
        Me.chkAutoYMajorTicks.UseVisualStyleBackColor = True
        '
        'txtYMinorTicks
        '
        Me.txtYMinorTicks.Location = New System.Drawing.Point(61, 58)
        Me.txtYMinorTicks.Margin = New System.Windows.Forms.Padding(4)
        Me.txtYMinorTicks.Name = "txtYMinorTicks"
        Me.txtYMinorTicks.Size = New System.Drawing.Size(165, 22)
        Me.txtYMinorTicks.TabIndex = 3
        '
        'txtYMajorTicks
        '
        Me.txtYMajorTicks.Location = New System.Drawing.Point(61, 27)
        Me.txtYMajorTicks.Margin = New System.Windows.Forms.Padding(4)
        Me.txtYMajorTicks.Name = "txtYMajorTicks"
        Me.txtYMajorTicks.Size = New System.Drawing.Size(165, 22)
        Me.txtYMajorTicks.TabIndex = 2
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(9, 62)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(43, 17)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "Minor"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(9, 31)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(43, 17)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "Major"
        '
        'GroupBox4
        '
        Me.GroupBox4.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox4.Controls.Add(Me.Label22)
        Me.GroupBox4.Controls.Add(Me.rdbXTickPosNoChange)
        Me.GroupBox4.Controls.Add(Me.rdbXTickPosCross)
        Me.GroupBox4.Controls.Add(Me.rdbXTickPosOutside)
        Me.GroupBox4.Controls.Add(Me.rdbXTickPosInside)
        Me.GroupBox4.Controls.Add(Me.chkXMinorTicks)
        Me.GroupBox4.Controls.Add(Me.chkAutoXMinorTicks)
        Me.GroupBox4.Controls.Add(Me.chkAutoXMajorTicks)
        Me.GroupBox4.Controls.Add(Me.txtXMinorTicks)
        Me.GroupBox4.Controls.Add(Me.txtXMajorTicks)
        Me.GroupBox4.Controls.Add(Me.Label13)
        Me.GroupBox4.Controls.Add(Me.Label12)
        Me.GroupBox4.Location = New System.Drawing.Point(4, 753)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox4.Size = New System.Drawing.Size(538, 140)
        Me.GroupBox4.TabIndex = 7
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "X Axis Tick Marks"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(11, 100)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(119, 17)
        Me.Label22.TabIndex = 14
        Me.Label22.Text = "TickMark Position"
        '
        'rdbXTickPosNoChange
        '
        Me.rdbXTickPosNoChange.AutoSize = True
        Me.rdbXTickPosNoChange.Checked = True
        Me.rdbXTickPosNoChange.Location = New System.Drawing.Point(362, 98)
        Me.rdbXTickPosNoChange.Name = "rdbXTickPosNoChange"
        Me.rdbXTickPosNoChange.Size = New System.Drawing.Size(100, 21)
        Me.rdbXTickPosNoChange.TabIndex = 13
        Me.rdbXTickPosNoChange.TabStop = True
        Me.rdbXTickPosNoChange.Text = "No Change"
        Me.rdbXTickPosNoChange.UseVisualStyleBackColor = True
        '
        'rdbXTickPosCross
        '
        Me.rdbXTickPosCross.AutoSize = True
        Me.rdbXTickPosCross.Location = New System.Drawing.Point(291, 98)
        Me.rdbXTickPosCross.Name = "rdbXTickPosCross"
        Me.rdbXTickPosCross.Size = New System.Drawing.Size(65, 21)
        Me.rdbXTickPosCross.TabIndex = 12
        Me.rdbXTickPosCross.Text = "Cross"
        Me.rdbXTickPosCross.UseVisualStyleBackColor = True
        '
        'rdbXTickPosOutside
        '
        Me.rdbXTickPosOutside.AutoSize = True
        Me.rdbXTickPosOutside.Location = New System.Drawing.Point(207, 98)
        Me.rdbXTickPosOutside.Name = "rdbXTickPosOutside"
        Me.rdbXTickPosOutside.Size = New System.Drawing.Size(78, 21)
        Me.rdbXTickPosOutside.TabIndex = 11
        Me.rdbXTickPosOutside.Text = "Outside"
        Me.rdbXTickPosOutside.UseVisualStyleBackColor = True
        '
        'rdbXTickPosInside
        '
        Me.rdbXTickPosInside.AutoSize = True
        Me.rdbXTickPosInside.Location = New System.Drawing.Point(136, 98)
        Me.rdbXTickPosInside.Name = "rdbXTickPosInside"
        Me.rdbXTickPosInside.Size = New System.Drawing.Size(66, 21)
        Me.rdbXTickPosInside.TabIndex = 10
        Me.rdbXTickPosInside.Text = "Inside"
        Me.rdbXTickPosInside.UseVisualStyleBackColor = True
        '
        'chkXMinorTicks
        '
        Me.chkXMinorTicks.AutoSize = True
        Me.chkXMinorTicks.Location = New System.Drawing.Point(336, 62)
        Me.chkXMinorTicks.Margin = New System.Windows.Forms.Padding(4)
        Me.chkXMinorTicks.Name = "chkXMinorTicks"
        Me.chkXMinorTicks.Size = New System.Drawing.Size(64, 21)
        Me.chkXMinorTicks.TabIndex = 9
        Me.chkXMinorTicks.Text = "None"
        Me.chkXMinorTicks.UseVisualStyleBackColor = True
        '
        'chkAutoXMinorTicks
        '
        Me.chkAutoXMinorTicks.AutoSize = True
        Me.chkAutoXMinorTicks.Location = New System.Drawing.Point(236, 62)
        Me.chkAutoXMinorTicks.Margin = New System.Windows.Forms.Padding(4)
        Me.chkAutoXMinorTicks.Name = "chkAutoXMinorTicks"
        Me.chkAutoXMinorTicks.Size = New System.Drawing.Size(59, 21)
        Me.chkAutoXMinorTicks.TabIndex = 8
        Me.chkAutoXMinorTicks.Text = "Auto"
        Me.chkAutoXMinorTicks.UseVisualStyleBackColor = True
        '
        'chkAutoXMajorTicks
        '
        Me.chkAutoXMajorTicks.AutoSize = True
        Me.chkAutoXMajorTicks.Location = New System.Drawing.Point(236, 31)
        Me.chkAutoXMajorTicks.Margin = New System.Windows.Forms.Padding(4)
        Me.chkAutoXMajorTicks.Name = "chkAutoXMajorTicks"
        Me.chkAutoXMajorTicks.Size = New System.Drawing.Size(59, 21)
        Me.chkAutoXMajorTicks.TabIndex = 7
        Me.chkAutoXMajorTicks.Text = "Auto"
        Me.chkAutoXMajorTicks.UseVisualStyleBackColor = True
        '
        'txtXMinorTicks
        '
        Me.txtXMinorTicks.Location = New System.Drawing.Point(61, 58)
        Me.txtXMinorTicks.Margin = New System.Windows.Forms.Padding(4)
        Me.txtXMinorTicks.Name = "txtXMinorTicks"
        Me.txtXMinorTicks.Size = New System.Drawing.Size(165, 22)
        Me.txtXMinorTicks.TabIndex = 3
        '
        'txtXMajorTicks
        '
        Me.txtXMajorTicks.Location = New System.Drawing.Point(61, 27)
        Me.txtXMajorTicks.Margin = New System.Windows.Forms.Padding(4)
        Me.txtXMajorTicks.Name = "txtXMajorTicks"
        Me.txtXMajorTicks.Size = New System.Drawing.Size(165, 22)
        Me.txtXMajorTicks.TabIndex = 2
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(9, 62)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(43, 17)
        Me.Label13.TabIndex = 1
        Me.Label13.Text = "Minor"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(9, 31)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(43, 17)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "Major"
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.chkYAutoScale)
        Me.GroupBox2.Controls.Add(Me.chkYlimSameForAll)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.txtYlimMax)
        Me.GroupBox2.Controls.Add(Me.txtYlimMin)
        Me.GroupBox2.Location = New System.Drawing.Point(4, 605)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Size = New System.Drawing.Size(538, 140)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Y Axis Properties"
        '
        'chkYAutoScale
        '
        Me.chkYAutoScale.AutoSize = True
        Me.chkYAutoScale.Location = New System.Drawing.Point(277, 95)
        Me.chkYAutoScale.Margin = New System.Windows.Forms.Padding(4)
        Me.chkYAutoScale.Name = "chkYAutoScale"
        Me.chkYAutoScale.Size = New System.Drawing.Size(117, 21)
        Me.chkYAutoScale.TabIndex = 6
        Me.chkYAutoScale.Text = "Auto Scale All"
        Me.chkYAutoScale.UseVisualStyleBackColor = True
        '
        'chkYlimSameForAll
        '
        Me.chkYlimSameForAll.AutoSize = True
        Me.chkYlimSameForAll.Location = New System.Drawing.Point(13, 95)
        Me.chkYlimSameForAll.Margin = New System.Windows.Forms.Padding(4)
        Me.chkYlimSameForAll.Name = "chkYlimSameForAll"
        Me.chkYlimSameForAll.Size = New System.Drawing.Size(189, 21)
        Me.chkYlimSameForAll.TabIndex = 4
        Me.chkYlimSameForAll.Text = "Same Scale For Selected"
        Me.chkYlimSameForAll.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(9, 63)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(33, 17)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Max"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(9, 31)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(30, 17)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Min"
        '
        'txtYlimMax
        '
        Me.txtYlimMax.Location = New System.Drawing.Point(49, 59)
        Me.txtYlimMax.Margin = New System.Windows.Forms.Padding(4)
        Me.txtYlimMax.Name = "txtYlimMax"
        Me.txtYlimMax.Size = New System.Drawing.Size(264, 22)
        Me.txtYlimMax.TabIndex = 1
        '
        'txtYlimMin
        '
        Me.txtYlimMin.Location = New System.Drawing.Point(49, 27)
        Me.txtYlimMin.Margin = New System.Windows.Forms.Padding(4)
        Me.txtYlimMin.Name = "txtYlimMin"
        Me.txtYlimMin.Size = New System.Drawing.Size(264, 22)
        Me.txtYlimMin.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.chkXAutoScale)
        Me.GroupBox1.Controls.Add(Me.chkXlimSameForAll)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtXlimMax)
        Me.GroupBox1.Controls.Add(Me.txtXlimMin)
        Me.GroupBox1.Location = New System.Drawing.Point(4, 457)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(538, 140)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "X Axis Properties"
        '
        'chkXAutoScale
        '
        Me.chkXAutoScale.AutoSize = True
        Me.chkXAutoScale.Location = New System.Drawing.Point(277, 95)
        Me.chkXAutoScale.Margin = New System.Windows.Forms.Padding(4)
        Me.chkXAutoScale.Name = "chkXAutoScale"
        Me.chkXAutoScale.Size = New System.Drawing.Size(117, 21)
        Me.chkXAutoScale.TabIndex = 5
        Me.chkXAutoScale.Text = "Auto Scale All"
        Me.chkXAutoScale.UseVisualStyleBackColor = True
        '
        'chkXlimSameForAll
        '
        Me.chkXlimSameForAll.AutoSize = True
        Me.chkXlimSameForAll.Location = New System.Drawing.Point(11, 95)
        Me.chkXlimSameForAll.Margin = New System.Windows.Forms.Padding(4)
        Me.chkXlimSameForAll.Name = "chkXlimSameForAll"
        Me.chkXlimSameForAll.Size = New System.Drawing.Size(189, 21)
        Me.chkXlimSameForAll.TabIndex = 4
        Me.chkXlimSameForAll.Text = "Same Scale For Selected"
        Me.chkXlimSameForAll.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(9, 63)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(33, 17)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Max"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(9, 31)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(30, 17)
        Me.Label1.TabIndex = 100
        Me.Label1.Text = "Min"
        '
        'txtXlimMax
        '
        Me.txtXlimMax.Location = New System.Drawing.Point(49, 59)
        Me.txtXlimMax.Margin = New System.Windows.Forms.Padding(4)
        Me.txtXlimMax.Name = "txtXlimMax"
        Me.txtXlimMax.Size = New System.Drawing.Size(213, 22)
        Me.txtXlimMax.TabIndex = 1
        '
        'txtXlimMin
        '
        Me.txtXlimMin.Location = New System.Drawing.Point(49, 27)
        Me.txtXlimMin.Margin = New System.Windows.Forms.Padding(4)
        Me.txtXlimMin.Name = "txtXlimMin"
        Me.txtXlimMin.Size = New System.Drawing.Size(213, 22)
        Me.txtXlimMin.TabIndex = 0
        '
        'GroupBox3
        '
        Me.GroupBox3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox3.Controls.Add(Me.TableLayoutPanel3)
        Me.GroupBox3.Location = New System.Drawing.Point(4, 14)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox3.Size = New System.Drawing.Size(538, 238)
        Me.GroupBox3.TabIndex = 6
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Font Sizes"
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.ColumnCount = 2
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.Label6, 0, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.txtYLabelFontSize, 1, 5)
        Me.TableLayoutPanel3.Controls.Add(Me.Label10, 0, 5)
        Me.TableLayoutPanel3.Controls.Add(Me.txtSizeTitle, 1, 6)
        Me.TableLayoutPanel3.Controls.Add(Me.txtGlobalFontSize, 1, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.Label19, 0, 6)
        Me.TableLayoutPanel3.Controls.Add(Me.Label8, 0, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.Label7, 0, 4)
        Me.TableLayoutPanel3.Controls.Add(Me.txtXLabelFontSize, 1, 3)
        Me.TableLayoutPanel3.Controls.Add(Me.Label9, 0, 3)
        Me.TableLayoutPanel3.Controls.Add(Me.txtLegendFontSize, 1, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.Label5, 0, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.txtXAxisFontSize, 1, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.txtYAxisFontSize, 1, 4)
        Me.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(4, 19)
        Me.TableLayoutPanel3.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 7
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28572!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28572!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28572!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28572!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28572!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28572!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28572!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(530, 215)
        Me.TableLayoutPanel3.TabIndex = 12
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(4, 6)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(112, 17)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "Global Font Size"
        '
        'txtYLabelFontSize
        '
        Me.txtYLabelFontSize.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtYLabelFontSize.Location = New System.Drawing.Point(204, 154)
        Me.txtYLabelFontSize.Margin = New System.Windows.Forms.Padding(4)
        Me.txtYLabelFontSize.Name = "txtYLabelFontSize"
        Me.txtYLabelFontSize.Size = New System.Drawing.Size(297, 22)
        Me.txtYLabelFontSize.TabIndex = 5
        '
        'Label10
        '
        Me.Label10.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(4, 156)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(110, 17)
        Me.Label10.TabIndex = 11
        Me.Label10.Text = "Ylabel Font Size"
        '
        'txtSizeTitle
        '
        Me.txtSizeTitle.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtSizeTitle.Location = New System.Drawing.Point(203, 186)
        Me.txtSizeTitle.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtSizeTitle.Name = "txtSizeTitle"
        Me.txtSizeTitle.Size = New System.Drawing.Size(299, 22)
        Me.txtSizeTitle.TabIndex = 22
        '
        'txtGlobalFontSize
        '
        Me.txtGlobalFontSize.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtGlobalFontSize.Location = New System.Drawing.Point(204, 4)
        Me.txtGlobalFontSize.Margin = New System.Windows.Forms.Padding(4)
        Me.txtGlobalFontSize.Name = "txtGlobalFontSize"
        Me.txtGlobalFontSize.Size = New System.Drawing.Size(297, 22)
        Me.txtGlobalFontSize.TabIndex = 0
        '
        'Label19
        '
        Me.Label19.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(3, 189)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(66, 17)
        Me.Label19.TabIndex = 21
        Me.Label19.Text = "Title Size"
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(4, 36)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(119, 17)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Legend Font Size"
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(4, 126)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(101, 17)
        Me.Label7.TabIndex = 5
        Me.Label7.Text = "Ytick Font Size"
        '
        'txtXLabelFontSize
        '
        Me.txtXLabelFontSize.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtXLabelFontSize.Location = New System.Drawing.Point(204, 94)
        Me.txtXLabelFontSize.Margin = New System.Windows.Forms.Padding(4)
        Me.txtXLabelFontSize.Name = "txtXLabelFontSize"
        Me.txtXLabelFontSize.Size = New System.Drawing.Size(297, 22)
        Me.txtXLabelFontSize.TabIndex = 3
        '
        'Label9
        '
        Me.Label9.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(4, 96)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(110, 17)
        Me.Label9.TabIndex = 9
        Me.Label9.Text = "Xlabel Font Size"
        '
        'txtLegendFontSize
        '
        Me.txtLegendFontSize.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtLegendFontSize.Location = New System.Drawing.Point(204, 34)
        Me.txtLegendFontSize.Margin = New System.Windows.Forms.Padding(4)
        Me.txtLegendFontSize.Name = "txtLegendFontSize"
        Me.txtLegendFontSize.Size = New System.Drawing.Size(297, 22)
        Me.txtLegendFontSize.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(4, 66)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(101, 17)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "Xtick Font Size"
        '
        'txtXAxisFontSize
        '
        Me.txtXAxisFontSize.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtXAxisFontSize.Location = New System.Drawing.Point(204, 64)
        Me.txtXAxisFontSize.Margin = New System.Windows.Forms.Padding(4)
        Me.txtXAxisFontSize.Name = "txtXAxisFontSize"
        Me.txtXAxisFontSize.Size = New System.Drawing.Size(297, 22)
        Me.txtXAxisFontSize.TabIndex = 2
        '
        'txtYAxisFontSize
        '
        Me.txtYAxisFontSize.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtYAxisFontSize.Location = New System.Drawing.Point(204, 124)
        Me.txtYAxisFontSize.Margin = New System.Windows.Forms.Padding(4)
        Me.txtYAxisFontSize.Name = "txtYAxisFontSize"
        Me.txtYAxisFontSize.Size = New System.Drawing.Size(297, 22)
        Me.txtYAxisFontSize.TabIndex = 4
        '
        'GroupBox7
        '
        Me.GroupBox7.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox7.Controls.Add(Me.TableLayoutPanel6)
        Me.GroupBox7.Location = New System.Drawing.Point(4, 260)
        Me.GroupBox7.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox7.Size = New System.Drawing.Size(538, 189)
        Me.GroupBox7.TabIndex = 7
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Legend and Title"
        '
        'TableLayoutPanel6
        '
        Me.TableLayoutPanel6.ColumnCount = 1
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel6.Controls.Add(Me.Label11, 0, 0)
        Me.TableLayoutPanel6.Controls.Add(Me.TableLayoutPanel5, 0, 3)
        Me.TableLayoutPanel6.Controls.Add(Me.TableLayoutPanel4, 0, 1)
        Me.TableLayoutPanel6.Controls.Add(Me.Label18, 0, 2)
        Me.TableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel6.Location = New System.Drawing.Point(4, 19)
        Me.TableLayoutPanel6.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel6.Name = "TableLayoutPanel6"
        Me.TableLayoutPanel6.RowCount = 4
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 74.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37.0!))
        Me.TableLayoutPanel6.Size = New System.Drawing.Size(530, 166)
        Me.TableLayoutPanel6.TabIndex = 29
        '
        'Label11
        '
        Me.Label11.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(4, 4)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(170, 17)
        Me.Label11.TabIndex = 12
        Me.Label11.Text = "Legend Position And Size"
        '
        'TableLayoutPanel5
        '
        Me.TableLayoutPanel5.ColumnCount = 3
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 133.0!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 133.0!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 256.0!))
        Me.TableLayoutPanel5.Controls.Add(Me.rdbTitleYes, 0, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.rdbTitleNo, 1, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.rdbTitleNoChange, 2, 0)
        Me.TableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel5.Location = New System.Drawing.Point(4, 128)
        Me.TableLayoutPanel5.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
        Me.TableLayoutPanel5.RowCount = 1
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel5.Size = New System.Drawing.Size(522, 34)
        Me.TableLayoutPanel5.TabIndex = 28
        '
        'rdbTitleYes
        '
        Me.rdbTitleYes.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.rdbTitleYes.AutoSize = True
        Me.rdbTitleYes.Location = New System.Drawing.Point(3, 6)
        Me.rdbTitleYes.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.rdbTitleYes.Name = "rdbTitleYes"
        Me.rdbTitleYes.Size = New System.Drawing.Size(53, 21)
        Me.rdbTitleYes.TabIndex = 17
        Me.rdbTitleYes.Text = "Yes"
        Me.rdbTitleYes.UseVisualStyleBackColor = True
        '
        'rdbTitleNo
        '
        Me.rdbTitleNo.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.rdbTitleNo.AutoSize = True
        Me.rdbTitleNo.Location = New System.Drawing.Point(136, 6)
        Me.rdbTitleNo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.rdbTitleNo.Name = "rdbTitleNo"
        Me.rdbTitleNo.Size = New System.Drawing.Size(47, 21)
        Me.rdbTitleNo.TabIndex = 18
        Me.rdbTitleNo.Text = "No"
        Me.rdbTitleNo.UseVisualStyleBackColor = True
        '
        'rdbTitleNoChange
        '
        Me.rdbTitleNoChange.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.rdbTitleNoChange.AutoSize = True
        Me.rdbTitleNoChange.Checked = True
        Me.rdbTitleNoChange.Location = New System.Drawing.Point(269, 6)
        Me.rdbTitleNoChange.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.rdbTitleNoChange.Name = "rdbTitleNoChange"
        Me.rdbTitleNoChange.Size = New System.Drawing.Size(100, 21)
        Me.rdbTitleNoChange.TabIndex = 19
        Me.rdbTitleNoChange.TabStop = True
        Me.rdbTitleNoChange.Text = "No Change"
        Me.rdbTitleNoChange.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.ColumnCount = 3
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 133.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 133.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 256.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.Label20, 1, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.txtLegendWidth, 2, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.txtLegendHeight, 2, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.chkTopLegend, 0, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.Label21, 1, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.chkRightLegend, 0, 1)
        Me.TableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(4, 29)
        Me.TableLayoutPanel4.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 2
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(522, 66)
        Me.TableLayoutPanel4.TabIndex = 27
        '
        'Label20
        '
        Me.Label20.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(136, 8)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(101, 17)
        Me.Label20.TabIndex = 23
        Me.Label20.Text = "Legend Height"
        '
        'txtLegendWidth
        '
        Me.txtLegendWidth.Enabled = False
        Me.txtLegendWidth.Location = New System.Drawing.Point(269, 35)
        Me.txtLegendWidth.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtLegendWidth.Name = "txtLegendWidth"
        Me.txtLegendWidth.Size = New System.Drawing.Size(100, 22)
        Me.txtLegendWidth.TabIndex = 26
        Me.txtLegendWidth.Text = "100"
        '
        'txtLegendHeight
        '
        Me.txtLegendHeight.Enabled = False
        Me.txtLegendHeight.Location = New System.Drawing.Point(269, 2)
        Me.txtLegendHeight.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtLegendHeight.Name = "txtLegendHeight"
        Me.txtLegendHeight.Size = New System.Drawing.Size(100, 22)
        Me.txtLegendHeight.TabIndex = 25
        Me.txtLegendHeight.Text = "62"
        '
        'chkTopLegend
        '
        Me.chkTopLegend.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.chkTopLegend.AutoSize = True
        Me.chkTopLegend.Location = New System.Drawing.Point(4, 6)
        Me.chkTopLegend.Margin = New System.Windows.Forms.Padding(4)
        Me.chkTopLegend.Name = "chkTopLegend"
        Me.chkTopLegend.Size = New System.Drawing.Size(55, 21)
        Me.chkTopLegend.TabIndex = 15
        Me.chkTopLegend.Text = "Top"
        Me.chkTopLegend.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(136, 41)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(96, 17)
        Me.Label21.TabIndex = 24
        Me.Label21.Text = "Legend Width"
        '
        'chkRightLegend
        '
        Me.chkRightLegend.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.chkRightLegend.AutoSize = True
        Me.chkRightLegend.Location = New System.Drawing.Point(4, 39)
        Me.chkRightLegend.Margin = New System.Windows.Forms.Padding(4)
        Me.chkRightLegend.Name = "chkRightLegend"
        Me.chkRightLegend.Size = New System.Drawing.Size(63, 21)
        Me.chkRightLegend.TabIndex = 16
        Me.chkRightLegend.Text = "Right"
        Me.chkRightLegend.UseVisualStyleBackColor = True
        '
        'Label18
        '
        Me.Label18.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(4, 103)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(64, 17)
        Me.Label18.TabIndex = 20
        Me.Label18.Text = "Add Title"
        '
        'GroupBox6
        '
        Me.GroupBox6.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox6.Controls.Add(Me.chkXGridNone)
        Me.GroupBox6.Controls.Add(Me.chkYGridNone)
        Me.GroupBox6.Controls.Add(Me.Panel2)
        Me.GroupBox6.Controls.Add(Me.Panel1)
        Me.GroupBox6.Controls.Add(Me.chkXGridMinor)
        Me.GroupBox6.Controls.Add(Me.chkYGridMinor)
        Me.GroupBox6.Controls.Add(Me.chkXGridMajor)
        Me.GroupBox6.Controls.Add(Me.Label17)
        Me.GroupBox6.Controls.Add(Me.Label16)
        Me.GroupBox6.Controls.Add(Me.chkYGridMajor)
        Me.GroupBox6.Location = New System.Drawing.Point(3, 1047)
        Me.GroupBox6.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox6.Size = New System.Drawing.Size(540, 206)
        Me.GroupBox6.TabIndex = 9
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Grid Lines"
        '
        'chkXGridNone
        '
        Me.chkXGridNone.AutoSize = True
        Me.chkXGridNone.Location = New System.Drawing.Point(232, 129)
        Me.chkXGridNone.Margin = New System.Windows.Forms.Padding(4)
        Me.chkXGridNone.Name = "chkXGridNone"
        Me.chkXGridNone.Size = New System.Drawing.Size(64, 21)
        Me.chkXGridNone.TabIndex = 12
        Me.chkXGridNone.Text = "None"
        Me.chkXGridNone.UseVisualStyleBackColor = True
        '
        'chkYGridNone
        '
        Me.chkYGridNone.AutoSize = True
        Me.chkYGridNone.Location = New System.Drawing.Point(232, 42)
        Me.chkYGridNone.Margin = New System.Windows.Forms.Padding(4)
        Me.chkYGridNone.Name = "chkYGridNone"
        Me.chkYGridNone.Size = New System.Drawing.Size(64, 21)
        Me.chkYGridNone.TabIndex = 11
        Me.chkYGridNone.Text = "None"
        Me.chkYGridNone.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.rdbXGridNoChange)
        Me.Panel2.Controls.Add(Me.rdbXGridDash)
        Me.Panel2.Controls.Add(Me.rdbXGridSolid)
        Me.Panel2.Location = New System.Drawing.Point(12, 158)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(368, 27)
        Me.Panel2.TabIndex = 11
        '
        'rdbXGridNoChange
        '
        Me.rdbXGridNoChange.AutoSize = True
        Me.rdbXGridNoChange.Checked = True
        Me.rdbXGridNoChange.Location = New System.Drawing.Point(220, 2)
        Me.rdbXGridNoChange.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.rdbXGridNoChange.Name = "rdbXGridNoChange"
        Me.rdbXGridNoChange.Size = New System.Drawing.Size(100, 21)
        Me.rdbXGridNoChange.TabIndex = 8
        Me.rdbXGridNoChange.TabStop = True
        Me.rdbXGridNoChange.Text = "No Change"
        Me.rdbXGridNoChange.UseVisualStyleBackColor = True
        '
        'rdbXGridDash
        '
        Me.rdbXGridDash.AutoSize = True
        Me.rdbXGridDash.Location = New System.Drawing.Point(7, 2)
        Me.rdbXGridDash.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.rdbXGridDash.Name = "rdbXGridDash"
        Me.rdbXGridDash.Size = New System.Drawing.Size(62, 21)
        Me.rdbXGridDash.TabIndex = 6
        Me.rdbXGridDash.Text = "Dash"
        Me.rdbXGridDash.UseVisualStyleBackColor = True
        '
        'rdbXGridSolid
        '
        Me.rdbXGridSolid.AutoSize = True
        Me.rdbXGridSolid.Location = New System.Drawing.Point(112, 2)
        Me.rdbXGridSolid.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.rdbXGridSolid.Name = "rdbXGridSolid"
        Me.rdbXGridSolid.Size = New System.Drawing.Size(60, 21)
        Me.rdbXGridSolid.TabIndex = 7
        Me.rdbXGridSolid.Text = "Solid"
        Me.rdbXGridSolid.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.rdbYGridNoChange)
        Me.Panel1.Controls.Add(Me.rdbYGridDash)
        Me.Panel1.Controls.Add(Me.rdbYGridSolid)
        Me.Panel1.Location = New System.Drawing.Point(15, 69)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(365, 27)
        Me.Panel1.TabIndex = 10
        '
        'rdbYGridNoChange
        '
        Me.rdbYGridNoChange.AutoSize = True
        Me.rdbYGridNoChange.Checked = True
        Me.rdbYGridNoChange.Location = New System.Drawing.Point(217, 4)
        Me.rdbYGridNoChange.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.rdbYGridNoChange.Name = "rdbYGridNoChange"
        Me.rdbYGridNoChange.Size = New System.Drawing.Size(100, 21)
        Me.rdbYGridNoChange.TabIndex = 8
        Me.rdbYGridNoChange.TabStop = True
        Me.rdbYGridNoChange.Text = "No Change"
        Me.rdbYGridNoChange.UseVisualStyleBackColor = True
        '
        'rdbYGridDash
        '
        Me.rdbYGridDash.AutoSize = True
        Me.rdbYGridDash.Location = New System.Drawing.Point(7, 2)
        Me.rdbYGridDash.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.rdbYGridDash.Name = "rdbYGridDash"
        Me.rdbYGridDash.Size = New System.Drawing.Size(62, 21)
        Me.rdbYGridDash.TabIndex = 6
        Me.rdbYGridDash.Text = "Dash"
        Me.rdbYGridDash.UseVisualStyleBackColor = True
        '
        'rdbYGridSolid
        '
        Me.rdbYGridSolid.AutoSize = True
        Me.rdbYGridSolid.Location = New System.Drawing.Point(109, 4)
        Me.rdbYGridSolid.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.rdbYGridSolid.Name = "rdbYGridSolid"
        Me.rdbYGridSolid.Size = New System.Drawing.Size(60, 21)
        Me.rdbYGridSolid.TabIndex = 7
        Me.rdbYGridSolid.Text = "Solid"
        Me.rdbYGridSolid.UseVisualStyleBackColor = True
        '
        'chkXGridMinor
        '
        Me.chkXGridMinor.AutoSize = True
        Me.chkXGridMinor.Location = New System.Drawing.Point(124, 129)
        Me.chkXGridMinor.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.chkXGridMinor.Name = "chkXGridMinor"
        Me.chkXGridMinor.Size = New System.Drawing.Size(65, 21)
        Me.chkXGridMinor.TabIndex = 5
        Me.chkXGridMinor.Text = "Minor"
        Me.chkXGridMinor.UseVisualStyleBackColor = True
        '
        'chkYGridMinor
        '
        Me.chkYGridMinor.AutoSize = True
        Me.chkYGridMinor.Location = New System.Drawing.Point(124, 42)
        Me.chkYGridMinor.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.chkYGridMinor.Name = "chkYGridMinor"
        Me.chkYGridMinor.Size = New System.Drawing.Size(65, 21)
        Me.chkYGridMinor.TabIndex = 4
        Me.chkYGridMinor.Text = "Minor"
        Me.chkYGridMinor.UseVisualStyleBackColor = True
        '
        'chkXGridMajor
        '
        Me.chkXGridMajor.AutoSize = True
        Me.chkXGridMajor.Location = New System.Drawing.Point(12, 129)
        Me.chkXGridMajor.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.chkXGridMajor.Name = "chkXGridMajor"
        Me.chkXGridMajor.Size = New System.Drawing.Size(65, 21)
        Me.chkXGridMajor.TabIndex = 3
        Me.chkXGridMajor.Text = "Major"
        Me.chkXGridMajor.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(12, 110)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(47, 17)
        Me.Label17.TabIndex = 2
        Me.Label17.Text = "X-Axis"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(12, 18)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(47, 17)
        Me.Label16.TabIndex = 1
        Me.Label16.Text = "Y-Axis"
        '
        'chkYGridMajor
        '
        Me.chkYGridMajor.AutoSize = True
        Me.chkYGridMajor.Location = New System.Drawing.Point(15, 42)
        Me.chkYGridMajor.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.chkYGridMajor.Name = "chkYGridMajor"
        Me.chkYGridMajor.Size = New System.Drawing.Size(65, 21)
        Me.chkYGridMajor.TabIndex = 0
        Me.chkYGridMajor.Text = "Major"
        Me.chkYGridMajor.UseVisualStyleBackColor = True
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.btnFormatSeries)
        Me.GroupBox8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox8.Location = New System.Drawing.Point(3, 1258)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(540, 144)
        Me.GroupBox8.TabIndex = 10
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Series Format"
        '
        'btnFormatSeries
        '
        Me.btnFormatSeries.Location = New System.Drawing.Point(15, 21)
        Me.btnFormatSeries.Name = "btnFormatSeries"
        Me.btnFormatSeries.Size = New System.Drawing.Size(109, 29)
        Me.btnFormatSeries.TabIndex = 0
        Me.btnFormatSeries.Text = "Format Series"
        Me.btnFormatSeries.UseVisualStyleBackColor = True
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.Button1)
        Me.GroupBox9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox9.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(540, 4)
        Me.GroupBox9.TabIndex = 11
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Default Chart Settings"
        Me.GroupBox9.Visible = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 21)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(172, 29)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Apply Default Settings"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.TableLayoutPanel1)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(594, 50)
        Me.Panel3.TabIndex = 11
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 4
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 111.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 113.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 109.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.btnOk, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.btnCancel, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.btnApply, 2, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(592, 48)
        Me.TableLayoutPanel1.TabIndex = 2
        '
        'btnOk
        '
        Me.btnOk.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnOk.Location = New System.Drawing.Point(264, 10)
        Me.btnOk.Margin = New System.Windows.Forms.Padding(4)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.Size = New System.Drawing.Size(100, 28)
        Me.btnOk.TabIndex = 1
        Me.btnOk.Text = "Ok"
        Me.btnOk.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnCancel.Location = New System.Drawing.Point(487, 10)
        Me.btnCancel.Margin = New System.Windows.Forms.Padding(4)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(100, 28)
        Me.btnCancel.TabIndex = 0
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnApply
        '
        Me.btnApply.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnApply.Location = New System.Drawing.Point(376, 10)
        Me.btnApply.Margin = New System.Windows.Forms.Padding(4)
        Me.btnApply.Name = "btnApply"
        Me.btnApply.Size = New System.Drawing.Size(100, 28)
        Me.btnApply.TabIndex = 2
        Me.btnApply.Text = "Apply"
        Me.btnApply.UseVisualStyleBackColor = True
        '
        'ChartEditor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(851, 745)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MinimumSize = New System.Drawing.Size(866, 718)
        Me.Name = "ChartEditor"
        Me.Text = "Chart Editor"
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel3.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.TableLayoutPanel6.ResumeLayout(False)
        Me.TableLayoutPanel6.PerformLayout()
        Me.TableLayoutPanel5.ResumeLayout(False)
        Me.TableLayoutPanel5.PerformLayout()
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel4.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox9.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents lstFiles As System.Windows.Forms.ListBox
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents chkYlimSameForAll As System.Windows.Forms.CheckBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtYlimMax As System.Windows.Forms.TextBox
    Friend WithEvents txtYlimMin As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents chkXlimSameForAll As System.Windows.Forms.CheckBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtXlimMax As System.Windows.Forms.TextBox
    Friend WithEvents txtXlimMin As System.Windows.Forms.TextBox
    Friend WithEvents btnOk As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents chkYAutoScale As System.Windows.Forms.CheckBox
    Friend WithEvents chkXAutoScale As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtXAxisFontSize As System.Windows.Forms.TextBox
    Friend WithEvents txtGlobalFontSize As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtLegendFontSize As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtYAxisFontSize As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtYLabelFontSize As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtXLabelFontSize As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents chkAutoXMinorTicks As System.Windows.Forms.CheckBox
    Friend WithEvents chkAutoXMajorTicks As System.Windows.Forms.CheckBox
    Friend WithEvents txtXMinorTicks As System.Windows.Forms.TextBox
    Friend WithEvents txtXMajorTicks As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents chkAutoYMinorTicks As System.Windows.Forms.CheckBox
    Friend WithEvents chkAutoYMajorTicks As System.Windows.Forms.CheckBox
    Friend WithEvents txtYMinorTicks As System.Windows.Forms.TextBox
    Friend WithEvents txtYMajorTicks As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents chkYMinorTicks As System.Windows.Forms.CheckBox
    Friend WithEvents chkXMinorTicks As System.Windows.Forms.CheckBox
    Friend WithEvents chkRightLegend As System.Windows.Forms.CheckBox
    Friend WithEvents chkTopLegend As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents rdbYGridSolid As System.Windows.Forms.RadioButton
    Friend WithEvents rdbYGridDash As System.Windows.Forms.RadioButton
    Friend WithEvents chkXGridMinor As System.Windows.Forms.CheckBox
    Friend WithEvents chkYGridMinor As System.Windows.Forms.CheckBox
    Friend WithEvents chkXGridMajor As System.Windows.Forms.CheckBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents chkYGridMajor As System.Windows.Forms.CheckBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents rdbXGridDash As System.Windows.Forms.RadioButton
    Friend WithEvents rdbXGridSolid As System.Windows.Forms.RadioButton
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txtSizeTitle As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents rdbTitleNoChange As System.Windows.Forms.RadioButton
    Friend WithEvents rdbTitleNo As System.Windows.Forms.RadioButton
    Friend WithEvents rdbTitleYes As System.Windows.Forms.RadioButton
    Friend WithEvents txtLegendWidth As System.Windows.Forms.TextBox
    Friend WithEvents txtLegendHeight As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents chkXGridNone As System.Windows.Forms.CheckBox
    Friend WithEvents chkYGridNone As System.Windows.Forms.CheckBox
    Friend WithEvents rdbXGridNoChange As System.Windows.Forms.RadioButton
    Friend WithEvents rdbYGridNoChange As System.Windows.Forms.RadioButton
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel3 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TableLayoutPanel6 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TableLayoutPanel5 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TableLayoutPanel4 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents btnFormatSeries As System.Windows.Forms.Button
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents rdbYTickPosNoChange As System.Windows.Forms.RadioButton
    Friend WithEvents rdbYTickPosCross As System.Windows.Forms.RadioButton
    Friend WithEvents rdbYTickPosOutside As System.Windows.Forms.RadioButton
    Friend WithEvents rdbYTickPosInside As System.Windows.Forms.RadioButton
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents rdbXTickPosNoChange As System.Windows.Forms.RadioButton
    Friend WithEvents rdbXTickPosCross As System.Windows.Forms.RadioButton
    Friend WithEvents rdbXTickPosOutside As System.Windows.Forms.RadioButton
    Friend WithEvents rdbXTickPosInside As System.Windows.Forms.RadioButton
    Friend WithEvents btnApply As System.Windows.Forms.Button
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class

﻿'SJS 04-30-15 ENTIRE CLASS WAS IN DECOMPILED, BUT NOT HERE
Imports System
Imports System.Drawing

Public Class SeriesFormatInfo
    Public Name As String

    Public PlotOrder As Integer

    Public LineColor As Color

    Public LineDashString As String

    Public LineWeight As Double

    Public Property LineDashStyle As Integer
        Get
            Dim num As Integer = 0
            If String.Compare(Me.LineDashString, "Solid", False) = 0 Then
                num = 1
            ElseIf String.Compare(Me.LineDashString, "RoundDot", False) = 0 Then
                num = 3
            ElseIf String.Compare(Me.LineDashString, "SquareDot", False) = 0 Then
                num = 2
            ElseIf String.Compare(Me.LineDashString, "Dash", False) = 0 Then
                num = 4
            ElseIf String.Compare(Me.LineDashString, "DashDot", False) = 0 Then
                num = 5
            ElseIf String.Compare(Me.LineDashString, "LongDash", False) = 0 Then
                num = 7
            ElseIf String.Compare(Me.LineDashString, "LongDashDot", False) = 0 Then
                num = 8
            ElseIf String.Compare(Me.LineDashString, "LongDashDotDot", False) = 0 Then
                num = 9
            End If
            Return num
        End Get
        Set(ByVal value As Integer)
            If (value = 1) Then
                Me.LineDashString = "Solid"
            ElseIf (value = 3) Then
                Me.LineDashString = "RoundDot"
            ElseIf (value = 2) Then
                Me.LineDashString = "SquareDot"
            ElseIf (value = 4) Then
                Me.LineDashString = "Dash"
            ElseIf (value = 5) Then
                Me.LineDashString = "DashDot"
            ElseIf (value = 7) Then
                Me.LineDashString = "LongDash"
            ElseIf (value = 8) Then
                Me.LineDashString = "LongDashDot"
            ElseIf (value = 9) Then
                Me.LineDashString = "LongDashDotDot"
            End If
        End Set
    End Property

    Public Sub New()
        MyBase.New()
        Me.LineColor = Color.FromArgb(192, 80, 77)
        Me.LineDashString = "Solid"
        Me.LineWeight = 2.25
    End Sub
End Class

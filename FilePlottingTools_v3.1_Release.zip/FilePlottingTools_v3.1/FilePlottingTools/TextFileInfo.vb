﻿Imports System.IO
Imports System.Collections
Imports System.Windows.Forms

Public Class TextFileInfo
    Inherits GenericFileInfo

    Private Deliminator As String
    Private PlotHeaders As New ArrayList 'Array containing the headers of each series, excluding time (PlotHeaders(0) is first series, not time)

    Public Sub New(ByVal name As String, ByVal Index As Integer, ByVal Deliminator As String, ByRef DataSheet As Excel.Worksheet, ByRef ControlSheet As Excel.Worksheet, ByRef FormattedSheet As Excel.Worksheet, ByVal PlotHeaderRow As Integer)
        Me.Namep = name
        Me.Indexp = Index
        Me.Deliminator = Deliminator
        Me.shtDataSheet = DataSheet
        Me.shtImport = ControlSheet
        Me.shtFormatted = FormattedSheet
        Me.FormattedSheetHeaderRow = PlotHeaderRow
    End Sub

    Public Sub New(ByVal Name As String, ByVal Index As Integer, ByVal Deliminator As String, ByVal RowStart As Integer, ByVal RowEnd As Integer, ByVal ColStart As Integer, ByVal ColEnd As Integer, ByRef DataSheet As Excel.Worksheet, ByRef ControlSheet As Excel.Worksheet, ByRef FormattedSheet As Excel.Worksheet, ByVal PlotHeaderRow As Integer)
        Me.Namep = Name
        Me.Indexp = Index
        Me.Deliminator = Deliminator
        Me.RowStartp = RowStart
        Me.RowEndp = RowEnd
        Me.ColStartp = ColStart
        Me.ColEndp = ColEnd
        Me.NumRowsp = RowEnd - RowStart + 1
        Me.NumColsp = ColEnd - ColStart + 1
        Me.shtDataSheet = DataSheet
        Me.shtImport = ControlSheet
        Me.shtFormatted = FormattedSheet
        Me.FormattedSheetHeaderRow = PlotHeaderRow

    End Sub

    Public Sub New(ByVal name As String, ByVal Index As Integer, ByVal Deliminator As String, ByRef DataSheetManager As DataSheetClass, ByRef ControlSheet As Excel.Worksheet, ByRef FormattedSheet As Excel.Worksheet, ByVal PlotHeaderRow As Integer)
        Me.Namep = name
        Me.Indexp = Index
        Me.Deliminator = Deliminator
        Me.DataSheetManager = DataSheetManager
        Me.shtDataSheet = Me.DataSheetManager.TheDataSheet
        Me.shtImport = ControlSheet
        Me.shtFormatted = FormattedSheet
        Me.FormattedSheetHeaderRow = PlotHeaderRow
    End Sub

    Public Sub New(ByVal Name As String, ByVal Index As Integer, ByVal Deliminator As String, ByVal RowStart As Integer, ByVal RowEnd As Integer, ByVal ColStart As Integer, ByVal ColEnd As Integer, ByRef DataSheetManater As DataSheetClass, ByRef ControlSheet As Excel.Worksheet, ByRef FormattedSheet As Excel.Worksheet, ByVal PlotHeaderRow As Integer)
        Me.Namep = Name
        Me.Indexp = Index
        Me.Deliminator = Deliminator
        Me.RowStartp = RowStart
        Me.RowEndp = RowEnd
        Me.ColStartp = ColStart
        Me.ColEndp = ColEnd
        Me.NumRowsp = RowEnd - RowStart + 1
        Me.NumColsp = ColEnd - ColStart + 1
        Me.DataSheetManager = DataSheetManater
        Me.shtDataSheet = Me.DataSheetManager.TheDataSheet
        Me.shtImport = ControlSheet
        Me.shtFormatted = FormattedSheet
        Me.FormattedSheetHeaderRow = PlotHeaderRow

    End Sub

    'Public Sub ConstructByGroupInfoSheet(ByVal RowStart As Integer, ByVal RowEnd As Integer, ByVal ColStart As Integer, ByVal ColEnd As Integer)
    '    Me.RowStartp = RowStart
    '    Me.RowEndp = RowEnd
    '    Me.ColStartp = ColStart
    '    Me.ColEndp = ColEnd
    '    Me.NumRowsp = RowEnd - RowStart + 1
    '    Me.NumColsp = ColEnd - ColStart + 1
    'End Sub

    Public ReadOnly Property SeriesNames As ArrayList
        Get
            Return PlotHeaders
        End Get
    End Property

    Public Overrides Sub ReadFileIntoClipBoard()
        'Reads a file into the clipboard with tab delimited spacing
        'Returns the number of rows and columns in the parsed file

        'NOTE:  HAD A LOT OF TROUBLE WITH SPEED READING IN AND PARSING FILES
        'USING THE STRING CLASS.  IF YOU TRY TO CREATE A STRING WITH VERY LARGE FILES,
        'ADDING CHARACTERS ON EACH LOOP, YOU ALLOCATE MEMORY WHICH SLOWS THE PROCESS DOWN
        'USING A CHARACTER ARRAY TO ALLOCATE MEMORY FIRST IS INCREDIBLY FAST!!!, NEED TO DO THIS FOR LARGE FILES

        Dim NumLines As Integer = 0
        Dim NumCols As Integer = 0
        Dim plotfilereader As StreamReader = New StreamReader(Me.Namep)
        Dim FileString As String = plotfilereader.ReadToEnd
        plotfilereader.Close()
        Dim NumChar As Integer = FileString.Count
        Dim LastWasDelimiter As Boolean = False
        Dim CountOffset As Integer = 0

        Dim IndexOfLastEntry = -1


        Dim FileChars() As Char = UsefulFunctions.ChangeFileToTabDelimitedCharArray(Me.Namep, {Me.Deliminator, " "}, NumLines, NumCols)

        'THIS CODE DOESN'T WORK WELL FOR FILES WITH WHITE SPACE AND EXTRA LINES AT THE END.  
        'BUILT A MUCH CLEANER FUNCTION ABOVE

        'Dim FileChars(NumChar) As Char

        'For i As Integer = 0 To NumChar - 1
        '    'MessageBox.Show(Asc(FileString(i)))


        '    If FileString(i) = Me.Deliminator Then
        '        'Is the current character a deliminator?
        '        If LastWasDelimiter Then
        '            'if the last found character was also a delimiter, increment the countoffset only
        '            CountOffset += 1

        '        ElseIf Not LastWasDelimiter Then
        '            'if the last char was NOT a delimeter, and the current is

        '            If i = 0 Then
        '                'Check if its the first char your testing
        '                CountOffset += 1
        '                LastWasDelimiter = True
        '            ElseIf FileChars(IndexOfLastEntry) = vbCr Or FileChars(IndexOfLastEntry) = vbCrLf Or FileChars(IndexOfLastEntry) = vbLf Then
        '                'check if last entry was a new line, it is, increment countoffset only
        '                CountOffset += 1

        '            Else
        '                'this is the first delimeter found after a number character
        '                LastWasDelimiter = True
        '                FileChars(i - CountOffset) = vbTab
        '                IndexOfLastEntry += 1
        '                If NumLines = 0 Then
        '                    NumCols += 1
        '                End If

        '            End If
        '        End If
        '    Else

        '        If FileString(i) = vbCr Then
        '            If FileChars(IndexOfLastEntry) = vbTab Then
        '                'the last entry in the parsed list was a tab
        '                'if so, there were extra deliminators after the last entry
        '                'remove the last tab

        '                FileChars(IndexOfLastEntry) = FileString(i)
        '                CountOffset += 1

        '            Else
        '                'the last entry was not a tab
        '                LastWasDelimiter = False

        '                FileChars(i - CountOffset) = FileString(i)
        '                IndexOfLastEntry += 1

        '                If NumLines = 0 Then
        '                    NumCols += 1
        '                End If

        '            End If

        '            NumLines += 1
        '        ElseIf FileString(i) = vbLf Then
        '            'The current character is a line feed
        '            If FileChars(IndexOfLastEntry) = vbCr Then
        '                'the last entry was a carrage return
        '                FileChars(i - CountOffset) = FileString(i)
        '                IndexOfLastEntry += 1
        '                LastWasDelimiter = False
        '            Else
        '                'the last entry was not a carriage return
        '                FileChars(i - CountOffset) = FileString(i)
        '                IndexOfLastEntry += 1
        '                NumLines += 1
        '            End If

        '        Else
        '            LastWasDelimiter = False

        '            FileChars(i - CountOffset) = FileString(i)
        '            IndexOfLastEntry += 1

        '        End If

        '    End If

        'Next

        My.Computer.Clipboard.Clear()
        My.Computer.Clipboard.SetText(FileChars)
        Me.NumRowsp = NumLines
        Me.NumColsp = NumCols

    End Sub

    Public Overrides Sub UpdateDataSheet()
        'update groupinfo sheet
        If Index = -1 Then
            MessageBox.Show("ERROR from TEXTFILEINFO.UpdateDataSheet(), index not specified.  Nothing updated.")
        Else
            ClearGroupRow()
            'shtGroupInfo.Cells(10 + Me.Index, 3).Value() = Me.Namep
            'shtGroupInfo.Cells(10 + Me.Index, 4).Value() = Me.RowStart
            'shtGroupInfo.Cells(10 + Me.Index, 5).Value() = Me.RowEndp
            'shtGroupInfo.Cells(10 + Me.Index, 6).Value() = Me.ColStartp
            'shtGroupInfo.Cells(10 + Me.Index, 7).Value() = Me.ColEndp

            Me.DataSheetManager.CellFirstFileName.Offset(Me.Index).Value() = Me.Namep
            Me.DataSheetManager.CellFirstFileRowStart.Offset(Me.Index).Value() = Me.RowStart
            Me.DataSheetManager.CellFirstFileRowEnd.Offset(Me.Index).Value() = Me.RowEndp
            Me.DataSheetManager.CellFirstFileColStart.Offset(Me.Index).Value() = Me.ColStartp
            Me.DataSheetManager.CellFirstFileColEnd.Offset(Me.Index).Value() = Me.ColEndp
        End If

    End Sub

    'Public Overrides Sub UpdateDataForGroup()
    '    Dim sheetindex As Integer = -1
    '    'Dim numWorksheets As Integer = Globals.ThisWorkbook.Sheets.Count
    '    Dim DataColIndex As Integer = 2 'FindColumnForData(GroupName)
    '    Dim Files As New GenericFileCollection
    '    Dim SavFileList As New SavFileInfoCollection
    '    Dim Delimiter As String
    '    Dim GroupType As String

    '    If DataColIndex = -1 Then
    '        'data was not found, exit subroutine
    '        MessageBox.Show("Error, could not update files.  No dataset was found.")
    '        Exit Sub
    '    ElseIf Me.shtGroupInfo.Cells(10, 3).Value Is Nothing Then
    '        'make sure there is at least one file in the file list on the groupinfo hidden sheet
    '        'if there are no files, exit with message
    '        MessageBox.Show("Error, no files found.  Make sure there are specified files in the file manager")
    '        Exit Sub
    '    Else
    '        'get the group type (compare or stitch)
    '        GroupType = Me.shtGroupInfo.Cells(11, DataColIndex).Value
    '        'get the delimiter
    '        Delimiter = Me.shtGroupInfo.Cells(12, DataColIndex).Value

    '        'create counter for the first row containing file names
    '        Dim row As Integer = 10
    '        'create counter for the index of the file
    '        Dim index As Integer = 0

    '        While True
    '            If Me.shtGroupInfo.Cells(row, DataColIndex + 1).Value Is Nothing Then
    '                Exit While
    '            Else
    '                'Get data for file
    '                Dim name As String = Me.shtGroupInfo.Cells(row, DataColIndex + 1).Value

    '                If IsSav Then
    '                    'create a new sav file
    '                    Dim sav As New SavFileInfo(name, index)
    '                    Files.Add(sav)

    '                Else
    '                    'create new textfileinfo
    '                    Dim Tfi As New TextFileInfo(name, index, Delimiter)
    '                    'Add textfileinfo to the list
    '                    Files.Add(Tfi)
    '                    'increment counters

    '                End If
    '                index += 1
    '                row += 1

    '            End If
    '        End While

    '    End If

    '    If IsSav Then
    '        If IsRefresh Then
    '            'refresh button was pressed
    '            For Each savfile As SavFileInfo In Files
    '                savfile.GetPlotListFromGroupInfoSheet()
    '            Next
    '        Else
    '            Dim FirstSavFile As SavFileInfo = Files(0)
    '            FirstSavFile.GetPlotListFromGroupInfoSheet()
    '            Dim SavImporter As New SavFileImport(FirstSavFile.Submodels, FirstSavFile.ItemsToPlot)
    '            If SavImporter.ShowDialog = DialogResult.OK Then
    '                For Each savfile As SavFileInfo In Files
    '                    savfile.ItemsToPlot = SavImporter.GetSelectedSubmodels
    '                Next
    '            Else
    '                Exit Sub
    '            End If
    '        End If

    '    End If


    '    sheetindex = Me.shtImport.Index

    '    If GroupType = "C" Then
    '        'comaprison files
    '        'Globals.shtFormatted.Visible = Excel.XlSheetVisibility.xlSheetHidden
    '        'Me.shtImport.Visible = Excel.XlSheetVisibility.xlSheetHidden
    '        PopulateDataSheetCompare(sheetindex, Files, Delimiter)
    '        'Globals.shtFormatted.Visible = Excel.XlSheetVisibility.xlSheetVisible
    '        'Me.shtImport.Visible = Excel.XlSheetVisibility.xlSheetVisible
    '    ElseIf GroupType = "S" Then
    '        'stitch files
    '        PopulateDataSheetStitch(sheetindex, Files, Delimiter)
    '    End If

    '    Me.shtImport.Activate()
    'End Sub

    Public ReadOnly Property GetSeriesHeader(ByVal index As Integer) As String
        Get
            Return PlotHeaders(index)
        End Get
    End Property

    Public Sub GetHeadersForEachSeries()
        For j As Integer = Me.ColStart + 1 To Me.ColEnd
            'BUG:  If you delete columns in the formatted sheet, the plotter won't function correctly
            Try
                If shtFormatted.Cells(HeaderRowNumber, j).Value Is Nothing Then
                    MessageBox.Show("Error, there are no Plot Header Labels in Row 19 of the Formatted Data Sheet.  Did the header formula get erased?")
                    Exit For
                Else
                    PlotHeaders.Add(shtFormatted.Cells(HeaderRowNumber, j).Value.ToString)
                End If
            Catch ex As Exception
                'need to learn about exception handling so I can stop the plot from running
                'Throw New ApplicationException("Exception Occured")
            End Try


        Next
    End Sub

End Class

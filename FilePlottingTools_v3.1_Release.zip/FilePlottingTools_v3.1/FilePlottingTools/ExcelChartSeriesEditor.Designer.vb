﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ExcelChartSeriesEditor
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblSeriesName = New System.Windows.Forms.Label()
        Me.cmbLineStyle = New System.Windows.Forms.ComboBox()
        Me.btnColor = New CustomControlsLibrary.ColorButton()
        Me.nudLineWeight = New System.Windows.Forms.NumericUpDown()
        CType(Me.nudLineWeight, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblSeriesName
        '
        Me.lblSeriesName.AutoSize = True
        Me.lblSeriesName.Location = New System.Drawing.Point(3, 6)
        Me.lblSeriesName.Name = "lblSeriesName"
        Me.lblSeriesName.Size = New System.Drawing.Size(89, 17)
        Me.lblSeriesName.TabIndex = 1
        Me.lblSeriesName.Text = "Series Name"
        '
        'cmbLineStyle
        '
        Me.cmbLineStyle.BackColor = System.Drawing.Color.White
        Me.cmbLineStyle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbLineStyle.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbLineStyle.FormattingEnabled = True
        Me.cmbLineStyle.Items.AddRange(New Object() {"Solid", "RoundDot", "SquareDot", "Dash", "DashDot", "LongDash", "LongDashDot", "LongDashDotDot"})
        Me.cmbLineStyle.Location = New System.Drawing.Point(257, 2)
        Me.cmbLineStyle.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.cmbLineStyle.Name = "cmbLineStyle"
        Me.cmbLineStyle.Size = New System.Drawing.Size(121, 24)
        Me.cmbLineStyle.TabIndex = 2
        Me.cmbLineStyle.Tag = ""
        '
        'btnColor
        '
        Me.btnColor.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnColor.Location = New System.Drawing.Point(223, 1)
        Me.btnColor.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnColor.MyColor = System.Drawing.Color.Empty
        Me.btnColor.Name = "btnColor"
        Me.btnColor.Size = New System.Drawing.Size(28, 28)
        Me.btnColor.TabIndex = 3
        '
        'nudLineWeight
        '
        Me.nudLineWeight.DecimalPlaces = 2
        Me.nudLineWeight.Increment = New Decimal(New Integer() {25, 0, 0, 131072})
        Me.nudLineWeight.Location = New System.Drawing.Point(387, 4)
        Me.nudLineWeight.Minimum = New Decimal(New Integer() {25, 0, 0, 131072})
        Me.nudLineWeight.Name = "nudLineWeight"
        Me.nudLineWeight.Size = New System.Drawing.Size(89, 22)
        Me.nudLineWeight.TabIndex = 4
        Me.nudLineWeight.Value = New Decimal(New Integer() {25, 0, 0, 131072})
        '
        'ExcelChartSeriesEditor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(246, Byte), Integer), CType(CType(246, Byte), Integer))
        Me.Controls.Add(Me.nudLineWeight)
        Me.Controls.Add(Me.btnColor)
        Me.Controls.Add(Me.cmbLineStyle)
        Me.Controls.Add(Me.lblSeriesName)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "ExcelChartSeriesEditor"
        Me.Size = New System.Drawing.Size(484, 32)
        CType(Me.nudLineWeight, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblSeriesName As System.Windows.Forms.Label
    Friend WithEvents cmbLineStyle As System.Windows.Forms.ComboBox
    Friend WithEvents btnColor As CustomControlsLibrary.ColorButton
    Friend WithEvents nudLineWeight As System.Windows.Forms.NumericUpDown

End Class

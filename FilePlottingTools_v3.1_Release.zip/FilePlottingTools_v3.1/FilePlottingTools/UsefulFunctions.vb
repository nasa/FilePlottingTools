﻿Imports System.Collections
Imports System.Diagnostics
Imports System.Windows.Forms
Imports System.Drawing
Imports Microsoft.Win32
Imports System.IO

Module UsefulFunctions

    Public Sub MoveItemsInListView(ByRef lvwListView As ListView, ByVal blnMoveUp As Boolean)
        'got this online:
        'http://www.pchilton.co.uk/2011/04/16/vb-net-move-listviewitems-up-and-down/

        Try
            'Set the listview index to limit to depending on whether we are moving things up or down in the list
            Dim intLimittedIndex As Integer = (lvwListView.Items.Count - 1)
            If blnMoveUp Then intLimittedIndex = 0

            'Define a new collection of the listview indexes to move
            Dim colIndexesToMove As New List(Of Integer)()

            'Loop through each selected item in the listview (multiple select support)
            For Each lviSelectedItem As ListViewItem In lvwListView.SelectedItems
                'Add the item's index to the collection
                colIndexesToMove.Add(lviSelectedItem.Index)

                'If this item is at the limit we defined
                If lviSelectedItem.Index = intLimittedIndex Then
                    'Do not attempt to move item(s) as we are at the top or bottom of the list
                    Exit Try
                End If
            Next

            'If we are moving items down
            If Not blnMoveUp Then
                'Reverse the index list so that we move items from the bottom of the selection first
                colIndexesToMove.Reverse()
            End If

            'Loop through each index we want to move
            For Each intIndex As Integer In colIndexesToMove
                'Define a new listviewitem
                Dim lviNewItem As ListViewItem = CType(lvwListView.Items(intIndex).Clone(), ListViewItem)

                'Remove the currently selected item from the list
                lvwListView.Items(intIndex).Remove()

                'Insert the new item in it's new place
                If blnMoveUp Then
                    lvwListView.Items.Insert(intIndex - 1, lviNewItem)
                Else
                    lvwListView.Items.Insert(intIndex + 1, lviNewItem)
                End If

                'Set the new item to be selected
                lviNewItem.Selected = True
            Next
        Catch ex As Exception
            Trace.WriteLine("MoveItemsInListView() has thrown an exception: " & ex.Message)
        Finally
            'Set the focus on the listview
            lvwListView.Focus()
        End Try
    End Sub

    Public Sub MakeRangeBold(ByRef range As Excel.Range)
        range.Font.Bold = True
    End Sub

    Public Sub AddBordersToRange(ByRef range As Excel.Range)
        range.Borders.Color = System.Drawing.Color.Black.ToArgb
    End Sub

    Public Sub SetNumberOfDecimalPlaces(ByRef range As Excel.Range, ByVal NumDigits As Integer)
        range.NumberFormat = PlottingFunctions.GetNumberFormatString(NumDigits)
    End Sub

    Public Sub SetColumnWidth(ByRef FirstCellInCol As Excel.Range, ByVal width As Integer)
        FirstCellInCol.EntireColumn.ColumnWidth = width
    End Sub

    Public Sub FreezePanes(ByRef aSheet As Excel.Worksheet, ByVal NumCols As Integer, ByVal NumRows As Integer)
        With aSheet
            .Activate()
            .Application.ActiveWindow.SplitRow = NumRows
            .Application.ActiveWindow.SplitColumn = NumCols
            .Application.ActiveWindow.FreezePanes = True
        End With
    End Sub

    Public Function ReturnNewNameIfSheetExists(ByRef aWorkbook As Excel.Workbook, ByVal NewName As String) As String
        Dim increment As Integer = 1

        While IsDuplicateName(aWorkbook, NewName)
            Dim CurrentNumber As String = String.Empty
            If NewName.Last = ")" Then
                Dim index = NewName.LastIndexOf("(")
                For i As Integer = index + 1 To NewName.Count - 2
                    CurrentNumber += NewName(i)
                Next
                increment = CType(CurrentNumber, Integer) + 1
                NewName = NewName.Remove(index)

            End If
            NewName = NewName + "(" + increment.ToString() + ")"
            increment += 1
        End While
        Return NewName
    End Function

    Public Function IsDuplicateName(ByRef aWorkbook As Excel.Workbook, ByVal Name As String) As Boolean

        Dim FoundDuplicate = False

        For i As Integer = 1 To aWorkbook.Sheets.Count()
            If aWorkbook.Sheets.Item(i).Name = Name Then

                FoundDuplicate = True
                Exit For

            End If
        Next

        Return FoundDuplicate
    End Function

    Public Function PointsToPixelsAsPoint(ByVal Xpoints As Double, ByVal Ypoints As Double, Optional ByVal PPI As Integer = 96) As Point

        Dim x As Integer = Xpoints / 72 * PPI
        Dim y As Integer = Ypoints / 72 * PPI

        Dim newpoint As New Point(x, y)

        Return newpoint

    End Function

    Public Function GetWorkSheetByName(ByVal SheetName As String, ByRef WorkBook As Excel.Workbook) As Excel.Worksheet
        'Returns the worksheet with the provided name
        'If not found, returns last worksheet
        For i As Integer = 1 To WorkBook.Worksheets.Count
            If WorkBook.Worksheets(i).Name = SheetName Then
                Return WorkBook.Worksheets(i)
            End If
        Next

        Return WorkBook.Worksheets(WorkBook.Worksheets.Count)

    End Function

    Public Sub SaveFileFromResource(ByVal FilePath As String, ByRef file As Object)
        Dim FByte() As Byte = file
        My.Computer.FileSystem.WriteAllBytes(FilePath, FByte, True)
    End Sub

    Public Function GetVersionString() As String
        'SJS THIS DOESN'T WORK, NOT SURE WHY IT DOESN'T GET MINOR VERSION
        'FIX
        Dim Minor = My.Application.Info.Version.Minor.ToString
        Return My.Application.Info.Version.Major.ToString + "." + My.Application.Info.Version.Minor.ToString
    End Function

    Public Sub AddCommentToExcelCell(ByRef Cell As Excel.Range, ByVal Comment As String)
        Cell.AddComment()

        Cell.Comment.Visible = False

        Cell.Comment.Text(Comment)

        Cell.Comment.Shape.TextFrame.AutoSize = True

        Cell.Comment.Shape.TextFrame.Characters.Font.Bold = False

    End Sub

    Public Function GetUserRegKeyValue(ByVal path As String, ByVal keyName As String) As Object

        If UserRegKeyExists(path) Then
            Dim regKey As Object = Registry.CurrentUser.OpenSubKey(path, False)

            Dim value As Object = regKey.GetValue(keyName)
            Return value
        Else
            Return Nothing
        End If

    End Function

    Public Function GetLocalRegKeyValue(ByVal path As String, ByVal keyName As String) As Object

        If LocalRegKeyExists(path) Then
            Dim regKey As Object = Registry.LocalMachine.OpenSubKey(path, False)

            Dim value As Object = regKey.GetValue(keyName)
            Return value
        Else
            Return Nothing
        End If

    End Function

    Public Function UserRegKeyExists(ByVal path As String) As Boolean
        Dim regKey As Object = Registry.CurrentUser.OpenSubKey(path, False)
        If regKey Is Nothing Then
            Return False
        Else
            Return True
        End If
    End Function

    Public Function LocalRegKeyExists(ByVal path As String) As Boolean
        Dim regKey As Object = Registry.LocalMachine.OpenSubKey(path, False)
        If regKey Is Nothing Then
            Return False
        Else
            Return True
        End If
    End Function

    Public Function ExpandRangeToLastRow(ByRef aRange As Excel.Range) As Excel.Range
        'THIS FUNCTION TAKES AN EXCEL RANGE AS INPUT, AND EXPANDS IT TO ENCOMPASS THE LAST DATA IN THE FIRST ROW
        'WAS DESIGN FOR A SINGLE COLUMN, UNKNOWN BEHAVIOR FOR MULTIPLE COLUMNS

        'INPUT:  RANGE TO EXPAND
        'OUTPUT: NEW RANGE EXPANDED TO LAST ENTRY IN COLUMN.  RETURNS NOTHING IF FIRST CELL IS EMPTY
        Dim NewRange As Excel.Range = Nothing

        'NOTE:  CELLS(0) IS ONE ABOVE THE FIRST IN THE RANGE, I.E. THE HEADER


        If Globals.ThisAddIn.Application.WorksheetFunction.CountA(aRange) = 0 Then
            'if the range is empty, then don't update anything

        ElseIf aRange.Cells(0).Value Is Nothing Then
            NewRange = Nothing
        Else
            Dim OriginalLastRow As Integer = aRange.Row + aRange.Rows.Count - 1
            Dim NewLastRow As Integer = aRange.End(Excel.XlDirection.xlDown).Row

            Dim Difference As Integer = NewLastRow - OriginalLastRow

            NewRange = aRange.Resize(aRange.Count + Difference)
        End If

        Return NewRange
    End Function

    Public Function GetLastRowNumberWithData(ByRef aSheet As Excel.Worksheet, ByVal StartRow As Integer, ByVal StartCol As String) As Integer

        Dim aRange As Excel.Range = aSheet.Cells(StartRow, StartCol)
        'SJS BUG, MODE FROM = NOTHING
        If aRange.Value Is Nothing Then
            Return StartRow
        Else
            aRange = ExpandRangeToLastRow(aRange)
            Dim LastRow As Integer = aRange.Row + aRange.Rows.Count - 1
            Return LastRow
        End If

    End Function

    Public Function ChangeFileToTabDelimitedCharArray(ByVal FileName As String, ByVal DelimArray As Char(), ByRef NumRows As Integer, ByRef NumCols As Integer) As Char()
        'initialize NumCols and NumRows to 0
        NumCols = 0
        NumRows = 0

        'Read the entire file into a string, count number of characters, and created fixed size character array.
        'close reader
        Dim Fullfilereader As StreamReader = New StreamReader(FileName)
        Dim NumChars As Integer = Fullfilereader.ReadToEnd.Count()
        Dim LineChar(NumChars) As Char
        Fullfilereader.Close()
        Fullfilereader.Dispose()

        'open a new reader on the same file for line by line reading
        Dim LineReader As StreamReader = New StreamReader(FileName)
        Dim index As Integer = 0

        'Read all lines in file
        While True

            Dim Line As String = LineReader.ReadLine()
            'split the line by the delimiters in the delimarray
            Dim ValueArray() As String = Line.Split(DelimArray, StringSplitOptions.RemoveEmptyEntries)


            If ValueArray.Count = 0 Then
                'there are no entries in the line
            Else
                'the line has entries, increment num rows and cols
                NumRows += 1
                NumCols = ValueArray.Count

                'loop through each entry and add to fixed size array
                'seperate each entry by a tab, and add return at end of line
                For i As Integer = 0 To NumCols - 1
                    For j As Integer = 0 To ValueArray(i).Count - 1
                        LineChar(index) = ValueArray(i)(j)
                        index += 1
                    Next
                    If i = NumCols - 1 Then
                        LineChar(index) = vbCrLf
                        index += 1
                    Else
                        LineChar(index) = vbTab
                        index += 1
                    End If

                Next

            End If

            'check if its the end of the file, if so exit while
            If LineReader.EndOfStream Then
                Exit While
            End If

        End While

        'close the file
        LineReader.Close()
        LineReader.Dispose()

        Return LineChar

    End Function
    '--------------------------------------------------------------
    'SJS 4/29/2015 THE FOLLOWING SUBS WERE IN ORIGINAL THAT WAS LOST, ADDED BACK FROM DECOMPILE

    Public Sub CreateRegSubKeyCurrentUser(ByVal KeyString As String, ByVal ValueString As String, ByVal DataString As String)
        'think these are my.computer, was MyProject in decompiled code
        My.Computer.Registry.CurrentUser.CreateSubKey(KeyString)
        My.Computer.Registry.SetValue(String.Concat("HKEY_CURRENT_USER\", KeyString), ValueString, DataString)
    End Sub

    Public Sub DeleteRegSubKeyCurrentUser(ByVal KeyString As String)
        My.Computer.Registry.CurrentUser.DeleteSubKey(KeyString)
    End Sub

    Public Function FileExists(ByVal FileName As String) As Object

        If File.Exists(FileName) Then
            Return True
        Else
            Return False
        End If

    End Function

    Public Sub GetSAVLibraryPathFromKey(ByRef FileName As String)
        Dim keystr As String = "Software\\FilePlottingTools"
        Dim valstr As String = "SinapsXNetLocation"
        If SavFileKeyExists(FileName) = False Then
            UsefulFunctions.CreateRegSubKeyCurrentUser(keystr, valstr, FileName)
        End If
    End Sub

    Public Function SavFileKeyExists(ByRef FileName As String) As Boolean
        Dim flag As Boolean
        Dim str As String = "Software\\FilePlottingTools"
        Dim str1 As String = "SinapsXNetLocation"
        'SJS 4/29/2015 set to My.computer from MyProject in decompiled version
        If (My.Computer.Registry.CurrentUser.OpenSubKey(str) IsNot Nothing) Then
            FileName = My.Computer.Registry.GetValue(String.Concat("HKEY_CURRENT_USER\", str), str1, "").ToString
            flag = True
        Else
            flag = False
        End If
        Return flag
    End Function

    Public Sub PositionFormOverParent(ByRef aForm As Form, Optional ByVal LeftOffset As Double = 40, Optional ByVal TopOffset As Double = 40)
        aForm.StartPosition = FormStartPosition.Manual
        Dim pixelsAsPoint As Point = UsefulFunctions.PointsToPixelsAsPoint(Globals.ThisAddIn.Application.Left, Globals.ThisAddIn.Application.Top, 96)
        pixelsAsPoint.Offset(CInt(Math.Round(LeftOffset)), CInt(Math.Round(TopOffset)))
        aForm.Location = pixelsAsPoint
        aForm.Focus()
    End Sub

    Public Sub SetSavFilePath(ByRef PathString As String)
        'Try to automatically find the sav file library
        Dim str As String = "Software\\FilePlottingTools"
        Dim setSavLibPath As SetSavLibPath = New SetSavLibPath(PathString)
        If (setSavLibPath.ShowDialog() = DialogResult.OK) Then
            PathString = setSavLibPath.GetPath
            My.Computer.Registry.SetValue(String.Concat("HKEY_CURRENT_USER\", str), "SinapsXNetLocation", PathString)
        End If
    End Sub

    Public Sub AutoSetSavFilePath(ByRef PathString As String)
        'Try to automatically find the sav file library
        Dim str As String = "Software\\FilePlottingTools"
        Dim setSavLibPathDiag As SetSavLibPath = New SetSavLibPath(PathString)
        PathString = setSavLibPathDiag.AutoLocateSinapsLibrary()

        If PathString = "" Then
            'file wasn't located, call SetSavFilePath
            SetSavFilePath(PathString)
        Else
            My.Computer.Registry.SetValue(String.Concat("HKEY_CURRENT_USER\", str), "SinapsXNetLocation", PathString)
        End If

    End Sub

    Public Sub ParseCommaStringAddDoubleToArray(ByRef theArray As ArrayList, ByVal theLine As String)
        While True
            theLine = theLine.Trim()
            Dim commaindex As Integer = theLine.IndexOf(",")
            If commaindex = -1 Then
                Dim theValue As Double = CType(theLine, Double)
                theArray.Add(theValue)
                Exit While
            Else
                Dim theValue As Double = CType(theLine.Substring(0, commaindex), Double)
                theArray.Add(theValue)
                theLine = theLine.Substring(commaindex + 1)
            End If
        End While

    End Sub

    Public Function FindFileNameWithSizeInFolders(ByVal StartDirectory As String, ByVal FileName As String, ByVal FileSize As Long) As String
        'this function uses recursion to look for a file with a specified name and file size in bytes in all subdirectories
        'of the StartDirectory variable.

        Dim theDir As New DirectoryInfo(StartDirectory)
        'loop through all subdirectories in the current directory, use recursion
        For Each subDir As DirectoryInfo In theDir.GetDirectories
            Dim FoundFile As String = FindFileNameWithSizeInFolders(subDir.FullName, FileName, FileSize)
            'if FoundFile is not an empty string, then return the foundfile
            If FoundFile <> "" Then
                Return FoundFile
            End If
        Next
        'find all files in the current directory that equal the filename
        'if one of the files size matches FileSize, return the file name
        For Each file As FileInfo In theDir.GetFiles(FileName)
            If file.Length = FileSize Then
                Return file.FullName
            End If
        Next

        'didn't find any files in the folder, return empty string
        Return ""

    End Function

    Public Sub FindAllFilesWithNameInFolder(ByVal StartDirectory As String, ByVal FileName As String, ByRef FileList As ArrayList)
        'this function uses recursion to look for a file with a specified name and file size in bytes in all subdirectories
        'of the StartDirectory variable.

        Dim theDir As New DirectoryInfo(StartDirectory)
        'loop through all subdirectories in the current directory, use recursion
        For Each subDir As DirectoryInfo In theDir.GetDirectories
            FindAllFilesWithNameInFolder(subDir.FullName, FileName, FileList)
        Next
        'find all files in the current directory that equal the filename
        'if one of the files size matches FileSize, return the file name
        For Each file As FileInfo In theDir.GetFiles(FileName)
            FileList.Add(file.FullName)
        Next

    End Sub

    Public Function CountNumberOfSpecificCharInString(ByVal theString As String, ByVal charToFind As String) As Integer
        Dim count As Integer = 0

        For i As Integer = 0 To theString.Count - 1
            If theString(i) = charToFind Then
                count += 1
            End If
        Next
        Return count
    End Function

    Public Function CheckIfExcelMacroExists(ByVal MacroName As String) As Boolean
        Dim VBProj = Globals.ThisAddIn.Application.ActiveWorkbook.VBProject
        Dim FirstLine As Integer = 1
        Dim LastLine As Integer = 0
        Dim FirstColumn As Integer = 1
        Dim LastColumn As Integer = -1

        For Each VBcomp In VBProj.VBComponents
            Dim CodeMod = VBcomp.CodeModule
            LastLine = CodeMod.CountOfLines
            Dim bFind As Boolean = CodeMod.Find(Target:=MacroName, StartLine:=FirstLine, EndLine:=LastLine, StartColumn:=FirstColumn, EndColumn:=FirstColumn, WholeWord:=True)
            If bFind Then
                'MessageBox.Show("The macro " + MacroName + " does exist in the: " + VBcomp.Name.ToString)
                Return True
            End If

        Next

        Return False
    End Function


    Public Function GetFileNameFromFullPathText(ByVal FullPath As String) As String

        Dim LastSlashIndex As Integer = FullPath.LastIndexOf("\")

        Return FullPath.Substring(LastSlashIndex + 1)

    End Function
End Module

﻿Public Class SeriesProperties

    Private Sub btnColor_Click(sender As System.Object, e As System.EventArgs) Handles btnColor.Click
        If ColorDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            btnColor.BackColor = ColorDialog1.Color
        End If
    End Sub
End Class

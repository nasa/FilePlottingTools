﻿Imports System.Collections

Public Class NewPlot2
    'FilesAndRanges
    'First column is file names
    'Next columns are ROWSTART ROWEND COLSTART, COLEND respectively
    Public FilesAndRanges As Matrix

    Public PlotName As String

    'SelectedDataStore
    'First column is file names
    'additional columns are 
    Private SelectedDataStore As New Matrix

    'FilesAndData
    'First Column is file names
    'additional columns are header labels for plotting from formatted data sheet
    Private FilesAndData As New Matrix


    Public FileList As TextFileCollection


    'LastFileIndex stores the previously selected file index in the check list
    Private LastFileIndex As Integer = 0

    Public LimitList As New ArrayList



    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

        txtPlotName.Text = "NewPlot"
        CheckForDuplicatNames()

    End Sub

    Public Sub New(ByVal fdata As Matrix, ByVal FandR As Matrix)
        Me.New()
        Me.FilesAndData = fdata
        Me.FilesAndRanges = FandR

        PopulateControl(FilesAndData, FilesAndRanges)

    End Sub

    Public Sub New(ByRef FileList As TextFileCollection)
        Me.New()
        Me.FileList = FileList
        PopulateControlA()
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub btnOk_Click(sender As System.Object, e As System.EventArgs) Handles btnOk.Click

        SaveCurrent(clbFiles.SelectedIndex)
        If IsAnythingSelected() Then
            If IsDuplicateName(txtPlotName.Text) Then
                MessageBox.Show("Sheet Name Already Exists, Change Name")
            Else
                Me.PlotName = txtPlotName.Text
                Me.DialogResult = Windows.Forms.DialogResult.OK
                Me.Close()
            End If
        Else
            MessageBox.Show("Nothing selected.  Select Data or Cancel.")
        End If


    End Sub

    Private Function IsDuplicateName(ByVal Name As String) As Boolean

        Dim FoundDuplicate = False

        For i As Integer = 1 To Globals.ThisWorkbook.Sheets.Count()
            If Globals.ThisWorkbook.Sheets.Item(i).Name = Name Then

                FoundDuplicate = True
                Exit For

            End If
        Next

        Return FoundDuplicate
    End Function

    Public Sub CheckForDuplicatNames()
        Dim increment As Integer = 1

        While IsDuplicateName(txtPlotName.Text)
            Dim CurrentNumber As String = String.Empty
            If txtPlotName.Text.Last = ")" Then
                Dim index = txtPlotName.Text.LastIndexOf("(")
                For i As Integer = index + 1 To txtPlotName.Text.Count - 2
                    CurrentNumber += txtPlotName.Text(i)
                Next
                increment = CType(CurrentNumber, Integer) + 1
                txtPlotName.Text = txtPlotName.Text.Remove(index)

            End If
            txtPlotName.Text = txtPlotName.Text + "(" + increment.ToString() + ")"
            Me.PlotName = txtPlotName.Text
            increment += 1
        End While
    End Sub

    Private Sub PopulateLimitSelection()
        'Dim NumLimits As Integer = FilesAndData.Cell(1, 5) - FilesAndData.Cell(1, 4)
        For i As Integer = 2 To FilesAndData.ColSize
            Dim lim As New LimitSelector(FilesAndData.Cell(1, i))
            FlowLayoutPanel1.Controls.Add(lim)
            LimitList.Add(lim)
        Next

    End Sub

    'PASTED FROM CONTROL:
    Public Sub PopulateControl(ByVal FileData As Matrix, ByVal FandR As Matrix)
        Me.FilesAndData = FileData
        Me.FilesAndRanges = FandR
        Me.SelectedDataStore = New Matrix(FilesAndData.RowSize, FilesAndData.ColSize)

        For i As Integer = 1 To FilesAndData.RowSize
            clbFiles.Items.Add(FilesAndData.Cell(i, 1).ToString)
            For j As Integer = 2 To FilesAndData.ColSize

            Next
        Next

        clbFiles.SelectedIndex = 0
        PopulateLimitSelection()
    End Sub

    Private Sub PopulateControlA()

        Me.SelectedDataStore = New Matrix(FileList.Count, FileList.Item(0).NumCols)

        For i As Integer = 0 To FileList.Count - 1
            clbFiles.Items.Add(FileList(i).Name)
        Next

        clbFiles.SelectedIndex = 0
        PopulateLimitSelectionA()
    End Sub

    Private Sub PopulateLimitSelectionA()
        'Dim NumLimits As Integer = FilesAndData.Cell(1, 5) - FilesAndData.Cell(1, 4)
        Dim textfile As TextFileInfo = FileList(0)
        For i As Integer = 0 To textfile.NumCols - 2
            Dim lim As New LimitSelector(textfile.GetSeriesHeader(i))
            FlowLayoutPanel1.Controls.Add(lim)
            LimitList.Add(lim)
        Next

    End Sub

    Public Function ReturnPlotSelections() As PlotSeriesInfoCollection

        Dim SeriesList As New PlotSeriesInfoCollection
        Dim NextRow As Integer = 0

        For i As Integer = 1 To SelectedDataStore.RowSize

            For j As Integer = 2 To SelectedDataStore.ColSize
                If SelectedDataStore.Cell(i, j) = 1 Then
                    Dim PsI As New PlotSeriesInfo(FileList.Item(i - 1).TimeColumn, FileList.Item(i - 1).ColStart + j - 1, FileList.Item(i - 1).RowStart, FileList.Item(i - 1).RowEnd)
                    SeriesList.Add(PsI)
                End If
            Next
        Next

        Return SeriesList

    End Function

    'Public Function ReturnLimitSelections() As PlotLimitInfoCollection
    '    Dim PlotLimitList As New PlotLimitInfoCollection
    '    For Each lim As LimitSelector In LimitList
    '        If lim.PlotHotSurvLimit Then
    '            'Dim plim As New PlotLimitInfo(
    '        End If
    '    Next
    'End Function

    Private Sub clbFiles_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles clbFiles.SelectedIndexChanged
        'index is already updated in this call, so you need to save the last index
        SaveCurrent(LastFileIndex)
        LastFileIndex = clbFiles.SelectedIndex
        clbSeries.Items.Clear()

        'For j = 2 To FilesAndData.ColSize
        '    If FilesAndData.Cell(clbFiles.SelectedIndex + 1, j) Is Nothing Then
        '        Exit For
        '    Else
        '        clbSeries.Items.Add(FilesAndData.Cell(clbFiles.SelectedIndex + 1, j).ToString)
        '    End If

        'Next

        For i As Integer = 0 To CType(FileList(clbFiles.SelectedIndex), TextFileInfo).NumCols - 2
            clbSeries.Items.Add(CType(FileList(clbFiles.SelectedIndex), TextFileInfo).GetSeriesHeader(i))
        Next

        RecallNext(clbFiles.SelectedIndex)

    End Sub

    Public Sub SaveCurrent(ByVal index As Integer)
        'Dim FoundCheck As Boolean = False
        If clbSeries.Items.Count > 0 Then
            For i As Integer = 0 To clbSeries.Items.Count - 1
                If clbSeries.GetItemChecked(i) Then
                    SelectedDataStore.Cell(index + 1, i + 2) = 1
                    'FoundCheck = True
                Else
                    SelectedDataStore.Cell(index + 1, i + 2) = 0
                End If
            Next
            'If FoundCheck Then
            '    clbFiles.SetItemChecked(clbFiles.SelectedIndex, True)
            'End If
        Else

        End If
    End Sub

    Private Sub RecallNext(ByVal index As Integer)

        For i As Integer = 0 To clbSeries.Items.Count - 1
            If SelectedDataStore.Cell(index + 1, i + 2) = 1 Then
                clbSeries.SetItemChecked(i, True)
                'FoundCheck = True
            Else
                clbSeries.SetItemChecked(i, False)
            End If
        Next
    End Sub

    Private Sub clbSeries_ItemCheck(sender As Object, e As System.Windows.Forms.ItemCheckEventArgs) Handles clbSeries.ItemCheck
        'MessageBox.Show(e.NewValue.ToString)
        If clbSeries.CheckedIndices.Count = 1 And e.NewValue = CheckState.Unchecked Then
            clbFiles.SetItemChecked(clbFiles.SelectedIndex, False)
        ElseIf e.NewValue = CheckState.Checked Then
            clbFiles.SetItemChecked(clbFiles.SelectedIndex, True)
        End If

    End Sub

    Public Function IsAnythingSelected() As Boolean
        Dim ContainsData As Boolean = False
        For i As Integer = 1 To SelectedDataStore.RowSize
            For j As Integer = 2 To SelectedDataStore.ColSize
                If SelectedDataStore.Cell(i, j) = 1 Then
                    ContainsData = True
                    Return ContainsData
                End If
            Next
        Next
        Return ContainsData
    End Function

    Private Sub btnSelectAll_Click(sender As System.Object, e As System.EventArgs) Handles btnSelectAll.Click
        For i As Integer = 0 To clbSeries.Items.Count - 1
            clbSeries.SetItemChecked(i, True)
        Next
    End Sub

    Private Sub btnSelectNone_Click(sender As System.Object, e As System.EventArgs) Handles btnSelectNone.Click
        For i As Integer = 0 To clbSeries.Items.Count - 1
            clbSeries.SetItemChecked(i, False)
        Next
    End Sub

    Private Sub chkSelectedAsTemplate_CheckedChanged(sender As Object, e As System.EventArgs) Handles chkSelectedAsTemplate.CheckedChanged
        If chkSelectedAsTemplate.CheckState = CheckState.Checked Then

            clbFiles.SelectedIndex = 0
            clbFiles.Enabled = False
            SelectedDataStore = New Matrix
            For i As Integer = 0 To clbFiles.Items.Count - 1
                clbFiles.SetItemChecked(i, False)
            Next
        Else
            clbFiles.SelectedIndex = 0
            clbFiles.Enabled = True
        End If
    End Sub

   
End Class
﻿Imports System.Windows.Forms
Imports System.IO
Imports System.Collections

Public Class SetSavLibPath

    Public Sub New(ByVal Path As String)
        InitializeComponent()
        Me.txtPath.Text = Path
    End Sub

    Public ReadOnly Property GetPath As String
        Get
            Return Me.txtPath.Text
        End Get
    End Property

    Private Sub btnOk_Click(sender As Object, e As EventArgs) Handles btnOk.Click
        If (Me.txtPath.Text Is Nothing) Then
            MessageBox.Show("A path must be entered, or Cancel")
        ElseIf (Not File.Exists(Me.txtPath.Text)) Then
            MessageBox.Show(String.Concat("Error, ", Me.txtPath.Text, " does not exist, please provide new location"))
        Else
            Me.DialogResult = DialogResult.OK
            Me.Close()
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.DialogResult = DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub btnBrowse_Click(sender As Object, e As EventArgs) Handles btnBrowse.Click
        Dim openFileDialog As System.Windows.Forms.OpenFileDialog = New System.Windows.Forms.OpenFileDialog()
        If (openFileDialog.ShowDialog() = DialogResult.OK) Then
            Me.txtPath.Text = openFileDialog.FileName
        End If
    End Sub

    Private Sub btnAutoLocate_Click(sender As Object, e As EventArgs) Handles btnAutoLocate.Click

        AutoLocateSinapsLibrary()

    End Sub

    Public Function AutoLocateSinapsLibrary() As String
        If Directory.Exists("C:\Windows\Microsoft.NET\assembly\GAC_64\SinapsXNet") Then
            Dim startdir As New DirectoryInfo("C:\Windows\Microsoft.NET\assembly\GAC_64\SinapsXNet")
            Dim ModDate As New Date(1900, 1, 1)
            Dim MostRecentFolder As DirectoryInfo = Nothing
            'AutoLocateSinapsLibrary("C:\Windows\Microsoft.NET")
            'AutoLocateSinapsLibrary("C:\Windows\Microsoft.NET\assembly\GAC_32\SinapsXNet")
            'AutoLocateSinapsLibrary("D:\my_docs\00_Programming\FilePlottingTools\FilePlottingTools_v2.0\TESTSINAPSFIND")
            For Each subdir As DirectoryInfo In startdir.GetDirectories
                If subdir.CreationTime > ModDate Then
                    ModDate = subdir.CreationTime
                    MostRecentFolder = subdir
                End If
            Next

            If MostRecentFolder Is Nothing Then
                StatusBarText.Text = "Unable to find SinapsXnet.dll.  User must manually set file"
            Else
                txtPath.Text = MostRecentFolder.FullName + "\SinapsXNet.dll"
                StatusBarText.Text = "Library file found for TD version "
            End If
            Return txtPath.Text
        Else
            StatusBarText.Text = "Cannot find C:\Windows\Microsoft.NET\assembly\GAC_32\SinapsXNet, ExcelPlotter may not be installed"
            Return ""
        End If

    End Function

    'Public Function AutoLocateSinapsLibrary(ByVal StartDirectory As String) As String
    '    StatusBarText.Text = "Searching for Library..."
    '    Me.Refresh()
    '    Dim theFile As String = "SinapsXNet.dll"
    '    Dim TDVersionLibrarySizeTable As New Dictionary(Of String, Long)

    '    'enter new values intot the dictionary when new versions are released
    '    'make sure the latest version is the first value added to the dictionary
    '    'TDVersionLibrarySizeTable.Add("5.7", 1200640)
    '    TDVersionLibrarySizeTable.Add("5.7", 1206208)
    '    TDVersionLibrarySizeTable.Add("5.6", 1183232)

    '    Dim FileList As New ArrayList
    '    UsefulFunctions.FindAllFilesWithNameInFolder(StartDirectory, theFile, FileList)



    '    For Each Version As String In TDVersionLibrarySizeTable.Keys
    '        theFile = UsefulFunctions.FindFileNameWithSizeInFolders(StartDirectory, "SinapsXNet.dll", TDVersionLibrarySizeTable(Version))
    '        If theFile = "" Then
    '            'file was not found
    '        Else
    '            'a file was found for the current version
    '            txtPath.Text = theFile
    '            StatusBarText.Text = "Library file found for TD version " + Version + "!"
    '            Return theFile
    '        End If
    '    Next
    '    'no file was found
    '    StatusBarText.Text = "Unable to find SinapsXnet.dll.  User must manually set file"
    '    Return ""

    '    'Check for 5.7 library



    '    'MessageBox.Show(theFile)
    'End Function
End Class
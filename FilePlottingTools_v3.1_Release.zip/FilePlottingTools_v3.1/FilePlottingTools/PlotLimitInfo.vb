﻿Public Class PlotLimitInfo
    Public TimeCol As Integer
    Public TimeRow1 As Integer
    Public TimeRow2 As Integer
    Public LimitCol As Integer
    Public LimitRow As Integer

    Public Sub New(ByVal TimeCol As Integer, ByVal TimeRow1 As Integer, ByVal TimeRow2 As Integer, ByVal LimitCol As Integer, ByVal LimitRow As Integer)
        Me.TimeCol = TimeCol
        Me.TimeRow1 = TimeRow1
        Me.TimeRow2 = TimeRow2
        Me.LimitCol = LimitCol
        Me.LimitRow = LimitRow
    End Sub
End Class

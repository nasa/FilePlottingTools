﻿Public Class ChartSeriesModifier

    Private aChart As Excel.Chart
    Private IsLimitSeries As Boolean

    'references are the part of the formula,
    'i.e. could be 'sheet1'!A$3:A$20
    Public SeriesLegendReference As String
    Public XvaluesReference As String
    Public YvaluesReference As String

    Public LastRow As String
    Public Formula As String
    Public SheetName As String
    Public ColumnLetter As String

    'range strings take just the cell references
    'i.e. "$A$20:$A$50"
    Public XRangeString As String
    Public YRangeString As String

    'Private aWorkBook As Excel.Workbook
    'Private OriginalSeries As Excel.Series
    'Public NumberOfRows As Integer
    'Public StartRow As Integer
    'Public Order As Integer
    'Public DataSheet As Excel.Worksheet
    'Public ColumnNumber As Integer

    Public Sub New(ByVal Formula As String, ByVal IsLimitSeries As Boolean)
        Me.Formula = Formula
        Me.IsLimitSeries = IsLimitSeries

        If Me.IsLimitSeries Then
            ParseLimit()
        Else
            ParseFormula()
        End If

    End Sub

    Private Sub ParseFormula()

        'Start at first ' character in forumla, after =SERIES(
        'each call to GetSectionOfFormula updates CurrentChar
        Dim CurrentChar As Integer = 8


        'SJS 07-15-2015
        'Added this if statement to better parse series.  If a series name is blank,
        'or if it doesn't reference a sheet cell, the code in the ELSE part of this if
        'statement doesn't work.  The first part of the if statement checks to see if
        'there are only 3 commas in the formula.  If so, its easier to parse.
        'still need to add a check if there are more than 3 commas.

        Dim numCommas As Integer = UsefulFunctions.CountNumberOfSpecificCharInString(Me.Formula, ",")

        If numCommas = 3 Then
            'can use comma positions to parse the formula
            Dim ParenthesesLoc1 As Integer = Me.Formula.IndexOf("(")
            Dim CommaLoc1 As Integer = Me.Formula.IndexOf(",")
            Dim CommaLoc2 As Integer = Me.Formula.IndexOf(",", CommaLoc1 + 1)
            Dim CommaLoc3 As Integer = Me.Formula.IndexOf(",", CommaLoc2 + 1)

            Me.SeriesLegendReference = Me.Formula.Substring(ParenthesesLoc1 + 1, CommaLoc1 - ParenthesesLoc1 - 1)
            Me.XvaluesReference = Me.Formula.Substring(CommaLoc1 + 1, CommaLoc2 - CommaLoc1 - 1)
            Me.YvaluesReference = Me.Formula.Substring(CommaLoc2 + 1, CommaLoc3 - CommaLoc2 - 1)

        ElseIf numCommas > 3 And Me.Formula(Me.Formula.IndexOf("(") + 1) = """" Then
            'SJS TODO
            'there are still cases where this will fail:
            '   if the name contains quotes, like: "help" me   OR   help", me    OR  help" me
            '   in these situations, excel adds extra quotes as needed, so you need to check if double
            '   quotes exist, parse them out, and find the absolute last quote before a comma, which is hard
            '   if the name also contains quotes followed by commas
            'series name is a string and not a reference, and may contain a comma
            Dim ParenthesesLoc1 As Integer = Me.Formula.IndexOf("(")
            Dim SeriesNameEndQuoteLoc As Integer = Me.Formula.IndexOf("""", ParenthesesLoc1 + 2)
            Dim CommaLoc1 As Integer = Me.Formula.IndexOf(",", SeriesNameEndQuoteLoc + 1)
            Dim CommaLoc2 As Integer = Me.Formula.IndexOf(",", CommaLoc1 + 1)
            Dim CommaLoc3 As Integer = Me.Formula.IndexOf(",", CommaLoc2 + 1)

            Me.SeriesLegendReference = Me.Formula.Substring(ParenthesesLoc1 + 1, CommaLoc1 - ParenthesesLoc1 - 1)
            Me.XvaluesReference = Me.Formula.Substring(CommaLoc1 + 1, CommaLoc2 - CommaLoc1 - 1)
            Me.YvaluesReference = Me.Formula.Substring(CommaLoc2 + 1, CommaLoc3 - CommaLoc2 - 1)
        Else
            'SJS TODO
            'THIS SECTION CAN EASILY FAIL UNLESS THE SERIES WAS CREATED WITH THE FILEPLOTTINGTOOLS
            'INTERFACE.  IF IT WAS MANUALLY CREATED, IT WILL NOT WORK IF THE NAME IS BLANK OR IS A STRING
            'THIS NEEDS TO BE ELIMINATED EVENTUALLY.
            SeriesLegendReference = GetSectionOfFormula(CurrentChar, Me.Formula)
            XvaluesReference = GetSectionOfFormula(CurrentChar, Me.Formula)
            YvaluesReference = GetSectionOfFormula(CurrentChar, Me.Formula)

        End If


        'Dim i1 As Integer = Me.Formula.LastIndexOf(",") + 1
        'Dim i2 As Integer = Me.Formula.Count
        'Dim i3 As Integer = i2 - i1 - 1

        'Order = CType(Me.Formula.Substring(i1, i3), Integer)

        'SJS 07-15-2015
        'changed this to use XvaluesReference because the legend may not contain the sheet name
        'SheetName = SeriesLegendReference.Substring(1, SeriesLegendReference.LastIndexOf("'") - 1)
        If XvaluesReference.Contains("'!") Then
            'sheet name will contain this only if the sheet has a space in the name
            SheetName = XvaluesReference.Substring(1, XvaluesReference.LastIndexOf("'!") - 1)
        Else
            'if the sheet doesn't have a space, it will only contain a !
            SheetName = XvaluesReference.Substring(1, XvaluesReference.LastIndexOf("!") - 1)
        End If


        Dim i1 As Integer = XvaluesReference.LastIndexOf("$") + 1
        Dim i2 As Integer = Me.XvaluesReference.Count
        Dim i3 As Integer = i2 - i1 - 1

        LastRow = XvaluesReference.Substring(i1, i3)

        Me.XRangeString = ConvertToRangeString(XvaluesReference)
        Me.YRangeString = ConvertToRangeString(YvaluesReference)

    End Sub


    Private Function GetSectionOfFormula(ByRef StartIndex As Integer, ByVal theFormula As String) As String

        Dim Section As String = ""

        'this bool makes sure you read the entire sheet name
        'it could contain a comma, so you can't just stop when 
        'you hit the first comma in the formula
        Dim SheetNameIsRead As Boolean = False

        'The first character should be a "'", read this into the string before the loop
        'there is a check for the last "'" character defining the sheet name, so you have to
        'read this one first
        Section += theFormula(StartIndex)
        StartIndex += 1

        'loop through until you find the next comma
        While True
            If SheetNameIsRead Then
                If theFormula(StartIndex) = "," Then
                    StartIndex += 1
                    Exit While
                Else
                    Section += theFormula(StartIndex)
                End If
            Else
                Section += theFormula(StartIndex)
                If theFormula(StartIndex) = "'" Then
                    SheetNameIsRead = True
                End If
            End If
            StartIndex += 1
        End While

        Return Section
    End Function

    Private Sub ParseLimit()
        Dim i1 As Integer = 0
        i1 = Me.Formula.IndexOf(",") + 1
        Dim i2 As Integer = Me.Formula.IndexOf(",", i1)
        i2 = Me.Formula.IndexOf(",", i2 + 1) - 1

        XvaluesReference = Me.Formula.Substring(i1, i2 - i1 + 1)

        i1 = i2 + 2
        i2 = Me.Formula.IndexOf(",", i1)
        i2 = Me.Formula.IndexOf(",", i2 + 1) - 1

        YvaluesReference = Me.Formula.Substring(i1, i2 - i1 + 1)
        i1 = XvaluesReference.IndexOf("'")
        i2 = XvaluesReference.IndexOf("'", i1 + 1)

        SheetName = XvaluesReference.Substring(2, i2 - i1 - 1)

        i1 = XvaluesReference.IndexOf("$", i2) + 1
        i2 = XvaluesReference.IndexOf("$", i1)
        Me.ColumnLetter = XvaluesReference.Substring(i1, i2 - i1)

        i1 = XvaluesReference.LastIndexOf("$") + 1
        Me.LastRow = XvaluesReference.Substring(i1, XvaluesReference.Count - i1 - 1)
        'ColumnNumber = PlottingFunctions.GetExcelColumnName


    End Sub

    Private Function ConvertToRangeString(ByVal formstring As String) As String
        Dim charIndex As Integer = 0
        Dim numChars As Integer = 0

        charIndex = formstring.LastIndexOf("!") + 1

        numChars = formstring.Count - charIndex

        Return formstring.Substring(charIndex, numChars)

    End Function

    Public Sub ChangeLastCellInXvalues(ByVal NewLastRowNumber As Integer)

        Me.XvaluesReference = Me.XvaluesReference.Replace("$" + Me.LastRow, "$" + NewLastRowNumber.ToString)

    End Sub

End Class

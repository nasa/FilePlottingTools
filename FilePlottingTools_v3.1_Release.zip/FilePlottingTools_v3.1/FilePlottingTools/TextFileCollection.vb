﻿Public Class TextFileCollection
    Inherits Collections.CollectionBase

    Public Sub Add(ByVal file As TextFileInfo)
        Me.List.Add(file)
    End Sub

    Public Sub Remove(ByVal file As TextFileInfo)
        Me.List.Remove(file)
    End Sub

    Public Property Item(ByVal index As Integer) As TextFileInfo
        Get
            Return CType(Me.List.Item(index), TextFileInfo)
        End Get
        Set(ByVal value As TextFileInfo)
            Me.List.Item(index) = value
        End Set
    End Property

End Class

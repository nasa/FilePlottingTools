﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SeriesAndLimitSelector
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.chkCS = New System.Windows.Forms.CheckBox()
        Me.chkCO = New System.Windows.Forms.CheckBox()
        Me.chkHO = New System.Windows.Forms.CheckBox()
        Me.chkHS = New System.Windows.Forms.CheckBox()
        Me.chkPlot = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'chkCS
        '
        Me.chkCS.AutoSize = True
        Me.chkCS.BackColor = System.Drawing.Color.Blue
        Me.chkCS.Location = New System.Drawing.Point(343, 3)
        Me.chkCS.Name = "chkCS"
        Me.chkCS.Size = New System.Drawing.Size(40, 17)
        Me.chkCS.TabIndex = 8
        Me.chkCS.Text = "CS"
        Me.chkCS.UseVisualStyleBackColor = False
        '
        'chkCO
        '
        Me.chkCO.AutoSize = True
        Me.chkCO.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chkCO.Location = New System.Drawing.Point(304, 3)
        Me.chkCO.Name = "chkCO"
        Me.chkCO.Size = New System.Drawing.Size(41, 17)
        Me.chkCO.TabIndex = 7
        Me.chkCO.Text = "CO"
        Me.chkCO.UseVisualStyleBackColor = False
        '
        'chkHO
        '
        Me.chkHO.AutoSize = True
        Me.chkHO.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.chkHO.Location = New System.Drawing.Point(262, 3)
        Me.chkHO.Name = "chkHO"
        Me.chkHO.Size = New System.Drawing.Size(42, 17)
        Me.chkHO.TabIndex = 6
        Me.chkHO.Text = "HO"
        Me.chkHO.UseVisualStyleBackColor = False
        '
        'chkHS
        '
        Me.chkHS.AutoSize = True
        Me.chkHS.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chkHS.Location = New System.Drawing.Point(223, 3)
        Me.chkHS.Name = "chkHS"
        Me.chkHS.Size = New System.Drawing.Size(41, 17)
        Me.chkHS.TabIndex = 5
        Me.chkHS.Text = "HS"
        Me.chkHS.UseVisualStyleBackColor = False
        '
        'chkPlot
        '
        Me.chkPlot.AutoSize = True
        Me.chkPlot.Location = New System.Drawing.Point(3, 3)
        Me.chkPlot.Name = "chkPlot"
        Me.chkPlot.Size = New System.Drawing.Size(55, 17)
        Me.chkPlot.TabIndex = 10
        Me.chkPlot.Text = "Series"
        Me.chkPlot.UseVisualStyleBackColor = True
        '
        'SeriesAndLimitSelector
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.Controls.Add(Me.chkPlot)
        Me.Controls.Add(Me.chkCS)
        Me.Controls.Add(Me.chkCO)
        Me.Controls.Add(Me.chkHO)
        Me.Controls.Add(Me.chkHS)
        Me.Margin = New System.Windows.Forms.Padding(1)
        Me.Name = "SeriesAndLimitSelector"
        Me.Size = New System.Drawing.Size(388, 21)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents chkCS As System.Windows.Forms.CheckBox
    Friend WithEvents chkCO As System.Windows.Forms.CheckBox
    Friend WithEvents chkHO As System.Windows.Forms.CheckBox
    Friend WithEvents chkHS As System.Windows.Forms.CheckBox
    Friend WithEvents chkPlot As System.Windows.Forms.CheckBox

End Class

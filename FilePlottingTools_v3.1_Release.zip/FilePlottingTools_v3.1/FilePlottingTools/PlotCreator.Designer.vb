﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PlotCreator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SplitContainer02 = New System.Windows.Forms.SplitContainer()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.btnCustomPlot = New System.Windows.Forms.Button()
        Me.btnPlotCompare = New System.Windows.Forms.Button()
        Me.btnPlotForEachFile = New System.Windows.Forms.Button()
        Me.SplitContainer002 = New System.Windows.Forms.SplitContainer()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.SplitContainer03 = New System.Windows.Forms.SplitContainer()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.FileListBox = New System.Windows.Forms.CheckedListBox()
        Me.SplitContainer01 = New System.Windows.Forms.SplitContainer()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOk = New System.Windows.Forms.Button()
        Me.txtPlotName = New System.Windows.Forms.TextBox()
        CType(Me.SplitContainer02, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer02.Panel1.SuspendLayout()
        Me.SplitContainer02.Panel2.SuspendLayout()
        Me.SplitContainer02.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.SplitContainer002, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer002.Panel1.SuspendLayout()
        Me.SplitContainer002.Panel2.SuspendLayout()
        Me.SplitContainer002.SuspendLayout()
        CType(Me.SplitContainer03, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer03.Panel1.SuspendLayout()
        Me.SplitContainer03.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.SplitContainer01, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer01.Panel1.SuspendLayout()
        Me.SplitContainer01.Panel2.SuspendLayout()
        Me.SplitContainer01.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer02
        '
        Me.SplitContainer02.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer02.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer02.IsSplitterFixed = True
        Me.SplitContainer02.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer02.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.SplitContainer02.Name = "SplitContainer02"
        '
        'SplitContainer02.Panel1
        '
        Me.SplitContainer02.Panel1.BackColor = System.Drawing.SystemColors.Control
        Me.SplitContainer02.Panel1.Controls.Add(Me.TableLayoutPanel1)
        '
        'SplitContainer02.Panel2
        '
        Me.SplitContainer02.Panel2.Controls.Add(Me.SplitContainer002)
        Me.SplitContainer02.Size = New System.Drawing.Size(804, 604)
        Me.SplitContainer02.SplitterDistance = 150
        Me.SplitContainer02.SplitterWidth = 5
        Me.SplitContainer02.TabIndex = 3
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.btnCustomPlot, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.btnPlotCompare, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.btnPlotForEachFile, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 4
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 49.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 49.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 49.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(150, 604)
        Me.TableLayoutPanel1.TabIndex = 3
        '
        'btnCustomPlot
        '
        Me.btnCustomPlot.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnCustomPlot.AutoSize = True
        Me.btnCustomPlot.BackColor = System.Drawing.Color.FromArgb(CType(CType(233, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.btnCustomPlot.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnCustomPlot.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnCustomPlot.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCustomPlot.Location = New System.Drawing.Point(4, 6)
        Me.btnCustomPlot.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnCustomPlot.Name = "btnCustomPlot"
        Me.btnCustomPlot.Size = New System.Drawing.Size(142, 36)
        Me.btnCustomPlot.TabIndex = 0
        Me.btnCustomPlot.Text = "Custom Plot"
        Me.btnCustomPlot.UseVisualStyleBackColor = False
        '
        'btnPlotCompare
        '
        Me.btnPlotCompare.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnPlotCompare.AutoSize = True
        Me.btnPlotCompare.BackColor = System.Drawing.Color.FromArgb(CType(CType(233, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.btnPlotCompare.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnPlotCompare.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnPlotCompare.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPlotCompare.Location = New System.Drawing.Point(4, 104)
        Me.btnPlotCompare.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnPlotCompare.Name = "btnPlotCompare"
        Me.btnPlotCompare.Size = New System.Drawing.Size(142, 36)
        Me.btnPlotCompare.TabIndex = 2
        Me.btnPlotCompare.Text = "Comparison Plot"
        Me.btnPlotCompare.UseVisualStyleBackColor = False
        '
        'btnPlotForEachFile
        '
        Me.btnPlotForEachFile.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnPlotForEachFile.AutoSize = True
        Me.btnPlotForEachFile.BackColor = System.Drawing.Color.FromArgb(CType(CType(233, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.btnPlotForEachFile.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnPlotForEachFile.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnPlotForEachFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPlotForEachFile.Location = New System.Drawing.Point(4, 55)
        Me.btnPlotForEachFile.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnPlotForEachFile.Name = "btnPlotForEachFile"
        Me.btnPlotForEachFile.Size = New System.Drawing.Size(142, 36)
        Me.btnPlotForEachFile.TabIndex = 1
        Me.btnPlotForEachFile.Text = "Plot For Each File"
        Me.btnPlotForEachFile.UseVisualStyleBackColor = False
        '
        'SplitContainer002
        '
        Me.SplitContainer002.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer002.IsSplitterFixed = True
        Me.SplitContainer002.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer002.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.SplitContainer002.Name = "SplitContainer002"
        Me.SplitContainer002.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer002.Panel1
        '
        Me.SplitContainer002.Panel1.Controls.Add(Me.txtDescription)
        '
        'SplitContainer002.Panel2
        '
        Me.SplitContainer002.Panel2.Controls.Add(Me.SplitContainer03)
        Me.SplitContainer002.Size = New System.Drawing.Size(649, 604)
        Me.SplitContainer002.SplitterDistance = 74
        Me.SplitContainer002.SplitterWidth = 5
        Me.SplitContainer002.TabIndex = 4
        '
        'txtDescription
        '
        Me.txtDescription.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtDescription.Enabled = False
        Me.txtDescription.Location = New System.Drawing.Point(0, 0)
        Me.txtDescription.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtDescription.Multiline = True
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(649, 74)
        Me.txtDescription.TabIndex = 0
        '
        'SplitContainer03
        '
        Me.SplitContainer03.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer03.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer03.IsSplitterFixed = True
        Me.SplitContainer03.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer03.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.SplitContainer03.Name = "SplitContainer03"
        Me.SplitContainer03.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer03.Panel1
        '
        Me.SplitContainer03.Panel1.Controls.Add(Me.GroupBox1)
        Me.SplitContainer03.Size = New System.Drawing.Size(649, 525)
        Me.SplitContainer03.SplitterDistance = 215
        Me.SplitContainer03.SplitterWidth = 5
        Me.SplitContainer03.TabIndex = 3
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.FileListBox)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(649, 215)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "File List"
        '
        'FileListBox
        '
        Me.FileListBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FileListBox.FormattingEnabled = True
        Me.FileListBox.Location = New System.Drawing.Point(4, 19)
        Me.FileListBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.FileListBox.Name = "FileListBox"
        Me.FileListBox.Size = New System.Drawing.Size(641, 192)
        Me.FileListBox.TabIndex = 2
        '
        'SplitContainer01
        '
        Me.SplitContainer01.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer01.FixedPanel = System.Windows.Forms.FixedPanel.Panel2
        Me.SplitContainer01.IsSplitterFixed = True
        Me.SplitContainer01.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer01.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.SplitContainer01.Name = "SplitContainer01"
        Me.SplitContainer01.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer01.Panel1
        '
        Me.SplitContainer01.Panel1.Controls.Add(Me.SplitContainer02)
        '
        'SplitContainer01.Panel2
        '
        Me.SplitContainer01.Panel2.Controls.Add(Me.TableLayoutPanel2)
        Me.SplitContainer01.Size = New System.Drawing.Size(804, 660)
        Me.SplitContainer01.SplitterDistance = 604
        Me.SplitContainer01.SplitterWidth = 5
        Me.SplitContainer01.TabIndex = 4
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 4
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.85714!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.14286!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 123.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.Label1, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.btnCancel, 3, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.btnOk, 2, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.txtPlotName, 1, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(804, 51)
        Me.TableLayoutPanel2.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(91, 17)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(145, 17)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Plot Worksheet Name"
        '
        'btnCancel
        '
        Me.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnCancel.AutoSize = True
        Me.btnCancel.Location = New System.Drawing.Point(692, 9)
        Me.btnCancel.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(100, 33)
        Me.btnCancel.TabIndex = 3
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnOk
        '
        Me.btnOk.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnOk.AutoSize = True
        Me.btnOk.Location = New System.Drawing.Point(570, 9)
        Me.btnOk.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.Size = New System.Drawing.Size(100, 33)
        Me.btnOk.TabIndex = 4
        Me.btnOk.Text = "Ok"
        Me.btnOk.UseVisualStyleBackColor = True
        '
        'txtPlotName
        '
        Me.txtPlotName.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPlotName.Location = New System.Drawing.Point(244, 14)
        Me.txtPlotName.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtPlotName.Name = "txtPlotName"
        Me.txtPlotName.Size = New System.Drawing.Size(312, 22)
        Me.txtPlotName.TabIndex = 5
        '
        'PlotCreator
        '
        Me.AcceptButton = Me.btnOk
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(804, 660)
        Me.Controls.Add(Me.SplitContainer01)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.MinimumSize = New System.Drawing.Size(819, 696)
        Me.Name = "PlotCreator"
        Me.Text = "PlotCreator"
        Me.SplitContainer02.Panel1.ResumeLayout(False)
        Me.SplitContainer02.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer02, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer02.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.SplitContainer002.Panel1.ResumeLayout(False)
        Me.SplitContainer002.Panel1.PerformLayout()
        Me.SplitContainer002.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer002, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer002.ResumeLayout(False)
        Me.SplitContainer03.Panel1.ResumeLayout(False)
        CType(Me.SplitContainer03, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer03.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.SplitContainer01.Panel1.ResumeLayout(False)
        Me.SplitContainer01.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer01, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer01.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer02 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer01 As System.Windows.Forms.SplitContainer
    Friend WithEvents btnOk As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnCustomPlot As System.Windows.Forms.Button
    Friend WithEvents SplitContainer03 As System.Windows.Forms.SplitContainer
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents FileListBox As System.Windows.Forms.CheckedListBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnPlotForEachFile As System.Windows.Forms.Button
    Friend WithEvents btnPlotCompare As System.Windows.Forms.Button
    Friend WithEvents SplitContainer002 As System.Windows.Forms.SplitContainer
    Friend WithEvents txtDescription As System.Windows.Forms.TextBox
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents txtPlotName As System.Windows.Forms.TextBox
End Class

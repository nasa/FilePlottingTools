﻿Public Class SubmodelInfo
    'THIS CLASS IS USED FOR BOTH REGISTERS, AND NODES
    'NAME CAN BE EITHER THE SUBMODEL NAME, OR "REGISTER"
    'THE NODES COLLECTION CAN BE EITHER NODE NUMBER, OR REGISTER NAME

    Private name
    Private Nodes As New Collections.Specialized.StringCollection

    Public Sub New(ByVal SubmodelName As String, ByVal Nodes As Long())
        Me.name = SubmodelName
        Dim s1(Nodes.Count - 1) As String

        For Each item As Long In Nodes
            Me.Nodes.Add(CStr(item))
        Next

    End Sub

    Public Sub New(ByVal SubmodelName As String, ByVal Nodes As Collections.Specialized.StringCollection)
        Me.name = SubmodelName
        Me.Nodes = Nodes
    End Sub

    Public Sub New(ByVal SubmodelName As String)
        Me.name = SubmodelName
        'Me.Nodes = Nodes

    End Sub


    Public ReadOnly Property SubModelName As String
        Get
            Return Me.name
        End Get
    End Property

    Public ReadOnly Property NumberOfNodes As Integer
        Get
            Return Nodes.Count
        End Get
    End Property

    Public ReadOnly Property GetNode(ByVal index As Integer) As String
        Get
            Return Nodes(index)
        End Get
    End Property

    Public ReadOnly Property GetAllNodes As Collections.Specialized.StringCollection
        Get
            Return Me.Nodes
        End Get
    End Property

    Public Sub AddNodeNumber(ByVal num As Long)

        Me.Nodes.Add(CStr(num))

        'If Me.Nodes Is Nothing Then
        '    Dim NewList(0) As Long
        '    Me.Nodes = NewList
        '    Nodes(0) = num
        'Else
        '    Dim size As Integer = Nodes.Count
        '    Array.Resize(Nodes, size + 1)
        '    Nodes(size) = num
        'End If
    End Sub

    Public Sub AddNodeNumber(ByVal num As String)

        Me.Nodes.Add(num)

        'If Me.Nodes Is Nothing Then
        '    Dim NewList(0) As Long
        '    Me.Nodes = NewList
        '    Nodes(0) = num
        'Else
        '    Dim size As Integer = Nodes.Count
        '    Array.Resize(Nodes, size + 1)
        '    Nodes(size) = num
        'End If
    End Sub

    Public ReadOnly Property NodeNumberExists(ByVal num As Long) As Boolean
        Get
            Dim numstring As String = CStr(num)
            For Each number As String In Me.Nodes
                If number = numstring Then
                    Return True
                End If
            Next
            Return False
        End Get
    End Property

    Public ReadOnly Property NodeNumberExists(ByVal num As String) As Boolean
        Get
            For Each number As String In Me.Nodes
                If number = num Then
                    Return True
                End If
            Next
            Return False
        End Get
    End Property
End Class

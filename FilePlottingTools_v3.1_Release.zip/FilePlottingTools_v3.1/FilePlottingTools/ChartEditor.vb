﻿Imports System.Collections
Imports System.Windows.Forms
Imports System.Drawing
Imports Microsoft.Office.Core

Public Class ChartEditor
    'Public ChartList As New Matrix
    Public ChartList As New ArrayList
    Public ThisWorkbook As Excel.Workbook = Globals.ThisAddIn.Application.ActiveWorkbook

    'SJS 05-01-15 ADDED THESE FROM DECOMPILED CODE
    Public SeriesFormatter As New SeriesEditor
    Private ModifySeriesFormats As Boolean = False


    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()
        Me.AutoScaleMode = Windows.Forms.AutoScaleMode.Dpi

        ' Add any initialization after the InitializeComponent() call.
        'MessageBox.Show("after initialize Component")
        If ThisWorkbook.Charts.Count >= 1 Then
            'MessageBox.Show("charts greater than 1: " + ThisWorkbook.Charts.Count.ToString)
            'SJS 05-08-15 CHANGED START OF LOOP TO 1 AFTER REMOVING TEMPLATECHART
            For i As Integer = 1 To ThisWorkbook.Charts.Count
                Dim CurrentChart As Excel.Chart = ThisWorkbook.Charts(i)
                If CurrentChart.ChartType = Excel.XlChartType.xlXYScatter Or CurrentChart.ChartType = Excel.XlChartType.xlXYScatterLines Or CurrentChart.ChartType = Excel.XlChartType.xlXYScatterLinesNoMarkers Or CurrentChart.ChartType = Excel.XlChartType.xlXYScatterSmooth Or CurrentChart.ChartType = Excel.XlChartType.xlXYScatterSmoothNoMarkers Then

                    'add a check so that you don't display any very-hidden charts
                    'did this to avoid showing the template chart if you are upgrading from 1.1
                    'and you press the plot manager button before another button
                    If CurrentChart.Visible = Excel.XlSheetVisibility.xlSheetVeryHidden Then
                    Else
                        Dim NewChartInfo As New ChartProps(CurrentChart, i)
                        ChartList.Add(NewChartInfo)
                        lstFiles.Items.Add(NewChartInfo.Name)
                        'MessageBox.Show(i.ToString + vbTab + NewChartInfo.Name)
                    End If

                End If

                    'If a chart is active, then set that chart as the selected on in the 
                    'list
                    If Me.ThisWorkbook.ActiveChart Is Nothing Then
                    Else
                        If CurrentChart.Index = Me.ThisWorkbook.ActiveChart.Index Then
                            lstFiles.SelectedIndex = lstFiles.Items.Count - 1
                        End If
                    End If


            Next
            'MessageBox.Show("exit for loop")
            'Me.ThisWorkbook.ActiveChart.Index(-1)
            'MessageBox.Show(lstFiles.SelectedIndex.ToString)
            'If no chart was active, set the first chart in the list to be selected
            If lstFiles.SelectedIndex = -1 Then
                lstFiles.SelectedIndex = 0
            End If
        Else
            MessageBox.Show("There are no Chart Sheets in the Workbook to Format")
        End If



    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
        Me.Close()

    End Sub

    Private Sub btnOk_Click(sender As System.Object, e As System.EventArgs) Handles btnOk.Click
        Me.DialogResult = Windows.Forms.DialogResult.OK
        UpdateCharts()
        Me.Close()
    End Sub

    Private Sub lstFiles_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles lstFiles.SelectedIndexChanged
        If chkXlimSameForAll.Checked = True Then
            AutoSelectXLimits()
        End If

        If chkYlimSameForAll.Checked = True Then
            AutoSelectYLimits()
        End If
    End Sub

    Private Sub AutoSelectXLimits()
        Dim Xmax As Double = -1000000000.0
        Dim Xmin As Double = 1000000000.0

        For i As Integer = 0 To lstFiles.SelectedIndices.Count - 1
            If CType(ChartList.Item(lstFiles.SelectedIndices(i)), ChartProps).XlimMax > Xmax Then
                Xmax = CType(ChartList.Item(lstFiles.SelectedIndices(i)), ChartProps).XlimMax
            End If

            If CType(ChartList.Item(lstFiles.SelectedIndices(i)), ChartProps).XlimMin < Xmin Then
                Xmin = CType(ChartList.Item(lstFiles.SelectedIndices(i)), ChartProps).XlimMin
            End If

        Next

        txtXlimMax.Text = Xmax
        txtXlimMin.Text = Xmin

        txtXlimMax.Enabled = False
        txtXlimMin.Enabled = False


    End Sub

    Private Sub AutoSelectYLimits()

        Dim Ymax As Double = -1000000000.0
        Dim Ymin As Double = 1000000000.0

        For i As Integer = 0 To lstFiles.SelectedIndices.Count - 1

            If CType(ChartList.Item(lstFiles.SelectedIndices(i)), ChartProps).YlimMax > Ymax Then
                Ymax = CType(ChartList.Item(lstFiles.SelectedIndices(i)), ChartProps).YlimMax
            End If

            If CType(ChartList.Item(lstFiles.SelectedIndices(i)), ChartProps).YlimMin < Ymin Then
                Ymin = CType(ChartList.Item(lstFiles.SelectedIndices(i)), ChartProps).YlimMin
            End If

        Next

        txtYlimMax.Text = Ymax
        txtYlimMin.Text = Ymin

    End Sub

    Private Sub chkXlimAutoSelect_CheckedChanged(sender As Object, e As System.EventArgs) Handles chkXlimSameForAll.CheckedChanged
        If chkXlimSameForAll.Checked = True Then
            AutoSelectXLimits()
            chkXAutoScale.Checked = False
            txtXlimMax.Enabled = False
            txtXlimMin.Enabled = False
        Else
            txtXlimMax.Enabled = True
            txtXlimMin.Enabled = True
        End If
    End Sub

    Private Sub chkYlimAutoSelect_CheckedChanged(sender As Object, e As System.EventArgs) Handles chkYlimSameForAll.CheckedChanged
        If chkYlimSameForAll.Checked = True Then
            AutoSelectYLimits()
            chkYAutoScale.Checked = False
            txtYlimMax.Enabled = False
            txtYlimMin.Enabled = False
        Else
            txtYlimMax.Enabled = True
            txtYlimMin.Enabled = True
        End If
    End Sub

    Private Sub UpdateCharts()
        For Each i As Integer In lstFiles.SelectedIndices
            Dim ChartInfo As ChartProps = ChartList.Item(i)
            Dim CurrentChart As Excel.Chart = ThisWorkbook.Charts(ChartInfo.index)
            Dim Xaxis As Excel.Axis = CurrentChart.Axes(Excel.XlAxisType.xlCategory)
            Dim Yaxis As Excel.Axis = CurrentChart.Axes(Excel.XlAxisType.xlValue)

            'Set Xaxis max value to fixed value
            If txtXlimMax.Text = String.Empty Then
            Else
                Xaxis.MaximumScaleIsAuto = False
                Xaxis.MaximumScale = CType(txtXlimMax.Text, Double)
            End If

            'Set Xaxis minimum value to fixed value
            If txtXlimMin.Text = String.Empty Then
            Else
                Xaxis.MinimumScaleIsAuto = False
                Xaxis.MinimumScale = CType(txtXlimMin.Text, Double)
            End If

            'Set Yaxis max value to fixed value
            If txtYlimMax.Text = String.Empty Then
            Else
                Yaxis.MaximumScaleIsAuto = False
                Yaxis.MaximumScale = CType(txtYlimMax.Text, Double)
            End If

            'Set Yaxis minimum value to fixed value
            If txtYlimMin.Text = String.Empty Then
            Else
                Yaxis.MinimumScaleIsAuto = False
                Yaxis.MinimumScale = CType(txtYlimMin.Text, Double)
            End If

            'Set Xaxis limits to Auto
            If chkXAutoScale.Checked = True Then
                Xaxis.MaximumScaleIsAuto = True
                Xaxis.MinimumScaleIsAuto = True
            End If

            'Set Yaxis limits to Auto
            If chkYAutoScale.Checked = True Then
                Yaxis.MaximumScaleIsAuto = True
                Yaxis.MinimumScaleIsAuto = True
            End If

            'Change Global Font Size
            If txtGlobalFontSize.Text = String.Empty Then
            Else
                CurrentChart.ChartArea.Font.Size = CType(txtGlobalFontSize.Text, Integer)
            End If

            'Change Legend Font Size
            If txtLegendFontSize.Text = String.Empty Then
            Else
                CurrentChart.Legend.Font.Size = CType(txtLegendFontSize.Text, Integer)
            End If

            'Change X Tick Number Font Size
            If txtXAxisFontSize.Text = String.Empty Then
            Else
                Xaxis.TickLabels.Font.Size = CType(txtXAxisFontSize.Text, Integer)
            End If

            'Change Y Axis Font Size
            If txtYAxisFontSize.Text = String.Empty Then
            Else
                Yaxis.TickLabels.Font.Size = CType(txtYAxisFontSize.Text, Integer)
            End If

            'Change X Label Font Size
            If txtXLabelFontSize.Text = String.Empty Then
            Else
                Xaxis.AxisTitle.Font.Size = CType(txtXLabelFontSize.Text, Integer)
            End If

            'Change Y Label Font Size
            If txtYLabelFontSize.Text = String.Empty Then
            Else
                Yaxis.AxisTitle.Font.Size = CType(txtYLabelFontSize.Text, Integer)
            End If


            Dim DefaultRightLegendWidth As Double = 100
            Dim DefaultTopLegendHeight As Double = 62

            'Add Title
            If rdbTitleNoChange.Checked Then
            ElseIf rdbTitleYes.Checked Then
                CurrentChart.HasTitle = True
                CurrentChart.ChartTitle.Text = CurrentChart.Name
                If txtSizeTitle.Text = "" Then
                Else
                    CurrentChart.ChartTitle.Font.Size = CType(txtSizeTitle.Text, Integer)
                End If
                'this if statment checks difference between plot area and legend tops to figure
                'if its a top or right legend
                'If Math.Abs(CurrentChart.PlotArea.Top - CurrentChart.Legend.Top) > 10 Then
                If CurrentChart.Legend.Left > 120 Then
                    'legend is right
                    'PlottingFunctions.SetLegendLocation(CurrentChart, LegendLocation.top, True)
                    PlottingFunctions.ArrangeChartArea(CurrentChart, LegendLocation.right, 50, DefaultRightLegendWidth)
                Else
                    'PlottingFunctions.SetLegendLocation(CurrentChart, LegendLocation.right, True)
                    PlottingFunctions.ArrangeChartArea(CurrentChart, LegendLocation.top, 50, DefaultTopLegendHeight)
                End If
            ElseIf rdbTitleNo.Checked Then
                CurrentChart.HasTitle = False
                'this if statment checks difference between plot area and legend tops to figure
                'if its a top or right legend
                'If Math.Abs(CurrentChart.PlotArea.Top - CurrentChart.Legend.Top) > 25 Then
                '    PlottingFunctions.SetLegendLocation(CurrentChart, LegendLocation.top, False)
                'Else
                '    PlottingFunctions.SetLegendLocation(CurrentChart, LegendLocation.right, False)
                'End If
                If CurrentChart.Legend.Left > 120 Then
                    'legend is right
                    'PlottingFunctions.SetLegendLocation(CurrentChart, LegendLocation.top, True)
                    PlottingFunctions.ArrangeChartArea(CurrentChart, LegendLocation.right, 0, DefaultRightLegendWidth)
                Else
                    'PlottingFunctions.SetLegendLocation(CurrentChart, LegendLocation.right, True)
                    PlottingFunctions.ArrangeChartArea(CurrentChart, LegendLocation.top, 0, DefaultTopLegendHeight)
                End If
            End If

            'Legend location
            Dim TopMargin As Double = 0
            If CurrentChart.HasTitle Then
                TopMargin = 50
            End If
            If chkTopLegend.Checked = True Then

                If txtLegendHeight.Text = "" Then
                    'PlottingFunctions.SetLegendLocation(CurrentChart, LegendLocation.top, False)
                    PlottingFunctions.ArrangeChartArea(CurrentChart, LegendLocation.top, TopMargin, 62)
                Else
                    PlottingFunctions.ArrangeChartArea(CurrentChart, LegendLocation.top, TopMargin, CType(txtLegendHeight.Text, Double))
                End If

            ElseIf chkRightLegend.Checked = True Then
                If txtLegendWidth.Text = "" Then
                    'PlottingFunctions.SetLegendLocation(CurrentChart, LegendLocation.top, False)
                    PlottingFunctions.ArrangeChartArea(CurrentChart, LegendLocation.right, TopMargin, 100)
                Else
                    PlottingFunctions.ArrangeChartArea(CurrentChart, LegendLocation.right, TopMargin, CType(txtLegendWidth.Text, Double))
                End If
            End If



            'X AXIS MAJOR TICKS
            If chkAutoXMajorTicks.Checked = True Then
                Xaxis.MajorUnitIsAuto = True
            ElseIf txtXMajorTicks.Text = String.Empty Then
            Else
                Xaxis.MajorUnit = CType(txtXMajorTicks.Text, Double)
            End If

            'X AXIS MINOR TICKS
            If chkAutoXMinorTicks.Checked = True Then
                Xaxis.MinorUnitIsAuto = True
                Xaxis.MinorTickMark = Excel.XlTickMark.xlTickMarkInside
            ElseIf chkXMinorTicks.Checked = True Then
                'remove ticks
                Xaxis.MinorTickMark = Excel.XlTickMark.xlTickMarkNone
            ElseIf txtXMinorTicks.Text = String.Empty Then
                'do nothing
            Else
                Xaxis.MinorUnit = CType(txtXMinorTicks.Text, Double)
                Xaxis.MinorTickMark = Excel.XlTickMark.xlTickMarkInside
            End If

            'Y AXIS MAJOR TICKS
            If chkAutoYMajorTicks.Checked = True Then
                Yaxis.MajorUnitIsAuto = True
            ElseIf txtYMajorTicks.Text = String.Empty Then
                'do nothing
            Else
                Yaxis.MajorUnit = CType(txtYMajorTicks.Text, Double)
            End If

            'Y AXIS MINOR TICKS
            If chkAutoYMinorTicks.Checked = True Then
                Yaxis.MinorUnitIsAuto = True
                Yaxis.MinorTickMark = Excel.XlTickMark.xlTickMarkInside
            ElseIf chkYMinorTicks.Checked = True Then
                'remove ticks
                Yaxis.MinorTickMark = Excel.XlTickMark.xlTickMarkNone
            ElseIf txtYMinorTicks.Text = String.Empty Then
                'do nothing
            Else
                Yaxis.MinorUnit = CType(txtYMinorTicks.Text, Double)
                Yaxis.MinorTickMark = Excel.XlTickMark.xlTickMarkInside
            End If

            'X AXIS TICK MARK POSITION
            If rdbXTickPosNoChange.Checked Then
            ElseIf rdbXTickPosInside.Checked Then
                Xaxis.MajorTickMark = Excel.XlTickMark.xlTickMarkInside
                If Xaxis.MinorTickMark <> Excel.XlTickMark.xlTickMarkNone Then
                    Xaxis.MinorTickMark = Excel.XlTickMark.xlTickMarkInside
                End If
            ElseIf rdbXTickPosOutside.Checked Then
                Xaxis.MajorTickMark = Excel.XlTickMark.xlTickMarkOutside
                If Xaxis.MinorTickMark <> Excel.XlTickMark.xlTickMarkNone Then
                    Xaxis.MinorTickMark = Excel.XlTickMark.xlTickMarkOutside
                End If
            ElseIf rdbXTickPosCross.Checked Then
                Xaxis.MajorTickMark = Excel.XlTickMark.xlTickMarkCross
                If Xaxis.MinorTickMark <> Excel.XlTickMark.xlTickMarkNone Then
                    Xaxis.MinorTickMark = Excel.XlTickMark.xlTickMarkCross
                End If
            End If

            'Y AXIS TICK MARK POSITION
            If rdbYTickPosNoChange.Checked Then
            ElseIf rdbYTickPosInside.Checked Then
                Yaxis.MajorTickMark = Excel.XlTickMark.xlTickMarkInside
                If Yaxis.MinorTickMark <> Excel.XlTickMark.xlTickMarkNone Then
                    Yaxis.MinorTickMark = Excel.XlTickMark.xlTickMarkInside
                End If
            ElseIf rdbYTickPosOutside.Checked Then
                Yaxis.MajorTickMark = Excel.XlTickMark.xlTickMarkOutside
                If Yaxis.MinorTickMark <> Excel.XlTickMark.xlTickMarkNone Then
                    Yaxis.MinorTickMark = Excel.XlTickMark.xlTickMarkOutside
                End If
            ElseIf rdbYTickPosCross.Checked Then
                Yaxis.MajorTickMark = Excel.XlTickMark.xlTickMarkCross
                If Yaxis.MinorTickMark <> Excel.XlTickMark.xlTickMarkNone Then
                    Yaxis.MinorTickMark = Excel.XlTickMark.xlTickMarkCross
                End If
            End If

            'X Axis Gridlines
            If chkXGridMajor.Checked Then
                Xaxis.HasMajorGridlines = True
            End If

            If chkXGridMinor.Checked Then
                Xaxis.HasMinorGridlines = True
            End If

            If chkXGridNone.Checked Then
                Xaxis.HasMajorGridlines = False
                Xaxis.HasMinorGridlines = False
            End If

            If Xaxis.HasMajorGridlines Then
                If rdbXGridDash.Checked Then
                    Xaxis.MajorGridlines.Format.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineRoundDot
                ElseIf rdbXGridSolid.Checked Then
                    Xaxis.MajorGridlines.Format.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineSolid
                End If
            End If
            If Xaxis.HasMinorGridlines Then
                If rdbXGridDash.Checked Then
                    Xaxis.MinorGridlines.Format.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineRoundDot
                ElseIf rdbXGridSolid.Checked Then
                    Xaxis.MinorGridlines.Format.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineSolid
                End If
            End If

            'Y Axis Gridlines
            If chkYGridMajor.Checked Then
                Yaxis.HasMajorGridlines = True
            End If

            If chkYGridMinor.Checked Then
                Yaxis.HasMinorGridlines = True
            End If

            If chkYGridNone.Checked Then
                Yaxis.HasMajorGridlines = False
                Yaxis.HasMinorGridlines = False
            End If

            If Yaxis.HasMajorGridlines Then
                If rdbYGridDash.Checked Then
                    Yaxis.MajorGridlines.Format.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineRoundDot
                ElseIf rdbYGridSolid.Checked Then
                    Yaxis.MajorGridlines.Format.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineSolid
                Else

                End If
            End If
            If Yaxis.HasMinorGridlines Then
                If rdbYGridDash.Checked Then
                    Yaxis.MinorGridlines.Format.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineRoundDot
                ElseIf rdbYGridSolid.Checked Then
                    Yaxis.MinorGridlines.Format.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineSolid
                Else

                End If
            End If

            '-----------------
            'SJS 05-01-15 ADDED BACK FROM DECOMPILED CODE:
            If Me.ModifySeriesFormats Then
                Dim num4 As Integer = 0

                For Each ser As Excel.Series In CurrentChart.SeriesCollection
                    If (String.Compare(ser.Name, "Limit", False) <> 0) Then
                        Dim seriesFormatInfo As FilePlottingTools.SeriesFormatInfo = DirectCast(Me.SeriesFormatter.SeriesArray(num4), FilePlottingTools.SeriesFormatInfo)
                        ser.Border.Color = ColorTranslator.ToOle(seriesFormatInfo.LineColor)
                        ser.Format.Line.Weight = CSng(seriesFormatInfo.LineWeight)
                        ser.Format.Line.DashStyle = DirectCast(seriesFormatInfo.LineDashStyle, MsoLineDashStyle)
                        num4 = num4 + 1
                    End If
                Next

            End If
            '-----------------------------------------------------
        Next
    End Sub

    Private Sub chkXAutoScale_CheckedChanged(sender As Object, e As System.EventArgs) Handles chkXAutoScale.CheckedChanged
        If chkXAutoScale.Checked = True Then
            chkXlimSameForAll.Checked = False
            txtXlimMax.Text = Nothing
            txtXlimMin.Text = Nothing
            txtXlimMax.Enabled = False
            txtXlimMin.Enabled = False
        Else
            txtXlimMax.Enabled = True
            txtXlimMin.Enabled = True

        End If
    End Sub

    Private Sub chkYAutoScale_CheckedChanged(sender As Object, e As System.EventArgs) Handles chkYAutoScale.CheckedChanged
        If chkYAutoScale.Checked = True Then
            chkYlimSameForAll.Checked = False
            txtYlimMax.Text = Nothing
            txtYlimMin.Text = Nothing
            txtYlimMax.Enabled = False
            txtYlimMin.Enabled = False
        Else
            txtYlimMax.Enabled = True
            txtYlimMin.Enabled = True

        End If
    End Sub

    Private Sub txtGlobalFontSize_Leave(sender As Object, e As System.EventArgs) Handles txtGlobalFontSize.Leave
        'TEST TEXT ENTRY AND MAKE SURE ITS VALID
        If txtGlobalFontSize.Text = String.Empty Then
        Else
            Try
                Dim i As Integer = CType(txtGlobalFontSize.Text, Integer)
            Catch ex As Exception
                MessageBox.Show("Value Must Be an Integer", "Bad Input")
                txtGlobalFontSize.Text = Nothing
            End Try
        End If
    End Sub

    Private Sub txtXlimMax_Leave(sender As Object, e As System.EventArgs) Handles txtXlimMax.Leave
        'TEST TEXT ENTRY AND MAKE SURE ITS VALID
        If txtXlimMax.Text = String.Empty Then
        Else
            Try
                Dim i As Integer = CType(txtXlimMax.Text, Double)
            Catch ex As Exception
                MessageBox.Show("Value Must Be a Number", "Bad Input")
                txtXlimMax.Text = Nothing
            End Try
        End If
    End Sub

    Private Sub txtXlimMin_Leave(sender As Object, e As System.EventArgs) Handles txtXlimMin.Leave
        'TEST TEXT ENTRY AND MAKE SURE ITS VALID
        If txtXlimMin.Text = String.Empty Then
        Else
            Try
                Dim i As Integer = CType(txtXlimMin.Text, Double)
            Catch ex As Exception
                MessageBox.Show("Value Must Be a Number", "Bad Input")
                txtXlimMin.Text = Nothing
            End Try
        End If
    End Sub

    Private Sub txtYlimMax_Leave(sender As Object, e As System.EventArgs) Handles txtYlimMax.Leave
        'TEST TEXT ENTRY AND MAKE SURE ITS VALID
        If txtYlimMax.Text = String.Empty Then
        Else
            Try
                Dim i As Integer = CType(txtYlimMax.Text, Double)
            Catch ex As Exception
                MessageBox.Show("Value Must Be a Number", "Bad Input")
                txtYlimMax.Text = Nothing
            End Try
        End If
    End Sub

    Private Sub txtYlimMin_Leave(sender As Object, e As System.EventArgs) Handles txtYlimMin.Leave
        'TEST TEXT ENTRY AND MAKE SURE ITS VALID
        If txtYlimMin.Text = String.Empty Then
        Else
            Try
                Dim i As Integer = CType(txtYlimMin.Text, Double)
            Catch ex As Exception
                MessageBox.Show("Value Must Be a Number", "Bad Input")
                txtYlimMin.Text = Nothing
            End Try
        End If
    End Sub

    Private Sub txtLegendFontSize_Leave(sender As Object, e As System.EventArgs) Handles txtLegendFontSize.Leave
        'TEST TEXT ENTRY AND MAKE SURE ITS VALID
        If txtLegendFontSize.Text = String.Empty Then
        Else
            Try
                Dim i As Integer = CType(txtLegendFontSize.Text, Integer)
            Catch ex As Exception
                MessageBox.Show("Value Must Be an Integer", "Bad Input")
                txtLegendFontSize.Text = Nothing
            End Try
        End If
    End Sub

    Private Sub txtXAxisFontSize_Leave(sender As Object, e As System.EventArgs) Handles txtXAxisFontSize.Leave
        'TEST TEXT ENTRY AND MAKE SURE ITS VALID
        If txtXAxisFontSize.Text = String.Empty Then
        Else
            Try
                Dim i As Integer = CType(txtXAxisFontSize.Text, Integer)
            Catch ex As Exception
                MessageBox.Show("Value Must Be an Integer", "Bad Input")
                txtXAxisFontSize.Text = Nothing
            End Try
        End If
    End Sub

    Private Sub txtYAxisFontSize_Leave(sender As Object, e As System.EventArgs) Handles txtYAxisFontSize.Leave
        'TEST TEXT ENTRY AND MAKE SURE ITS VALID
        If txtYAxisFontSize.Text = String.Empty Then
        Else
            Try
                Dim i As Integer = CType(txtYAxisFontSize.Text, Integer)
            Catch ex As Exception
                MessageBox.Show("Value Must Be an Integer", "Bad Input")
                txtYAxisFontSize.Text = Nothing
            End Try
        End If
    End Sub

    Private Sub txtXLabelFontSize_Leave(sender As Object, e As System.EventArgs) Handles txtXLabelFontSize.Leave
        'TEST TEXT ENTRY AND MAKE SURE ITS VALID
        If txtXLabelFontSize.Text = String.Empty Then
        Else
            Try
                Dim i As Integer = CType(txtXLabelFontSize.Text, Integer)
            Catch ex As Exception
                MessageBox.Show("Value Must Be an Integer", "Bad Input")
                txtXLabelFontSize.Text = Nothing
            End Try
        End If
    End Sub

    Private Sub txtYLabelFontSize_Leave(sender As Object, e As System.EventArgs) Handles txtYLabelFontSize.Leave
        'TEST TEXT ENTRY AND MAKE SURE ITS VALID
        If txtYLabelFontSize.Text = String.Empty Then
        Else
            Try
                Dim i As Integer = CType(txtYLabelFontSize.Text, Integer)
            Catch ex As Exception
                MessageBox.Show("Value Must Be an Integer", "Bad Input")
                txtYLabelFontSize.Text = Nothing
            End Try
        End If
    End Sub

    Private Sub chkTopLegend_CheckStateChanged(sender As Object, e As System.EventArgs) Handles chkTopLegend.CheckStateChanged
        If chkTopLegend.Checked = True Then
            txtLegendHeight.Enabled = True
            chkRightLegend.Checked = False
            txtLegendWidth.Enabled = False
        Else
            txtLegendHeight.Enabled = False
        End If

    End Sub

    Private Sub chkRightLegend_CheckStateChanged(sender As Object, e As System.EventArgs) Handles chkRightLegend.CheckStateChanged
        If chkRightLegend.Checked = True Then
            txtLegendWidth.Enabled = True
            chkTopLegend.Checked = False
            txtLegendHeight.Enabled = False
        Else
            txtLegendWidth.Enabled = False
        End If
    End Sub

    Private Sub chkYGridNone_CheckStateChanged(sender As Object, e As System.EventArgs) Handles chkYGridNone.CheckStateChanged
        If chkYGridNone.Checked Then
            chkYGridMajor.Checked = False
            chkYGridMinor.Checked = False
        End If
    End Sub

    Private Sub chkXGridNone_CheckStateChanged(sender As Object, e As System.EventArgs) Handles chkXGridNone.CheckStateChanged
        If chkXGridNone.Checked Then
            chkXGridMajor.Checked = False
            chkXGridMinor.Checked = False
        End If
    End Sub

    'SJS 05-01-15 ADDED BACK FROM DECOMPILED CODE.  moded significantly to make readable
    Private Sub btnFormatSeries_Click(sender As Object, e As EventArgs) Handles btnFormatSeries.Click

        '-------------------------
        'Find the chart in the selected charts that has the most number of series
        Dim num As Integer = 0
        For Each indx As Integer In Me.lstFiles.SelectedIndices
            Dim item As ChartProps = DirectCast(Me.ChartList(indx), ChartProps)
            Dim TEST = Me.ThisWorkbook.Charts

            Dim charts As Excel.Chart = DirectCast(Me.ThisWorkbook.Charts.Item(item.index), Excel.Chart)

            Dim num1 As Integer = 0

            For Each ser As Excel.Series In charts.SeriesCollection
                If (String.Compare(ser.Name, "Limit", False) <> 0) Then
                    num1 = num1 + 1
                End If
            Next

            If (num1 > num) Then
                num = num1
            End If

        Next
        '-----------------------------------

        'Create a series formater with the maximum number of series
        Me.SeriesFormatter.PopulateControlSeriesOnly(num)


        'Dim seriesFormatter As Form = Me.SeriesFormatter
        UsefulFunctions.PositionFormOverParent(Me.SeriesFormatter, 40, 40)
        'Me.SeriesFormatter = DirectCast(Me.SeriesFormatter, SeriesEditor)
        Me.SeriesFormatter.TopMost = True
        If (Me.SeriesFormatter.ShowDialog() = DialogResult.OK) Then
            Me.ModifySeriesFormats = True
        End If
        Me.SeriesFormatter.TopMost = False
    End Sub

    Private Sub btnApply_Click(sender As Object, e As EventArgs) Handles btnApply.Click
        UpdateCharts()
    End Sub
End Class

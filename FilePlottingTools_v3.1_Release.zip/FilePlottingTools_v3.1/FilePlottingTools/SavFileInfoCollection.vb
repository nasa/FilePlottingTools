﻿Public Class SavFileInfoCollection
    Inherits Collections.CollectionBase

    Public Sub Add(ByVal savInfo As SavFileInfo)
        Me.List.Add(savInfo)
    End Sub

    Public Sub Remove(ByVal savInfo As SavFileInfo)
        Me.List.Remove(savInfo)
    End Sub

    Public Property Item(ByVal index As Integer) As SavFileInfo
        Get
            Return CType(Me.List.Item(index), SavFileInfo)
        End Get
        Set(ByVal value As SavFileInfo)
            Me.List.Item(index) = value
        End Set
    End Property
End Class

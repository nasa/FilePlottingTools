﻿Public Class PlotLimitInfoCollection
    Inherits Collections.CollectionBase

    Public Sub Add(ByVal limitinfo As PlotLimitInfo)
        Me.List.Add(limitinfo)
    End Sub

    Public Sub Remove(ByVal limitinfo As PlotLimitInfo)
        Me.List.Remove(limitinfo)
    End Sub

    Public Property Item(ByVal index As Integer) As PlotLimitInfo
        Get
            Return CType(Me.List.Item(index), PlotLimitInfo)
        End Get
        Set(ByVal value As PlotLimitInfo)
            Me.List.Item(index) = value
        End Set
    End Property
End Class

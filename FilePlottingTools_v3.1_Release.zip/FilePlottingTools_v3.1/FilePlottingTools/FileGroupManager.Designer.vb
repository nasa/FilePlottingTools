﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FileGroupManager
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.lstFiles = New System.Windows.Forms.ListView()
        Me.NameCol = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.grpDelimiters = New System.Windows.Forms.GroupBox()
        Me.txtOther = New System.Windows.Forms.TextBox()
        Me.rdbOther = New System.Windows.Forms.RadioButton()
        Me.rdbComma = New System.Windows.Forms.RadioButton()
        Me.rdbTab = New System.Windows.Forms.RadioButton()
        Me.rdbSpace = New System.Windows.Forms.RadioButton()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.btnOk = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.radCompare = New System.Windows.Forms.RadioButton()
        Me.radStitch = New System.Windows.Forms.RadioButton()
        Me.grpStitchOptions = New System.Windows.Forms.GroupBox()
        Me.radAllFilesStartTime0 = New System.Windows.Forms.RadioButton()
        Me.radFileTimesInOrder = New System.Windows.Forms.RadioButton()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.grpDelimiters.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.SplitContainer3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        Me.grpStitchOptions.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel2
        Me.SplitContainer1.IsSplitterFixed = True
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.SplitContainer2)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.AllowDrop = True
        Me.SplitContainer1.Panel2.Controls.Add(Me.TableLayoutPanel1)
        Me.SplitContainer1.Size = New System.Drawing.Size(630, 522)
        Me.SplitContainer1.SplitterDistance = 297
        Me.SplitContainer1.TabIndex = 0
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel2
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.lstFiles)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.RichTextBox1)
        Me.SplitContainer2.Size = New System.Drawing.Size(630, 297)
        Me.SplitContainer2.SplitterDistance = 208
        Me.SplitContainer2.TabIndex = 1
        '
        'lstFiles
        '
        Me.lstFiles.Alignment = System.Windows.Forms.ListViewAlignment.[Default]
        Me.lstFiles.AllowDrop = True
        Me.lstFiles.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.NameCol})
        Me.lstFiles.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lstFiles.HideSelection = False
        Me.lstFiles.Location = New System.Drawing.Point(0, 0)
        Me.lstFiles.Name = "lstFiles"
        Me.lstFiles.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lstFiles.Size = New System.Drawing.Size(630, 208)
        Me.lstFiles.TabIndex = 0
        Me.lstFiles.UseCompatibleStateImageBehavior = False
        Me.lstFiles.View = System.Windows.Forms.View.Details
        '
        'NameCol
        '
        Me.NameCol.Text = "FileName"
        Me.NameCol.Width = 354
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RichTextBox1.Enabled = False
        Me.RichTextBox1.Location = New System.Drawing.Point(0, 0)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(630, 85)
        Me.RichTextBox1.TabIndex = 0
        Me.RichTextBox1.Text = "Drag and drop files or folder onto the window above." & Global.Microsoft.VisualBasic.ChrW(10) & "Dropped folders will ask for" &
    " a file type." & Global.Microsoft.VisualBasic.ChrW(10) & "Use + or - to change item order in list" & Global.Microsoft.VisualBasic.ChrW(10) & "Use DEL to remove items"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.grpDelimiters, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel2, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.GroupBox1, 0, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 64.74359!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 35.25641!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(630, 221)
        Me.TableLayoutPanel1.TabIndex = 11
        '
        'grpDelimiters
        '
        Me.grpDelimiters.Controls.Add(Me.txtOther)
        Me.grpDelimiters.Controls.Add(Me.rdbOther)
        Me.grpDelimiters.Controls.Add(Me.rdbComma)
        Me.grpDelimiters.Controls.Add(Me.rdbTab)
        Me.grpDelimiters.Controls.Add(Me.rdbSpace)
        Me.grpDelimiters.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grpDelimiters.Location = New System.Drawing.Point(3, 120)
        Me.grpDelimiters.Name = "grpDelimiters"
        Me.grpDelimiters.Size = New System.Drawing.Size(624, 58)
        Me.grpDelimiters.TabIndex = 10
        Me.grpDelimiters.TabStop = False
        Me.grpDelimiters.Text = "Select Delimiter"
        '
        'txtOther
        '
        Me.txtOther.Location = New System.Drawing.Point(281, 19)
        Me.txtOther.Name = "txtOther"
        Me.txtOther.Size = New System.Drawing.Size(46, 20)
        Me.txtOther.TabIndex = 11
        '
        'rdbOther
        '
        Me.rdbOther.AutoSize = True
        Me.rdbOther.Location = New System.Drawing.Point(224, 19)
        Me.rdbOther.Name = "rdbOther"
        Me.rdbOther.Size = New System.Drawing.Size(51, 17)
        Me.rdbOther.TabIndex = 10
        Me.rdbOther.Text = "Other"
        Me.rdbOther.UseVisualStyleBackColor = True
        '
        'rdbComma
        '
        Me.rdbComma.AutoSize = True
        Me.rdbComma.Location = New System.Drawing.Point(145, 19)
        Me.rdbComma.Name = "rdbComma"
        Me.rdbComma.Size = New System.Drawing.Size(60, 17)
        Me.rdbComma.TabIndex = 9
        Me.rdbComma.Text = "Comma"
        Me.rdbComma.UseVisualStyleBackColor = True
        '
        'rdbTab
        '
        Me.rdbTab.AutoSize = True
        Me.rdbTab.Checked = True
        Me.rdbTab.Location = New System.Drawing.Point(6, 19)
        Me.rdbTab.Name = "rdbTab"
        Me.rdbTab.Size = New System.Drawing.Size(44, 17)
        Me.rdbTab.TabIndex = 7
        Me.rdbTab.TabStop = True
        Me.rdbTab.Text = "Tab"
        Me.rdbTab.UseVisualStyleBackColor = True
        '
        'rdbSpace
        '
        Me.rdbSpace.AutoSize = True
        Me.rdbSpace.Location = New System.Drawing.Point(70, 19)
        Me.rdbSpace.Name = "rdbSpace"
        Me.rdbSpace.Size = New System.Drawing.Size(56, 17)
        Me.rdbSpace.TabIndex = 8
        Me.rdbSpace.Text = "Space"
        Me.rdbSpace.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 3
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.btnOk, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.btnCancel, 2, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(3, 184)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(624, 34)
        Me.TableLayoutPanel2.TabIndex = 11
        '
        'btnOk
        '
        Me.btnOk.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnOk.AutoSize = True
        Me.btnOk.Location = New System.Drawing.Point(451, 3)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.Size = New System.Drawing.Size(75, 27)
        Me.btnOk.TabIndex = 5
        Me.btnOk.Text = "Ok"
        Me.btnOk.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnCancel.AutoSize = True
        Me.btnCancel.Location = New System.Drawing.Point(541, 3)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 27)
        Me.btnCancel.TabIndex = 6
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.SplitContainer3)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox1.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(624, 111)
        Me.GroupBox1.TabIndex = 9
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Type Of Plot"
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.Location = New System.Drawing.Point(3, 16)
        Me.SplitContainer3.Margin = New System.Windows.Forms.Padding(2)
        Me.SplitContainer3.Name = "SplitContainer3"
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.radCompare)
        Me.SplitContainer3.Panel1.Controls.Add(Me.radStitch)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.Controls.Add(Me.grpStitchOptions)
        Me.SplitContainer3.Size = New System.Drawing.Size(618, 92)
        Me.SplitContainer3.SplitterDistance = 261
        Me.SplitContainer3.SplitterWidth = 3
        Me.SplitContainer3.TabIndex = 5
        '
        'radCompare
        '
        Me.radCompare.AutoSize = True
        Me.radCompare.Checked = True
        Me.radCompare.Location = New System.Drawing.Point(3, 25)
        Me.radCompare.Name = "radCompare"
        Me.radCompare.Size = New System.Drawing.Size(91, 17)
        Me.radCompare.TabIndex = 3
        Me.radCompare.TabStop = True
        Me.radCompare.Text = "Compare Files"
        Me.radCompare.UseVisualStyleBackColor = True
        '
        'radStitch
        '
        Me.radStitch.AutoSize = True
        Me.radStitch.Location = New System.Drawing.Point(98, 25)
        Me.radStitch.Name = "radStitch"
        Me.radStitch.Size = New System.Drawing.Size(76, 17)
        Me.radStitch.TabIndex = 4
        Me.radStitch.Text = "Stitch Files"
        Me.radStitch.UseVisualStyleBackColor = True
        '
        'grpStitchOptions
        '
        Me.grpStitchOptions.Controls.Add(Me.radAllFilesStartTime0)
        Me.grpStitchOptions.Controls.Add(Me.radFileTimesInOrder)
        Me.grpStitchOptions.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grpStitchOptions.Enabled = False
        Me.grpStitchOptions.Location = New System.Drawing.Point(0, 0)
        Me.grpStitchOptions.Margin = New System.Windows.Forms.Padding(2)
        Me.grpStitchOptions.Name = "grpStitchOptions"
        Me.grpStitchOptions.Padding = New System.Windows.Forms.Padding(2)
        Me.grpStitchOptions.Size = New System.Drawing.Size(354, 92)
        Me.grpStitchOptions.TabIndex = 0
        Me.grpStitchOptions.TabStop = False
        Me.grpStitchOptions.Text = "Stitch Options"
        '
        'radAllFilesStartTime0
        '
        Me.radAllFilesStartTime0.AutoSize = True
        Me.radAllFilesStartTime0.Location = New System.Drawing.Point(8, 39)
        Me.radAllFilesStartTime0.Margin = New System.Windows.Forms.Padding(2)
        Me.radAllFilesStartTime0.Name = "radAllFilesStartTime0"
        Me.radAllFilesStartTime0.Size = New System.Drawing.Size(123, 17)
        Me.radAllFilesStartTime0.TabIndex = 1
        Me.radAllFilesStartTime0.TabStop = True
        Me.radAllFilesStartTime0.Text = "All files start at time 0"
        Me.radAllFilesStartTime0.UseVisualStyleBackColor = True
        '
        'radFileTimesInOrder
        '
        Me.radFileTimesInOrder.AutoSize = True
        Me.radFileTimesInOrder.Checked = True
        Me.radFileTimesInOrder.Location = New System.Drawing.Point(8, 17)
        Me.radFileTimesInOrder.Margin = New System.Windows.Forms.Padding(2)
        Me.radFileTimesInOrder.Name = "radFileTimesInOrder"
        Me.radFileTimesInOrder.Size = New System.Drawing.Size(161, 17)
        Me.radFileTimesInOrder.TabIndex = 0
        Me.radFileTimesInOrder.TabStop = True
        Me.radFileTimesInOrder.Text = "File times are already in order"
        Me.radFileTimesInOrder.UseVisualStyleBackColor = True
        '
        'FileGroupManager
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(630, 522)
        Me.Controls.Add(Me.SplitContainer1)
        Me.MinimumSize = New System.Drawing.Size(377, 489)
        Me.Name = "FileGroupManager"
        Me.Text = "FileGroupManager"
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.grpDelimiters.ResumeLayout(False)
        Me.grpDelimiters.PerformLayout()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel1.PerformLayout()
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer3.ResumeLayout(False)
        Me.grpStitchOptions.ResumeLayout(False)
        Me.grpStitchOptions.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOk As System.Windows.Forms.Button
    Friend WithEvents radStitch As System.Windows.Forms.RadioButton
    Friend WithEvents radCompare As System.Windows.Forms.RadioButton
    Public WithEvents lstFiles As System.Windows.Forms.ListView
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rdbSpace As System.Windows.Forms.RadioButton
    Friend WithEvents rdbTab As System.Windows.Forms.RadioButton
    Friend WithEvents grpDelimiters As System.Windows.Forms.GroupBox
    Friend WithEvents rdbOther As System.Windows.Forms.RadioButton
    Friend WithEvents rdbComma As System.Windows.Forms.RadioButton
    Friend WithEvents txtOther As System.Windows.Forms.TextBox
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents NameCol As System.Windows.Forms.ColumnHeader
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents SplitContainer3 As System.Windows.Forms.SplitContainer
    Friend WithEvents grpStitchOptions As System.Windows.Forms.GroupBox
    Friend WithEvents radAllFilesStartTime0 As System.Windows.Forms.RadioButton
    Friend WithEvents radFileTimesInOrder As System.Windows.Forms.RadioButton
End Class

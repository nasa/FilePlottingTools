﻿Imports Microsoft.Office.Tools.Ribbon
Imports System.Windows.Forms
Imports System.Drawing
Imports System.Diagnostics
Imports System.IO
Imports System.Collections

Public Class FilePlottingRibon
    Private DataSheetName As String = "DataStorage"
    Private ImportSheetName As String = "ImportSheet"



    Private Sub FilePlottingRibon_Load(ByVal sender As System.Object, ByVal e As RibbonUIEventArgs) Handles MyBase.Load
        'uncomment this when you are doing debugging, and need to automatically load files or run subroutines.  Debug sub is at the bottom of this page
        'DEBUGMODE()
        'DEBUGMODE2()
        'DEBUGMODE3()
        'DEBUGMODE4()
        'DEBUGMODE5()
        'DEBUGMODE6()
    End Sub

    Private Sub btnFileManager_Click(sender As System.Object, e As Microsoft.Office.Tools.Ribbon.RibbonControlEventArgs) Handles btnFileManager.Click

        Dim CurrentWorkbook As Excel.Workbook = Globals.ThisAddIn.Application.ActiveWorkbook
        Dim CurrentSheet As Object = CurrentWorkbook.ActiveSheet
        Try
            If CompatibilityModeIsOff(CurrentWorkbook) And Me.TrustVbaAccessIsOn() Then
                Dim ThisWorkbookManager As New WorkBookManager(CurrentWorkbook, DataSheetName, ImportSheetName)
                ThisWorkbookManager.ImportFiles()
            End If
            CurrentSheet.Activate()

        Catch ex As Exception
            MessageBox.Show(ex.ToString, "Exception Thrown")
            CurrentSheet.Activate()
        End Try

    End Sub

    Private Sub btnRefresh_Click(sender As System.Object, e As Microsoft.Office.Tools.Ribbon.RibbonControlEventArgs) Handles btnRefresh.Click

        Dim CurrentWorkbook As Excel.Workbook = Globals.ThisAddIn.Application.ActiveWorkbook
        Dim CurrentSheet As Object = CurrentWorkbook.ActiveSheet

        Try
            If CompatibilityModeIsOff(CurrentWorkbook) And Me.TrustVbaAccessIsOn() Then
                Dim ThisWorkbookManager As New WorkBookManager(CurrentWorkbook, DataSheetName, ImportSheetName)
                ThisWorkbookManager.UpdateDataForGroup(True)
            End If
            CurrentSheet.Activate()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception Thrown")
            CurrentSheet.Activate()
        End Try


    End Sub

    Private Sub btnNewPlot_Click(sender As System.Object, e As Microsoft.Office.Tools.Ribbon.RibbonControlEventArgs) Handles btnNewPlot.Click
        Try
            Dim CurrentWorkbook As Excel.Workbook = Globals.ThisAddIn.Application.ActiveWorkbook
            If CompatibilityModeIsOff(CurrentWorkbook) And Me.TrustVbaAccessIsOn() Then
                Dim ThisWorkbookManager As New WorkBookManager(CurrentWorkbook, DataSheetName, ImportSheetName)
                ThisWorkbookManager.NewPlot()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception Thrown")
        End Try


    End Sub

    Private Sub btnPlotManager_Click(sender As System.Object, e As Microsoft.Office.Tools.Ribbon.RibbonControlEventArgs) Handles btnPlotManager.Click
        Try
            'SJS 05-08-15 REMOVED WORKBOOK MANAGER FROM PLOT MANAGER
            'ALLOWS USE OF PLOT MANAGER IN ANY WORKBOOK WITHOUT NEEDING FORMATTED
            'OR IMPORT SHEETS

            Dim CurrentWorkbook As Excel.Workbook = Globals.ThisAddIn.Application.ActiveWorkbook
            If CompatibilityModeIsOff(CurrentWorkbook) And Me.TrustVbaAccessIsOn() Then
                If Globals.ThisAddIn.Application.ActiveWorkbook.Charts.Count = 0 Then
                    MessageBox.Show("There are no Chart Sheets in the Workbook to Format")
                Else
                    PlottingFunctions.FormatPlots()
                End If
            End If


        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception Thrown")
        End Try

    End Sub

    Private Sub btnCompareMaxMin_Click(sender As System.Object, e As Microsoft.Office.Tools.Ribbon.RibbonControlEventArgs) Handles btnCompareMaxMin.Click
        Try
            Dim CurrentWorkbook As Excel.Workbook = Globals.ThisAddIn.Application.ActiveWorkbook
            If CompatibilityModeIsOff(CurrentWorkbook) And Me.TrustVbaAccessIsOn() Then
                Dim ThisWorkbookManager As New WorkBookManager(CurrentWorkbook, DataSheetName, ImportSheetName)
                ThisWorkbookManager.CompareFiles()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception Thrown")
        End Try

    End Sub

    Private Sub btnRefreshImportOnly_Click(sender As System.Object, e As Microsoft.Office.Tools.Ribbon.RibbonControlEventArgs) Handles btnRefreshImportOnly.Click

        Dim CurrentWorkbook As Excel.Workbook = Globals.ThisAddIn.Application.ActiveWorkbook
        Dim CurrentSheet As Object = CurrentWorkbook.ActiveSheet
        Try
            If CompatibilityModeIsOff(CurrentWorkbook) And Me.TrustVbaAccessIsOn() Then
                If MessageBox.Show("This will re-import the text files only, it will not update the formatted sheet. If you are using a worksheet that is created with a previous version of FilePlottingTools this will act like Refresh All on the first click. If you have added new columns to your files, or the number of time points have changed, use the refresh all button", "Caution", MessageBoxButtons.OKCancel) = DialogResult.OK Then
                    Dim ThisWorkbookManager As New WorkBookManager(CurrentWorkbook, DataSheetName, ImportSheetName)
                    ThisWorkbookManager.UpdateDataForGroup(True, True, False)
                End If
            End If
            CurrentSheet.Activate()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception Thrown")
            CurrentSheet.Activate()
        End Try

    End Sub

    Private Sub btnAbout_Click(sender As System.Object, e As Microsoft.Office.Tools.Ribbon.RibbonControlEventArgs) Handles btnAbout.Click
        Dim NewAbout As New AboutForm
        NewAbout.StartPosition = FormStartPosition.Manual
        Dim LocPoint As Point = PointsToPixelsAsPoint(Globals.ThisAddIn.Application.Left, Globals.ThisAddIn.Application.Top)
        LocPoint.Offset(40, 40)

        NewAbout.Location = LocPoint
        If NewAbout.ShowDialog = DialogResult.OK Then

        End If
    End Sub

    Private Sub btnHelp_Click(sender As System.Object, e As Microsoft.Office.Tools.Ribbon.RibbonControlEventArgs) Handles btnHelp.Click
        Dim HelpFile As String = My.Computer.FileSystem.SpecialDirectories.MyDocuments + "\FilePlottingToolsManual v3.1"
        UsefulFunctions.SaveFileFromResource(HelpFile, My.Resources.FilePlottingToolsManual_v3_1)
        Process.Start(HelpFile)
    End Sub

    Private Sub btnAddSeries_Click(sender As System.Object, e As Microsoft.Office.Tools.Ribbon.RibbonControlEventArgs) Handles btnAddSeries.Click
        Try
            Dim CurrentWorkbook As Excel.Workbook = Globals.ThisAddIn.Application.ActiveWorkbook
            Dim CurrentChart As Excel.Chart = CurrentWorkbook.ActiveChart

            If CurrentChart Is Nothing Then
                MessageBox.Show("A Chart Must Be Selected.")
            Else
                If CompatibilityModeIsOff(CurrentWorkbook) And Me.TrustVbaAccessIsOn() Then
                    Dim ThisWorkbookManager As New WorkBookManager(CurrentWorkbook, DataSheetName, ImportSheetName)

                    Dim shtDatasheet As Excel.Worksheet = UsefulFunctions.GetWorkSheetByName(DataSheetName, CurrentWorkbook)
                    ThisWorkbookManager.AddSeriesToPlot(CurrentChart)
                End If
            End If


        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception Thrown")
        End Try
    End Sub

    Private Sub btnSeriesFormat_Click(sender As System.Object, e As Microsoft.Office.Tools.Ribbon.RibbonControlEventArgs) Handles btnSeriesFormat.Click
        Try
            Dim CurrentWorkbook As Excel.Workbook = Globals.ThisAddIn.Application.ActiveWorkbook
            Dim CurrentChart As Excel.Chart = CurrentWorkbook.ActiveChart

            If CurrentChart Is Nothing Then
                MessageBox.Show("A Chart Must Be Selected.")
            Else
                If CompatibilityModeIsOff(CurrentWorkbook) And Me.TrustVbaAccessIsOn() Then
                    Dim ThisWorkbookManager As New WorkBookManager(CurrentWorkbook, DataSheetName, ImportSheetName)

                    Dim shtDatasheet As Excel.Worksheet = UsefulFunctions.GetWorkSheetByName(DataSheetName, CurrentWorkbook)
                    ThisWorkbookManager.ModifyChartSeries(CurrentChart)
                End If
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception Thrown")
        End Try

        

    End Sub

    Private Sub btnTEST_Click(sender As System.Object, e As Microsoft.Office.Tools.Ribbon.RibbonControlEventArgs) Handles btnTEST.Click
        Try
            Dim CurrentWorkbook As Excel.Workbook = Globals.ThisAddIn.Application.ActiveWorkbook
            'Dim CurrentChart As Excel.Chart = CurrentWorkbook.ActiveChart

            'If CurrentChart Is Nothing Then
            'MessageBox.Show("A Chart Must Be Selected.")
            ' Else
            If CompatibilityModeIsOff(CurrentWorkbook) And Me.TrustVbaAccessIsOn() Then
                Dim ThisWorkbookManager As New WorkBookManager(CurrentWorkbook, DataSheetName, ImportSheetName)
                ThisWorkbookManager.shtDataSheet.Visible = Excel.XlSheetVisibility.xlSheetVisible
                'Dim shtDatasheet As Excel.Worksheet = UsefulFunctions.GetWorkSheetByName(DataSheetName, CurrentWorkbook)
                '        Dim PlotFileType As String = shtDatasheet.Cells(11, 2).value.ToString

                '        Dim Color1 As Color

                '        Color1 = ColorTranslator.FromOle(CurrentChart.SeriesCollection(1).Border.Color)
                '        Color1 = Color.FromArgb(CurrentChart.SeriesCollection(1).Border.Color)
                '        CurrentChart.SeriesCollection(1).Border.Color = RGB(192, 80, 77)
                '        Color1 = Color.FromArgb(192, 80, 77)

                Dim VBProj = CurrentWorkbook.VBProject
                    Dim FirstLine As Integer = 1
                    Dim LastLine As Integer = 0
                    Dim FirstColumn As Integer = 1
                    Dim LastColumn As Integer = -1

                Dim ProcedureName As String = "Tconvert33"
                For Each VBcomp In VBProj.VBComponents
                        Dim CodeMod = VBcomp.CodeModule
                        LastLine = CodeMod.CountOfLines
                        Dim bFind As Boolean = CodeMod.Find(Target:=ProcedureName, StartLine:=FirstLine, EndLine:=LastLine, StartColumn:=FirstColumn, EndColumn:=FirstColumn, WholeWord:=True)
                        If bFind Then
                            MessageBox.Show("The macro " + ProcedureName + " does exist in the: " + VBcomp.Name.ToString)
                            Exit For
                        End If

                    Next
                End If
            ' End If

            'PlottingFunctions.CreateTemplateChart("TEST", CurrentWorkbook, "Formatted Data")

            'Dim DataSheetManager As New DataSheetClass(CType(CurrentWorkbook.Sheets(1), Excel.Worksheet))
            'Dim DataSheetManager As New DataSheetClass("testSheet")

            'MessageBox.Show(DataSheetManager.CellNumberOfFiles.Value)
            'DataSheetManager.CellNumberOfFiles.Value = 19
            'DataSheetManager.CellNumberOfFiles.Offset(, 1).Value = 23

            'DataSheetManager.CellTEST.Value = 12
            'DataSheetManager.CellTEST(1, 1).Value = 13
            'DataSheetManager.CreateADataSheetInWorkbook("test")
            'Dim ThisWorkbookManager As New WorkBookManager(CurrentWorkbook, DataSheetName, ImportSheetName, 20)





        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception Thrown")
        End Try
    End Sub

    Private Sub btnSetSavLib_Click(sender As Object, e As RibbonControlEventArgs) Handles btnSetSavLib.Click
        Dim SaveFilePath As String = ""
        UsefulFunctions.GetSAVLibraryPathFromKey(SaveFilePath)
        UsefulFunctions.SetSavFilePath(SaveFilePath)
    End Sub

    Private Sub btnEnvHeatingImport_Click(sender As Object, e As RibbonControlEventArgs) Handles btnEnvHeatingImport.Click
        Dim CurrentWorkbook As Excel.Workbook = Globals.ThisAddIn.Application.ActiveWorkbook
        Dim CurrentSheet As Object = CurrentWorkbook.ActiveSheet
        Try

            If CompatibilityModeIsOff(CurrentWorkbook) And Me.TrustVbaAccessIsOn() Then
                Dim ThisWorkbookManager As New WorkBookManager(CurrentWorkbook, DataSheetName, ImportSheetName)
                ThisWorkbookManager.ImportHeatingFiles()
            End If
            CurrentSheet.Activate()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception Thrown")
            CurrentSheet.Activate()
        End Try

    End Sub

    Private Function CompatibilityModeIsOff(ByRef ThisWorkBook As Excel.Workbook)
        If ThisWorkBook.Excel8CompatibilityMode Then
            MessageBox.Show(My.Resources.CompatibilityWarning.ToString)
            Return False
        Else
            Return True
        End If
    End Function
    Private Function TrustVbaAccessIsOn() As Boolean
        'CHECK WHETHER TRUST VBA ACCES IS ENABLED

        Dim VersionString = Globals.ThisAddIn.Application.Application.Version
        Dim RegString As String = "Software\Microsoft\Office\" + VersionString + "\Excel\Security"

        Dim UserRegValue As Object = UsefulFunctions.GetUserRegKeyValue(RegString, "AccessVBOM")
        Dim LocalRegValue As Object = UsefulFunctions.GetLocalRegKeyValue(RegString, "AccessVBOM")

        If UserRegValue Is Nothing Then
        Else
            If UserRegValue = 1 And (LocalRegValue = 1 Or LocalRegValue Is Nothing) Then
                Return True
            Else
                MessageBox.Show("Trust Access To the VBA project model must be enabled to use the plotting add-In.  This can be enabled In Excel Options, Trust Center, Macro Security. You must restart Excel the change to take effect.", "Enable Access to VBA Project Model")
                Return False
            End If
        End If

        Return True
    End Function
    Private Sub DEBUGMODE()
        Dim ListOfFiles As New ArrayList

        ListOfFiles.Add("D:\my_docs\00_Programming\FilePlottingTools\RegisterBug\B13C_BOL_OMspin.sav")
        'ListOfFiles.Add("D:\my_docs\00_Programming\FilePlottingTools\FilePlottingTools_v2.1\TextFiles\TD57SavFile\ChamberRun_2C_perMin.sav")
        'ListOfFiles.Add("D:\my_docs\00_Programming\FilePlottingTools\FilePlottingTools_v2.1\TextFiles\TD57SavFile\ChamberRun_2C_perMin.sav")
        'ListOfFiles.Add("D:\my_docs\00_Programming\FilePlottingTools\FilePlottingTools_v2.0\TextFiles\Dragon_FacilityOnly_ATT_01.us1")
        'ListOfFiles.Add("D:\my_docs\00_Programming\FilePlottingTools\FilePlottingTools_v2.1\TextFiles\OneNodeOnly.us1")
        'ListOfFiles.Add("D:\my_docs\00_Programming\FilePlottingTools\FilePlottingTools_v2.1\TextFiles\OneNodeOnly.us1")
        'ListOfFiles.Add("D:\my_docs\00_Programming\FilePlottingTools\FilePlottingTools_v2.1\TextFiles\OneNodeOnly.us1")
        'ListOfFiles.Add("D:\my_docs\00_Programming\FilePlottingTools\FilePlottingTools_v2.1\TextFiles\Dragon_FacilityOnly_ATT_01.us1")
        'ListOfFiles.Add("D:\my_docs\00_Programming\FilePlottingTools\FilePlottingTools_v2.1\TextFiles\Dragon_FacilityOnly_ATT_01.us1")
        'ListOfFiles.Add("D:\my_docs\00_Programming\FilePlottingTools\FilePlottingTools_v2.1\TextFiles\Dragon_FacilityOnly_ATT_01.us1")
        'ListOfFiles.Add("D:\my_docs\00_Programming\FilePlottingTools\BIGFILE.us1")
        'ListOfFiles.Add("D:\my_docs\00_Programming\FilePlottingTools\BIGFILE.us1")
        'ListOfFiles.Add("D:\my_docs\00_Programming\FilePlottingTools\BIGFILE.us1")

        'ListOfFiles.Add("D:\my_docs\00_Programming\FilePlottingTools\PPT_on_stringer.sav")
        'ListOfFiles.Add("D:\my_docs\00_Programming\FilePlottingTools\PPT_On_Stringer_Nominal.sav")
        Try
            Dim CurrentWorkbook As Excel.Workbook = Globals.ThisAddIn.Application.ActiveWorkbook

            If CompatibilityModeIsOff(CurrentWorkbook) And Me.TrustVbaAccessIsOn() Then
                Dim ThisWorkbookManager As New WorkBookManager(CurrentWorkbook, DataSheetName, ImportSheetName)
                ThisWorkbookManager.CreateDebugCase(ListOfFiles, "C")

                For i As Integer = 1 To 4
                    ThisWorkbookManager.shtImport.Cells(8, i + 1).Value = "TEST" + i.ToString
                    ThisWorkbookManager.shtImport.Cells(10, i + 1).Value = 100
                    ThisWorkbookManager.shtImport.Cells(11, i + 1).Value = 70
                    ThisWorkbookManager.shtImport.Cells(12, i + 1).Value = 0
                    ThisWorkbookManager.shtImport.Cells(13, i + 1).Value = -20

                Next

                ThisWorkbookManager.shtDataSheet.Visible = Excel.XlSheetVisibility.xlSheetVisible

                'use this to automatically generate a plot
                'NumSeries is the number of series you want to make, don't exceed number of columns in file
                Dim NumSeries As Integer = 1
                'ThisWorkbookManager.DebugNewPlot(NumSeries)

            End If



            'Dim TestForm As New SeriesEditor

            'TestForm.Show()

            'put any test scripts here:
            'Try
            '    'Dim CurrentWorkbook As Excel.Workbook = Globals.ThisAddIn.Application.ActiveWorkbook
            '    If CompatibilityModeIsOff(CurrentWorkbook) And Me.TrustVbaAccessIsOn() Then
            '        Dim ThisWorkbookManager As New WorkBookManager(CurrentWorkbook, DataSheetName, ImportSheetName, 20)
            '        ThisWorkbookManager.CompareFiles()
            '    End If
            'Catch ex As Exception

            'End Try
            'Dim shtform As Excel.Worksheet = UsefulFunctions.GetWorkSheetByName("Formatted Data", CurrentWorkbook)
            'Dim test As String = shtform.Cells(25, "A").Value()

            'If shtform.Cells(20, "A").Value() Is Nothing Then
            '    Dim junk As String

            'Else

            'End If

            'Dim a As String = "junk"


        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception Thrown")
        End Try
    End Sub

    Private Sub DEBUGMODE2()
        Dim HeatDialog As New ImportHeating()
        HeatDialog.FileName = HeatDialog.txtFileName.Text
        'If HeatDialog.ShowDialog = DialogResult.OK Then
        Dim Heating As New HeatingFileInfo(HeatDialog.FileName)
        Heating.ReadFileIntoClipBoard()

        'End If



    End Sub

    Private Sub DEBUGMODE3()
        Dim theFile As String

        Dim STartDirectory As String = "D:\my_docs\00_Programming\FilePlottingTools\FilePlottingTools_v2.0\TESTSINAPSFIND" ' "C:\Windows\Microsoft.NET" 'Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)
        theFile = UsefulFunctions.FindFileNameWithSizeInFolders(STartDirectory, "SinapsXNet.dll", 1200640)

        MessageBox.Show(theFile)

    End Sub
    Private Sub DEBUGMODE4()
        Try
            UsefulFunctions.DeleteRegSubKeyCurrentUser("Software\\FilePlottingTools")
        Catch ex As Exception

        End Try

    End Sub

    Private Sub DEBUGMODE5()
        Try
            'UsefulFunctions.DeleteRegSubKeyCurrentUser("Software\\FilePlottingTools")
            Dim CurrentWorkbook As Excel.Workbook = Globals.ThisAddIn.Application.ActiveWorkbook

            MessageBox.Show(CurrentWorkbook.Charts.Count.ToString)

            MessageBox.Show("enter chartsheet loop")
            For Each chartsheet As Excel.Chart In CurrentWorkbook.Charts

                If chartsheet.Name = "chtTemplate" Then
                    MessageBox.Show("unhide chartsheet")
                    chartsheet.Visible = Excel.XlSheetVisibility.xlSheetVisible
                    Exit For
                End If
            Next

            MessageBox.Show("Start worksheet loop")
            For Each datasheet As Excel.Worksheet In CurrentWorkbook.Worksheets

                If datasheet.Name = DataSheetName Then
                    MessageBox.Show("unhide chartsheet")
                    datasheet.Visible = Excel.XlSheetVisibility.xlSheetVisible
                End If
            Next

        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try

    End Sub


    Private Sub DEBUGMODE6()
        Dim ListOfFiles As New ArrayList

        Try
            Dim CurrentWorkbook As Excel.Workbook = Globals.ThisAddIn.Application.ActiveWorkbook

            If CompatibilityModeIsOff(CurrentWorkbook) And Me.TrustVbaAccessIsOn() Then
                Dim ThisWorkbookManager As New WorkBookManager(CurrentWorkbook, DataSheetName, ImportSheetName)

                ThisWorkbookManager.shtDataSheet.Visible = Excel.XlSheetVisibility.xlSheetVisible

            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception Thrown")
        End Try
    End Sub
End Class

﻿Imports System.IO
Imports System.Drawing
Imports System.Windows.Forms

Public Class FolderSelector
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()
        Me.AutoScaleMode = Windows.Forms.AutoScaleMode.Dpi
        ' Add any initialization after the InitializeComponent() call.


        For Each Dir As String In Directory.GetDirectories("c:\Program Files")
            Dim NewFolder As New ListViewItem
            lvwFolders.Items.Add(Dir)
        Next

    End Sub


End Class
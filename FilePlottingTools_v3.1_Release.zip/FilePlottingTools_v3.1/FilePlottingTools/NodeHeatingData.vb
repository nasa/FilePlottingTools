﻿Imports System.Collections

Public Class NodeHeatingData
    Private FullName As String
    Public Submodel As String
    Public Number As Integer
    Public NodeArea As Double
    Public TimeArray As New ArrayList
    Public SolarArray As New ArrayList
    Public AlbedoArray As New ArrayList
    Public PlanetArray As New ArrayList


    Public Sub New()
        FullName = ""
        Submodel = ""
    End Sub

    Public Sub New(ByVal FullName As String)
        Me.FullNodeName = FullName
        'Me.Submodel = Me.FullName.Substring(0, Me.FullName.IndexOf("."))
        'Me.Number = Me.FullName.Substring(Me.FullName.IndexOf(".") + 1)
    End Sub

    Public Sub New(ByVal FullName As String, ByVal Area As Double)
        Me.New(FullName)
        Me.NodeArea = NodeArea
    End Sub

    Public Sub New(ByVal FullName As String, ByVal Area As Double, ByVal TimeArrayList As ArrayList, ByVal SolarArrayList As ArrayList, ByVal AlbedoArrayList As ArrayList, ByVal PlanetArrayList As ArrayList)
        Me.New(FullName)
        Me.NodeArea = NodeArea
        Me.TimeArray = TimeArrayList
        Me.SolarArray = SolarArrayList
        Me.AlbedoArray = AlbedoArrayList
        Me.PlanetArray = PlanetArrayList
    End Sub

    Public Property FullNodeName As String
        Get
            Return Me.FullName
        End Get
        Set(value As String)
            Me.FullName = value
            Me.Submodel = value.Substring(0, value.IndexOf("."))
            Me.Number = CType(value.Substring(value.IndexOf(".") + 1), Integer)
        End Set
    End Property
End Class

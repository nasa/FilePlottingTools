﻿'Imports SinapsXNet
Imports System.Collections
Imports System.Windows.Forms
Imports FilePlottingTools
Imports Microsoft.Office.Interop.Excel
Imports System
Imports System.Reflection
Imports System.Runtime.CompilerServices

Public Class SavFileInfo
    Inherits GenericFileInfo

    'SJS ADDED FROM DECOMPILE
    Private CRLib As [Assembly]

    Private Source As String = "PC"         'used to read the savefile
    'Private sindaplot As New SindaPlotting
    Private sindaplot As New Object
    Private SubModelList As New SubmodelCollection
    Private PlotList As SubmodelCollection 'this is the items to be plotted, need to add this from a savfileimport dialog

    'flag is used so that file is property opened and closed when a single sindaplotting funcion is called
    'however the file will stay open if in a routine where multiple sindaplotting functions are called
    'this is implemented in me.OpenSavFile and Me.CloseSavFile
    Private SavFileIsOpen As Boolean = False

    Public Sub New(ByVal FileName As String, ByVal index As Integer, ByRef DataSheet As Excel.Worksheet, ByRef ControlSheet As Excel.Worksheet)
        Me.Namep = FileName
        Me.Indexp = index
        Me.shtDataSheet = DataSheet
        Me.shtImport = ControlSheet

        'Me.SubModelList = New SubmodelCollection
        'Me.PlotList = New SubmodelCollection

        Dim str As String = ""

        'SJS 04-30-2015 ADDED THIS CODE FROM DECOMPILED VERSION
        If (UsefulFunctions.SavFileKeyExists(str) = False) Then
            'Sav file key doesn't exist in registry, create it
            UsefulFunctions.AutoSetSavFilePath(str)
            Me.CreateSinapsAssembly(str)
        ElseIf (Not UsefulFunctions.FileExists(str)) Then
            'if key existed, 'str' will contain file name
            'if file doesn't exist, set new path to sav library
            UsefulFunctions.AutoSetSavFilePath(str)
            Me.CreateSinapsAssembly(str)
        Else
            'both the key and file existed, create the assembly
            Me.CreateSinapsAssembly(str)
        End If

        'MessageBox.Show("SAV Construct, Start Open Sav")
        'OpenSaveFile()
        'MessageBox.Show("SAV Construct, Finish Open Sav, Start Loading Submodels and Nodes")
        'StoreSubmodelInfo()
        'MessageBox.Show("SAV Construct, Finish Loading Submodels and Nodes")
        'CloseSaveFile()
    End Sub

    Public Sub New(ByVal FileName As String, ByVal index As Integer, ByRef DataSheetManager As DataSheetClass, ByRef ControlSheet As Excel.Worksheet)
        Me.Namep = FileName
        Me.Indexp = index

        Me.DataSheetManager = DataSheetManager
        Me.shtDataSheet = Me.DataSheetManager.TheDataSheet
        Me.shtImport = ControlSheet

        Dim str As String = ""

        'SJS 04-30-2015 ADDED THIS CODE FROM DECOMPILED VERSION
        If (UsefulFunctions.SavFileKeyExists(str) = False) Then
            'Sav file key doesn't exist in registry, create it
            UsefulFunctions.AutoSetSavFilePath(str)
            Me.CreateSinapsAssembly(str)
        ElseIf (Not UsefulFunctions.FileExists(str)) Then
            'if key existed, 'str' will contain file name
            'if file doesn't exist, set new path to sav library
            UsefulFunctions.AutoSetSavFilePath(str)
            Me.CreateSinapsAssembly(str)
        Else
            'both the key and file existed, create the assembly
            Me.CreateSinapsAssembly(str)
        End If

    End Sub

    Public Overrides Sub ReadFileIntoClipBoard()
        'SJS 04-30-2015 THINK ITS THE SAME AS DECOMPILED, BUT HARD TO TELL
        'WOULD NEED TO GO THROUGH IN DETAIL
        'MessageBox.Show("start open sav")
        OpenSaveFile()
        'MessageBox.Show("end open sav")

        '09/13/2016 SJS
        'DANGEROUS HARD CODE FIX
        'If you don't keep this value high, it cuts off exponent values.  Needs to be at least 20.
        'set to 25 for safety.  Originally set to 10, and it was cutting of exponents
        'Eliminate this eventually.  Its being used to size the file array, figure out
        'better way to do this
        Dim NumDigits = 25
        '------------
        Dim NumCols = PlotList.CountNumberOfColumnsRequired
        Dim TimeArray As String() = Me.GetTimesAsString
        Dim numTimePoints = TimeArray.Count
        Dim ArraySize = (NumDigits + 1) * (NumCols) * numTimePoints + 1
        Dim FileChars(ArraySize) As Char

        'Dim DataBlockArray(NumCols - 1)() As String
        Dim DataBlockArray(NumCols - 1)() As String

        'DataBlockArray(0) = ConvertDblArrayToStringArray(TimeArray)
        DataBlockArray(0) = TimeArray
        Dim i As Integer = 1

        'MessageBox.Show("start populate datablock")
        For Each subm As SubmodelInfo In PlotList
            If subm.SubModelName = "REGISTERS" Then
                For Each regName As String In subm.GetAllNodes
                    Dim TArray As String() = Me.GetTimeArrayForRegisterAsString(regName)

                    If TArray.Count <> numTimePoints Then
                        ResizeArrayIfNoValuesFound(TArray, numTimePoints)
                    End If

                    DataBlockArray(i) = TArray
                    i += 1

                Next
            Else
                For Each node As String In subm.GetAllNodes
                    Dim TArray As String() = Me.GetTempArrayForNodeAsString(subm.SubModelName, node)

                    If TArray.Count <> numTimePoints Then
                        ResizeArrayIfNoValuesFound(TArray, numTimePoints)
                    End If

                    DataBlockArray(i) = TArray
                    i += 1

                Next
            End If

        Next
        'MessageBox.Show("finish populate datablock")

        'MessageBox.Show("start populate filechars ")
        Dim col As Integer = 0
        For j As Integer = 0 To numTimePoints - 1
            For k As Integer = 0 To NumCols - 1
                AddNextValueToFile(FileChars, DataBlockArray(k)(j), col, NumDigits)
            Next
            'need to back up by 1 character, because the last one gets a vbTab, replace with vbCr if its the entry
            col -= 1
            FileChars(col) = vbCr
            col += 1
        Next
        'MessageBox.Show("finish populate filechars")

        My.Computer.Clipboard.SetText(FileChars)
        Me.NumRowsp = numTimePoints
        Me.NumColsp = NumCols
        CloseSaveFile()
    End Sub

    Private Sub ResizeArrayIfNoValuesFound(ByRef TArray As String(), ByVal ArrayCount As Integer)
        Dim StartIndex = TArray.Count
        Array.Resize(TArray, ArrayCount)
        For i As Integer = StartIndex To ArrayCount - 1
            TArray(i) = "No DATA"
        Next
    End Sub

    Private Sub AddNextValueToFile(ByRef File As Char(), ByVal val As String, ByRef i As Integer, ByVal NumDigits As Integer)
        Dim limit As Integer = 0
        'Dim CurrentTime As String = TimeArray(RowCount).ToString
        While limit < NumDigits
            If limit = val.Count Then
                Exit While
            Else
                File(i) = val(limit)
                i += 1
            End If
            limit += 1
        End While
        File(i) = vbTab
        i += 1
    End Sub

    Private Sub AddNextValueToFile(ByRef File As Char(), ByVal vald As Double, ByRef i As Integer, ByVal NumDigits As Integer)
        Dim limit As Integer = 0
        Dim val As String = vald.ToString
        'Dim CurrentTime As String = TimeArray(RowCount).ToString
        'SJS TODO change this to just call the previous function, don't duplicate code
        While limit < NumDigits
            If limit = val.Count Then
                Exit While
            Else
                File(i) = val(limit)
                i += 1
            End If
            limit += 1
        End While
        File(i) = vbTab
        i += 1
    End Sub

    Public Overrides Sub UpdateDataSheet()
        'update data sheet
        'SJS 04-30-2015 THINK ITS THE SAME AS DECOMPILED, BUT HARD TO TELL
        'WOULD NEED TO GO THROUGH IN DETAIL
        If Index = -1 Then
            MessageBox.Show("ERROR from TEXTFILEINFO.UpdateDataSheet(), index not specified.  Nothing updated.")
        Else
            ClearGroupRow()
            'shtGroupInfo.Cells(10 + Me.Index, 3).Value() = Me.Namep
            'shtGroupInfo.Cells(10 + Me.Index, 4).Value() = Me.RowStart
            'shtGroupInfo.Cells(10 + Me.Index, 5).Value() = Me.RowEndp
            'shtGroupInfo.Cells(10 + Me.Index, 6).Value() = Me.ColStartp
            'shtGroupInfo.Cells(10 + Me.Index, 7).Value() = Me.ColEndp

            Me.DataSheetManager.CellFirstFileName.Offset(Me.Index).Value() = Me.Namep
            Me.DataSheetManager.CellFirstFileRowStart.Offset(Me.Index).Value() = Me.RowStart
            Me.DataSheetManager.CellFirstFileRowEnd.Offset(Me.Index).Value() = Me.RowEndp
            Me.DataSheetManager.CellFirstFileColStart.Offset(Me.Index).Value() = Me.ColStartp
            Me.DataSheetManager.CellFirstFileColEnd.Offset(Me.Index).Value() = Me.ColEndp


            'continue node list
            'Dim col As Integer = 8
            Dim col As Integer = 0


            For Each subm As SubmodelInfo In PlotList
                For Each node As String In subm.GetAllNodes
                    If subm.SubModelName = "REGISTERS" Then
                        'shtGroupInfo.Cells(10 + Me.Index, col).Value() = subm.SubModelName + "." + node
                        Me.DataSheetManager.CellFirstFileSavNodeListStart.Offset(Me.Index, col).Value() = subm.SubModelName + "." + node
                    Else
                        'shtGroupInfo.Cells(10 + Me.Index, col).Value() = subm.SubModelName + ".T" + node
                        Me.DataSheetManager.CellFirstFileSavNodeListStart.Offset(Me.Index, col).Value() = subm.SubModelName + ".T" + node
                    End If

                    col += 1
                Next
            Next


            If Me.Index = 0 Then
                Dim clearRange As Excel.Range
                'clear the control sheet node numbers
                'dangerous hard code, 1000
                clearRange = shtImport.Range(shtImport.Cells(9, 2), shtImport.Cells(9, 1000))
                clearRange.Clear()
                'copy the node numbers and paste into the control sheet
                'Dim CopyRange As Excel.Range = shtGroupInfo.Range(shtGroupInfo.Cells(10, 8), shtGroupInfo.Cells(10, col))
                Dim CopyRange As Excel.Range = shtDataSheet.Range(Me.DataSheetManager.CellFirstFileSavNodeListStart, Me.DataSheetManager.CellFirstFileSavNodeListStart.Offset(, col))
                CopyRange.Copy()

                Dim PasteRange As Excel.Range = shtImport.Cells(9, 2)
                PasteRange.PasteSpecial()
            Else

            End If

        End If

    End Sub

    Private Sub OpenSaveFile()
        If Me.SavFileIsOpen = True Then
            'do nothing, file is already open
        Else
            sindaplot.reOpen(Me.Namep, Me.Source)
            Me.SavFileIsOpen = True
        End If

    End Sub

    Private Sub CloseSaveFile()
        If Me.SavFileIsOpen Then
            sindaplot.closeSaveFile()
            Me.SavFileIsOpen = False
        Else
            'do nothing, file is already closed
        End If

    End Sub

    Public Sub StoreSubmodelInfo()
        'SJS 04-30-2015 THINK ITS THE SAME AS DECOMPILED, BUT HARD TO TELL
        'WOULD NEED TO GO THROUGH IN DETAIL
        'add registers to listing
        Dim RegName As String = "REGISTERS"
        Dim Registers As Specialized.StringCollection = GetRegisterNames
        If Registers Is Nothing Then
        Else
            Dim subm As New SubmodelInfo(RegName, Registers)
            SubModelList.Add(subm)
        End If

        'add submodels to listing
        For i As Integer = 0 To GetSubmodelNames.Count - 1
            Dim SubName As String = GetSubmodelNames(i)
            Dim SubmodelNodes() As Long = GetNodesInSubmodel(SubName)
            If SubmodelNodes Is Nothing Then
            Else
                Dim subm As New SubmodelInfo(SubName, SubmodelNodes)
                SubModelList.Add(subm)
            End If
        Next
    End Sub

    'sjs renamed from GroupInfoRowNumber
    Public ReadOnly Property DataSheetRowNumber() As Integer
        Get
            Return Index + 10
        End Get
    End Property

    Public ReadOnly Property IndexOfFile() As Integer
        Get
            Return Me.Index
        End Get
    End Property

    Public Sub GetPlotListFromDataSheet()
        'SJS 04-30-2015 THINK ITS THE SAME AS DECOMPILED, BUT HARD TO TELL
        'WOULD NEED TO GO THROUGH IN DETAIL
        'Dim col As Integer = 8
        Dim col As Integer = 0
        Dim subCollection As New SubmodelCollection

        'SJS 05-12-15 CLEAN THIS UP, LOOKS VERY STRANGE AND DUPLICATIVE, USE RECURSION

        While True
            'Dim NodeCell As Excel.Range = shtGroupInfo.Cells(10 + Me.Index, col)
            Dim NodeCell As Excel.Range = Me.DataSheetManager.CellFirstFileSavNodeListStart.Offset(Me.Index, col)
            If NodeCell.Value Is Nothing Then
                Exit While
            Else
                Dim node As String = NodeCell.Value.ToString
                Dim IndexOf_Dot As Integer = node.IndexOf(".")
                Dim SubName As String = node.Substring(0, IndexOf_Dot)
                Dim NodeNum As String

                If SubName = "REGISTERS" Then
                    NodeNum = node.Substring(IndexOf_Dot + 1)
                Else
                    NodeNum = node.Substring(IndexOf_Dot + 2)
                End If

                Dim subm As New SubmodelInfo(SubName)
                subm.AddNodeNumber(CType(NodeNum, String))
                col += 1
                While True
                    'NodeCell = shtGroupInfo.Cells(10 + Me.Index, col)
                    NodeCell = Me.DataSheetManager.CellFirstFileSavNodeListStart.Offset(Me.Index, col)
                    If NodeCell.Value Is Nothing Then
                        subCollection.Add(subm)
                        Exit While
                    Else
                        node = NodeCell.Value.ToString
                        IndexOf_Dot = node.IndexOf(".")
                        SubName = node.Substring(0, IndexOf_Dot)
                        If SubName = "REGISTERS" Then
                            NodeNum = node.Substring(IndexOf_Dot + 1)
                        Else
                            NodeNum = node.Substring(IndexOf_Dot + 2)
                        End If

                        If subm.SubModelName = SubName Then
                            subm.AddNodeNumber(CType(NodeNum, String))
                            col += 1
                        Else
                            subCollection.Add(subm)
                            Exit While
                        End If
                    End If

                End While
            End If
        End While
        If subCollection.Count = 0 Then
            Exit Sub
        Else
            Me.ItemsToPlot = subCollection
        End If

    End Sub

    Public ReadOnly Property Submodels() As SubmodelCollection
        Get
            If SubModelList.Count = 0 Then
                StoreSubmodelInfo()
            End If
            Return SubModelList
        End Get
    End Property

    Public Property ItemsToPlot() As SubmodelCollection
        Get
            Return PlotList
        End Get
        Set(value As SubmodelCollection)
            PlotList = value
        End Set
    End Property

    Public ReadOnly Property GetSubmodelNames As Collections.Specialized.StringCollection
        Get
            OpenSaveFile()
            Dim subs As Collections.Specialized.StringCollection = sindaplot.getThermalModels()
            'SJS 06-03 COMMENTED OUT CLOSESAVFILE
            'DID NOT EXIST IN DECOMPILED CODE
            'CloseSaveFile()
            Return subs
        End Get
    End Property

    Public ReadOnly Property GetNodesInSubmodel(ByVal SubmodelName As String) As Long()
        Get

            Me.OpenSaveFile()
            Dim Nodes() As Long = sindaplot.nodesIn(SubmodelName)
            'SJS 06-03 COMMENTED OUT CLOSESAVFILE
            'DID NOT EXIST IN DECOMPILED CODE
            'Me.CloseSaveFile()
            Return Nodes

        End Get
    End Property

    Public ReadOnly Property GetTimes() As Double()
        Get
            Me.OpenSaveFile()
            Dim Times() As Double = sindaplot.getXArray()
            'SJS 06-03 COMMENTED OUT CLOSESAVFILE
            'DID NOT EXIST IN DECOMPILED CODE
            'Me.CloseSaveFile()
            Return Times
        End Get
    End Property

    Public ReadOnly Property GetTimesAsString() As String()
        Get
            Me.OpenSaveFile()
            Dim Times() As String = ConvertDoubleArrayToStringArray(sindaplot.getXArray())
            'SJS 06-03 COMMENTED OUT CLOSESAVFILE
            'DID NOT EXIST IN DECOMPILED CODE
            'Me.CloseSaveFile()
            Return Times
        End Get
    End Property

    Public ReadOnly Property GetRecordNumbers() As Double()
        Get
            Me.OpenSaveFile()
            Dim Records() As Double = sindaplot.getYArray()
            'SJS 06-03 COMMENTED OUT CLOSESAVFILE
            'DID NOT EXIST IN DECOMPILED CODE
            'Me.CloseSaveFile()
            Return Records
        End Get
    End Property

    Public ReadOnly Property GetTempArrayForNode(ByVal SubmodelName As String, ByVal NodeNumber As Long) As Double()
        Get
            Me.OpenSaveFile()
            Dim Temps() As Double = sindaplot.getTimeDataFor("T", SubmodelName.ToUpper, NodeNumber)
            'SJS 06-03 COMMENTED OUT CLOSESAVFILE
            'DID NOT EXIST IN DECOMPILED CODE
            'Me.CloseSaveFile()
            Return Temps
        End Get
    End Property

    Public ReadOnly Property GetTempArrayForNodeAsString(ByVal SubmodelName As String, ByVal NodeNumber As Long) As String()
        Get
            Me.OpenSaveFile()
            Dim Temps() As String = ConvertDoubleArrayToStringArray(sindaplot.getTimeDataFor("T", SubmodelName.ToUpper, NodeNumber))
            'SJS 06-03 COMMENTED OUT CLOSESAVFILE
            'DID NOT EXIST IN DECOMPILED CODE
            'Me.CloseSaveFile()
            Return Temps
        End Get
    End Property

    Public ReadOnly Property GetQArrayForNode(ByVal SubmodelName As String, ByVal NodeNumber As Long) As Double()
        Get
            Me.OpenSaveFile()
            Dim Temps() As Double = sindaplot.getTimeDataFor("Q", SubmodelName.ToUpper, NodeNumber)
            'SJS 06-03 COMMENTED OUT CLOSESAVFILE
            'DID NOT EXIST IN DECOMPILED CODE
            'Me.CloseSaveFile()
            Return Temps
        End Get
    End Property

    Public ReadOnly Property GetQArrayForNodeAsString(ByVal SubmodelName As String, ByVal NodeNumber As Long) As String()
        Get
            Me.OpenSaveFile()
            Dim Temps() As String = ConvertDoubleArrayToStringArray(sindaplot.getTimeDataFor("Q", SubmodelName.ToUpper, NodeNumber))
            'SJS 06-03 COMMENTED OUT CLOSESAVFILE
            'DID NOT EXIST IN DECOMPILED CODE
            'Me.CloseSaveFile()
            Return Temps
        End Get
    End Property


    Public ReadOnly Property GetTimeArrayForRegister(ByVal RegisterName As String) As Double()
        Get
            Me.OpenSaveFile()
            Dim Times() As Double = sindaplot.getTimeDataFor(RegisterName, "Register", CLng(0))

            'SJS 06-03 COMMENTED OUT CLOSESAVFILE
            'DID NOT EXIST IN DECOMPILED CODE
            'Me.CloseSaveFile()
            Return Times
        End Get
    End Property

    Public ReadOnly Property GetTimeArrayForRegisterAsString(ByVal RegisterName As String) As String()
        Get
            Me.OpenSaveFile()
            Dim TimeForRegister() As String = ConvertDoubleArrayToStringArray(sindaplot.getTimeDataFor(RegisterName, "Register", CLng(0)))
            'SJS 06-03 COMMENTED OUT CLOSESAVFILE
            'DID NOT EXIST IN DECOMPILED CODE
            'Me.CloseSaveFile()

            Return TimeForRegister
        End Get
    End Property

    Public ReadOnly Property GetRegisterNames() As Collections.Specialized.StringCollection
        Get
            Me.OpenSaveFile()
            Dim Registers As Collections.Specialized.StringCollection = sindaplot.getRegisterNames()
            'SJS 06-03 COMMENTED OUT CLOSESAVFILE
            'DID NOT EXIST IN DECOMPILED CODE
            'Me.CloseSaveFile()
            Return Registers
        End Get
    End Property

    Private Function ConvertDoubleArrayToStringArray(ByVal DoubleArray As Double()) As String()
        'Dim Darray() As Double = sindaplot.getTimeDataFor(RegisterName, "Register", CLng(0))
        Dim StringArray(DoubleArray.Count - 1) As String
        For i As Integer = 0 To DoubleArray.Count - 1
            StringArray(i) = CStr(DoubleArray(i))
        Next

        Return StringArray
    End Function


    '------------------
    'SJS 04-30-2015
    'ADDED MISSING FUNCTIONS FROM DECOMPILED V1.1

    Private Sub CreateSinapsAssembly(ByVal FileName As String)
        Try
            Me.CRLib = [Assembly].LoadFrom(FileName)
            Me.sindaplot = RuntimeHelpers.GetObjectValue(Me.CRLib.CreateInstance("SinapsXNet.SindaPlotting"))
        Catch exception As System.Exception
            Throw New System.Exception("Error, the library used to read sav files is specified incorrectly.  Use the Set SAV File Library button on the ribbon to select the correct file.")
        End Try
    End Sub

End Class

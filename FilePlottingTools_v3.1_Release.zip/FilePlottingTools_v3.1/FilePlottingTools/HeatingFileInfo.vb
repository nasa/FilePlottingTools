﻿Imports System.IO
Imports System.Collections
Imports System.Windows.Forms
Public Class HeatingFileInfo
    Inherits GenericFileInfo

    Private Deliminator As String = ","
    Private PlotHeaders As New ArrayList 'Array containing the headers of each series, excluding time (PlotHeaders(0) is first series, not time)
    Public NodeHeatingArray As New CollectionOfNodeHeatingData
    Public TimeArray As New ArrayList

    Public Sub New(ByVal Name As String, ByVal Index As Integer, ByVal RowStart As Integer, ByVal RowEnd As Integer, ByVal ColStart As Integer, ByVal ColEnd As Integer, ByRef DataSheetManater As DataSheetClass, ByRef ControlSheet As Excel.Worksheet, ByRef FormattedSheet As Excel.Worksheet, ByVal PlotHeaderRow As Integer)
        Me.Namep = Name
        Me.Indexp = Index
        Me.RowStartp = RowStart
        Me.RowEndp = RowEnd
        Me.ColStartp = ColStart
        Me.ColEndp = ColEnd
        Me.NumRowsp = RowEnd - RowStart + 1
        Me.NumColsp = ColEnd - ColStart + 1
        Me.DataSheetManager = DataSheetManater
        Me.shtDataSheet = Me.DataSheetManager.TheDataSheet
        Me.shtImport = ControlSheet
        Me.shtFormatted = FormattedSheet
        Me.FormattedSheetHeaderRow = PlotHeaderRow

    End Sub

    Public Sub New(ByVal Name As String)
        Me.Namep = Name
        'Me.Indexp = Index
        'Me.RowStartp = RowStart
        'Me.RowEndp = RowEnd
        'Me.ColStartp = ColStart
        'Me.ColEndp = ColEnd
        'Me.NumRowsp = RowEnd - RowStart + 1
        'Me.NumColsp = ColEnd - ColStart + 1
        'Me.DataSheetManager = DataSheetManater
        'Me.shtDataSheet = Me.DataSheetManager.TheDataSheet
        'Me.shtImport = ControlSheet
        'Me.shtFormatted = FormattedSheet
        'Me.FormattedSheetHeaderRow = PlotHeaderRow

    End Sub

    Public Overrides Sub ReadFileIntoClipBoard()

        Dim NumLines As Integer = 0
        Dim NumCols As Integer = 0
        Dim plotfilereader As StreamReader = New StreamReader(Me.Namep)
        Dim FileString As String = plotfilereader.ReadToEnd
        plotfilereader.Close()
        Dim NumChar As Integer = FileString.Count
        Dim LastWasDelimiter As Boolean = False
        Dim CountOffset As Integer = 0

        Dim IndexOfLastEntry = -1

        Dim line As String

        Dim FileStringReader As New StringReader(FileString)


        Dim TextBlockForNode As String = ""
        Dim IsNewNodeBlock As Boolean = False

        While True
            line = FileStringReader.ReadLine
            If line = Nothing Then
                Exit While
            ElseIf line.Contains("Time Array") Then
                While True
                    If ChrW(FileStringReader.Peek) = "C" Then
                        Exit While
                    Else
                        line = FileStringReader.ReadLine
                        If line.Contains("=") Then
                            line = line.Substring(line.IndexOf("=") + 1)
                            UsefulFunctions.ParseCommaStringAddDoubleToArray(TimeArray, line)
                        Else
                            UsefulFunctions.ParseCommaStringAddDoubleToArray(TimeArray, line)
                        End If
                    End If
                End While
            ElseIf line.Contains("-") And line.Contains("Area") And line.Contains("=") Then

                If TextBlockForNode = "" Then
                Else
                    Me.NodeHeatingArray.Add(CreateNodeHeatingData(TextBlockForNode))
                End If
                TextBlockForNode = line + vbNewLine
                IsNewNodeBlock = True
            ElseIf IsNewNodeBlock = True Then
                TextBlockForNode += line + vbNewLine
            End If

        End While

        Me.NodeHeatingArray.Add(CreateNodeHeatingData(TextBlockForNode))

        Dim SolarString As String = "Time" + vbTab
        Dim AlbedoString As String = "Time" + vbTab
        Dim PlanetString As String = "Time" + vbTab

        For Each NodeHeatData As NodeHeatingData In NodeHeatingArray
            SolarString += NodeHeatData.FullNodeName + vbTab
            AlbedoString += NodeHeatData.FullNodeName + vbTab
            PlanetString += NodeHeatData.FullNodeName + vbTab
        Next
        SolarString += vbNewLine
        AlbedoString += vbNewLine
        PlanetString += vbNewLine
        For i As Integer = 0 To NodeHeatingArray.Item(0).AlbedoArray.Count() - 1
            SolarString += Me.TimeArray(i).ToString + vbTab
            AlbedoString += Me.TimeArray(i).ToString + vbTab
            PlanetString += Me.TimeArray(i).ToString + vbTab
            For Each NodeHeatData As NodeHeatingData In NodeHeatingArray

                SolarString += NodeHeatData.SolarArray(i).ToString + vbTab
                AlbedoString += NodeHeatData.AlbedoArray(i).ToString + vbTab
                PlanetString += NodeHeatData.PlanetArray(i).ToString + vbTab

            Next
            SolarString += vbNewLine
            AlbedoString += vbNewLine
            PlanetString += vbNewLine
        Next

        Dim CombinedString As String = SolarString + vbNewLine + AlbedoString + vbNewLine + PlanetString + vbNewLine


        'Dim FileChars() As Char = UsefulFunctions.ChangeFileToTabDelimitedCharArray(Me.Namep, {Me.Deliminator, " "}, NumLines, NumCols)

        'My.Computer.Clipboard.Clear()
        My.Computer.Clipboard.SetText(CombinedString)
        'Me.NumRowsp = NumLines
        'Me.NumColsp = NumCols
    End Sub

    Public Overrides Sub UpdateDataSheet()

    End Sub
    Private Function CreateNodeHeatingData(ByVal HeatingTextBlock As String) As NodeHeatingData
        Dim HeatData As New NodeHeatingData
        Dim sReader As New StringReader(HeatingTextBlock)
        Dim line As String = ""

        While True
            line = sReader.ReadLine
            If line = Nothing Then
                Exit While
            Else
                Dim AlbedoExists As Boolean = False
                Dim SolarExists As Boolean = False
                Dim PlanetExists As Boolean = False
                Dim NumHeatingArrays As Integer = 0

                'all lines that have heating contain a dash, the word "area" and an "=". Search for this first
                If line.Contains("-") And line.Contains("Area") And line.Contains("=") Then
                    'determine which heating arrays exist for the current node
                    'the arrays are in teh following order in the file: Solar Albedo PlanetShine
                    'So if one doesn't exist, it will still follow the same order

                    If line.Contains("solar") Then
                        SolarExists = True
                        NumHeatingArrays += 1
                    Else
                        For i As Integer = 0 To Me.TimeArray.Count - 1
                            HeatData.SolarArray.Add(0.0)
                        Next
                    End If

                    If line.Contains("albedo") Then
                        AlbedoExists = True
                        NumHeatingArrays += 1
                    Else
                        For i As Integer = 0 To Me.TimeArray.Count - 1
                            HeatData.AlbedoArray.Add(0.0)
                        Next
                    End If

                    If line.Contains("planetshine") Then
                        PlanetExists = True
                        NumHeatingArrays += 1
                        For i As Integer = 0 To Me.TimeArray.Count - 1
                            HeatData.PlanetArray.Add(0.0)
                        Next
                    End If
                End If

                If NumHeatingArrays > 0 Then

                    'delete everything before the node number
                    Dim DashIndex As Integer = line.IndexOf("-")
                    line = line.Substring(DashIndex + 2)

                    'get the node number
                    Dim AreaIndex As Integer = line.IndexOf("Area =")
                    Dim Node As String = line.Substring(0, AreaIndex - 1)

                    'remove node number from line
                    line = line.Substring(AreaIndex)

                    'Remove the area text from the line
                    line = line.Replace("Area = ", "")
                    'get the area
                    Dim AvgIndex As Integer = line.IndexOf("Avg =")
                    Dim Area As Double = CType(line.Substring(0, AvgIndex - 1), Double)

                    'TODO read the average values from the line based on the types of heating


                    HeatData.FullNodeName = Node
                    HeatData.NodeArea = Area

                    'loop through the number of heating arrays that exist
                    Dim i As Integer = 0

                    While i < NumHeatingArrays
                        Dim heatList As New ArrayList

                        While True
                          
                            line = sReader.ReadLine

                            If line Is Nothing Then
                                i += 1
                                Exit While
                            ElseIf (line(0) = "C" Or line.Contains("PSTART")) And heatList.Count > 0 Then
                                'end of the array has been reached if this is true
                                'increment i
                                i += 1
                                Exit While
                            ElseIf line(0) = "C" Then
                                'this is a comment line, and the array is not done yet do nothing, go to next line
                            ElseIf line.Contains("=") Then
                                'this is the start of the first heating array
                                line = line.Substring(line.IndexOf("=") + 1)
                                UsefulFunctions.ParseCommaStringAddDoubleToArray(heatList, line)
                            Else
                                'line must be a continuation of the array, parse
                                UsefulFunctions.ParseCommaStringAddDoubleToArray(heatList, line)
                            End If
                            'line = FileStringReader.ReadLine
                        End While

                        'determine which heating type the array is, and store in the NodeHeatingData
                        If i = 1 Then
                            If SolarExists Then
                                HeatData.SolarArray = heatList
                            ElseIf AlbedoExists Then
                                HeatData.AlbedoArray = heatList
                            Else
                                HeatData.PlanetArray = heatList
                            End If
                        ElseIf i = 2 Then
                            If SolarExists And AlbedoExists Then
                                'if solar and albedo exist, the second array must be albedo
                                HeatData.AlbedoArray = heatList
                            ElseIf AlbedoExists Then
                                'if solar does not exist, then the second array must be planet
                                'there is no other option, if only planet, then there is only 1 array
                                HeatData.PlanetArray = heatList
                            End If
                        ElseIf i = 3 Then
                            'the third array must be planetshine if it exists
                            HeatData.PlanetArray = heatList
                        End If
                    End While


                    'MessageBox.Show(Node + " " + Area.ToString)
                    'Exit While


                End If

            End If


        End While



        Return HeatData
    End Function
End Class

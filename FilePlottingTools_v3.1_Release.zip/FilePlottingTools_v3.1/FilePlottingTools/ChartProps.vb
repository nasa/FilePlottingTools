﻿Public Class ChartProps
    Public Name As String
    Public index As Integer
    Public XlimMin As Double
    Public XlimMax As Double
    Public YlimMin As Double
    Public YlimMax As Double
    Public Xaxis As Excel.Axis
    Public Yaxis As Excel.Axis

    Public Sub New(ByRef chart As Excel.Chart, ByVal index As Integer)
        Me.Name = chart.Name
        Me.index = index
        Me.Xaxis = chart.Axes(Excel.XlAxisType.xlCategory)
        Me.Yaxis = chart.Axes(Excel.XlAxisType.xlValue)

        Me.XlimMax = Xaxis.MaximumScale
        Me.XlimMin = Xaxis.MinimumScale
        Me.YlimMax = Yaxis.MaximumScale
        Me.YlimMin = Yaxis.MinimumScale


    End Sub


End Class

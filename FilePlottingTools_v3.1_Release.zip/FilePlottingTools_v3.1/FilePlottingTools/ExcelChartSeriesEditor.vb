﻿Imports System.Drawing
Imports System.Windows.Forms
Imports System.Collections

Public Class ExcelChartSeriesEditor
    Private SeriesColor As Color
    Private ColorDiag As ColorDialog
    Private ColorSelectForm As CustomControlsLibrary.ColorSelectorForm
    Private ColorList As ArrayList
    Private PlotOrder As Integer

    'NOTE:  This is not done,, needs work, aSeries is not integer
    Public Sub New(ByRef aSeries As Excel.Series, ByRef ButtonColors As ArrayList, ByRef ClrDiag As ColorDialog)
        InitializeComponent()
        Me.AutoScaleMode = Windows.Forms.AutoScaleMode.Dpi
        Me.ColorList = ButtonColors
        Me.ColorDiag = ClrDiag
        Me.lblSeriesName.Text = aSeries.Name
        Me.PlotOrder = aSeries.PlotOrder

        Me.btnColor.InitialzeButton(Me.ColorList, Me.ColorDiag)
        Me.btnColor.MyColor = ColorTranslator.FromOle(aSeries.Border.Color)
        Me.cmbLineStyle.Text = GetComboBoxLineStyleText(aSeries)

        'SJS 04-30-15 WAS IN DECOMPILE, BUT NOT HERE
        Me.nudLineWeight.Value = aSeries.Format.Line.Weight

    End Sub



    Private Function GetComboBoxLineStyleText(ByRef aSeries As Excel.Series) As String

        If aSeries.Format.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineSolid Then
            Return "Solid"
        ElseIf aSeries.Format.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineRoundDot Then
            Return "RoundDot"
        ElseIf aSeries.Format.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineSquareDot Then
            Return "SquareDot"
        ElseIf aSeries.Format.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineDash Then
            Return "Dash"
        ElseIf aSeries.Format.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineDashDot Then
            Return "DashDot"
        ElseIf aSeries.Format.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineLongDash Then
            Return "LongDash"
        ElseIf aSeries.Format.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineLongDashDot Then
            Return "LongDashDot"
        ElseIf aSeries.Format.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineLongDashDotDot Then
            Return "LongDashDotDot"
        Else
            'this is an error condition, shouldn't be possible to return empty string
            Return ""
        End If
    End Function

    Public ReadOnly Property GetColor As Color
        Get
            Return Me.btnColor.MyColor
        End Get
    End Property

    Public ReadOnly Property GetPlotOrder As Integer
        Get
            Return Me.PlotOrder
        End Get
    End Property

    Public ReadOnly Property GetLineStyle As Integer
        Get
            If cmbLineStyle.Text = "Solid" Then
                Return Microsoft.Office.Core.MsoLineDashStyle.msoLineSolid
            ElseIf cmbLineStyle.Text = "RoundDot" Then
                Return Microsoft.Office.Core.MsoLineDashStyle.msoLineRoundDot
            ElseIf cmbLineStyle.Text = "SquareDot" Then
                Return Microsoft.Office.Core.MsoLineDashStyle.msoLineSquareDot
            ElseIf cmbLineStyle.Text = "Dash" Then
                Return Microsoft.Office.Core.MsoLineDashStyle.msoLineDash
            ElseIf cmbLineStyle.Text = "DashDot" Then
                Return Microsoft.Office.Core.MsoLineDashStyle.msoLineDashDot
            ElseIf cmbLineStyle.Text = "LongDash" Then
                Return Microsoft.Office.Core.MsoLineDashStyle.msoLineLongDash
            ElseIf cmbLineStyle.Text = "LongDashDot" Then
                Return Microsoft.Office.Core.MsoLineDashStyle.msoLineLongDashDot
            ElseIf cmbLineStyle.Text = "LongDashDotDot" Then
                Return Microsoft.Office.Core.MsoLineDashStyle.msoLineLongDashDotDot
            End If
        End Get
    End Property

    'SJS 04-30-15 WAS IN DECOMPILE, BUT NOT HERE
    Public Sub New(ByVal aSeries As SeriesFormatInfo, ByRef ButtonColors As ArrayList, ByRef ClrDiag As ColorDialog)
        Me.InitializeComponent()
        Me.ColorList = ButtonColors
        Me.ColorDiag = ClrDiag
        Me.lblSeriesName.Text = aSeries.Name
        Me.PlotOrder = aSeries.PlotOrder
        Me.btnColor.InitialzeButton(Me.ColorList, Me.ColorDiag)
        Me.btnColor.MyColor = aSeries.LineColor
        Me.cmbLineStyle.Text = aSeries.LineDashString
        Me.nudLineWeight.Value = aSeries.LineWeight
    End Sub
End Class

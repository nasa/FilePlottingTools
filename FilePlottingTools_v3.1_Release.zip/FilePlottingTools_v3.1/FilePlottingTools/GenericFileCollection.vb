﻿Public Class GenericFileCollection
    Inherits Collections.CollectionBase

    Public Sub Add(ByVal file As GenericFileInfo)
        Me.List.Add(file)
    End Sub

    Public Sub Remove(ByVal file As GenericFileInfo)
        Me.List.Remove(file)
    End Sub

    Public Property Item(ByVal index As Integer) As GenericFileInfo
        Get
            Return CType(Me.List.Item(index), GenericFileInfo)
        End Get
        Set(ByVal value As GenericFileInfo)
            Me.List.Item(index) = value
        End Set
    End Property
End Class

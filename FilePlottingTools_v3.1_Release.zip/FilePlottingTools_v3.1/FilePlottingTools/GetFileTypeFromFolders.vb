﻿Public Class GetFileTypeFromFolders
    Public SelectedFilter As String
    '------------------------------
    'SJS 05-01-15 ADDED BACK FROM DECOMPILED CODE
    Public Sub New(ByVal RemoveSavOption As Boolean)
        InitializeComponent()
        If (RemoveSavOption) Then
            Me.ComboBox1.Items.Remove(".sav")
        End If
    End Sub
    '------------------------

    Private Sub btnIgnoreFolders_Click(sender As System.Object, e As System.EventArgs) Handles btnIgnoreFolders.Click
        DialogResult = Windows.Forms.DialogResult.Ignore
        Me.Close()
    End Sub

    Private Sub btnOk_Click(sender As System.Object, e As System.EventArgs) Handles btnOk.Click
        DialogResult = Windows.Forms.DialogResult.OK
        SelectedFilter = ComboBox1.Text
        Me.Close()
    End Sub
End Class
﻿Public Class ImportHeating
    Public FileName As String
    Public SubmodelName As String
    Public NodeStart As Integer
    Public NodeEnd As Integer

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        Me.FileName = txtFileName.Text
        'Me.SubmodelName = txtSubmodel.Text
        'Me.NodeStart = CType(txtStartNode.Text, Integer)
        'Me.NodeEnd = CType(txtEndNode.Text, Integer)
        Me.DialogResult = Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub
End Class
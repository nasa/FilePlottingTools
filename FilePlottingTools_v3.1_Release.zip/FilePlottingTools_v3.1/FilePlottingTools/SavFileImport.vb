﻿Imports System.Collections
Imports System.Windows.Forms
Public Class SavFileImport
    Private InputSubmodelList As SubmodelCollection
    Private SelectedNodesList As SubmodelCollection
    Private OutputSubmodelList As New SubmodelCollection

    Private SelectorCollection As New ArrayList
    Private SelectorPanel As SplitterPanel
    Private LastFileIndex As Integer = 0

    Private Sub New()

        ' This call is required by the designer.
        InitializeComponent()
        Me.AutoScaleMode = Windows.Forms.AutoScaleMode.Dpi

        ' Add any initialization after the InitializeComponent() call.
        Me.SelectorPanel = SplitContainer03.Panel2

    End Sub

    Public Sub New(ByRef SubmodelList As SubmodelCollection)
        Me.New()
        Me.InputSubmodelList = SubmodelList
        PopulateNodeLists()
    End Sub

    Public Sub New(ByRef SubmodelList As SubmodelCollection, ByRef SelectedValues As SubmodelCollection)
        Me.New()
        Me.InputSubmodelList = SubmodelList
        Me.SelectedNodesList = SelectedValues
        PopulateNodeLists()
        If Me.SelectedNodesList Is Nothing Then
        Else
            SetInitialChecks()
        End If

    End Sub

    Private Sub PopulateNodeLists()

        'ListBox1.Items.Add("REGISTERS")
        'Dim RegList As New SavNodeSelector("REGISTERS", Me.Registers)
        'SelectorCollection.Add(RegList)

        For Each submodel As SubmodelInfo In Me.InputSubmodelList
            ListBox1.Items.Add(submodel.SubModelName)
            Dim nodelist As New SavNodeSelector(submodel)
            'sall.Dock = DockStyle.Fill
            SelectorCollection.Add(nodelist)
        Next
        ListBox1.SelectedIndex = 0

    End Sub

    Private Sub SetInitialChecks()
        For Each subm As SubmodelInfo In SelectedNodesList
            Dim indexOfSub As Integer = InputSubmodelList.IndexOf(subm.SubModelName)
            If indexOfSub = -1 Then
                MessageBox.Show("Error, bad submodel name, " + subm.SubModelName.ToUpper + " from savefileimport.setinitialchecks().  This may happen if you deleted all sav files, and added new sav files")
            Else

                Dim SavNodeList As SavNodeSelector = CType(SelectorCollection.Item(indexOfSub), SavNodeSelector)
                Me.ListBox1.SetItemCheckState(indexOfSub, CheckState.Checked)
                For i As Integer = 0 To SavNodeList.CheckedListBox1.Items.Count - 1
                    If subm.NodeNumberExists(SavNodeList.CheckedListBox1.Items(i)) Then
                        SavNodeList.CheckedListBox1.SetItemCheckState(i, CheckState.Checked)
                    End If
                Next
            End If
        Next
    End Sub

    Private Sub ClearContainers()
        ListBox1.Items.Clear()
        SelectorPanel.Controls.Clear()
        SelectorCollection.Clear()
        LastFileIndex = 0
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub btnOk_Click(sender As System.Object, e As System.EventArgs) Handles btnOk.Click

        If IsAnythingSelected() Then
            For i As Integer = 0 To SelectorCollection.Count - 1
                Dim CheckedIndices As ArrayList = CType(SelectorCollection.Item(i), SavNodeSelector).GetCheckedIndices
                Dim NumNodes As Integer = CheckedIndices.Count
                Dim nodes As New Specialized.StringCollection

                For j As Integer = 0 To NumNodes - 1
                    nodes.Add(Me.InputSubmodelList(i).GetNode(CheckedIndices(j)))
                Next

                Dim subm As New SubmodelInfo(Me.InputSubmodelList(i).SubModelName, nodes)
                OutputSubmodelList.Add(subm)
            Next

            Me.DialogResult = Windows.Forms.DialogResult.OK
            Me.Close()
        Else
            MessageBox.Show("No nodes/registers selected.  Select at least one node/register, or cancel")
        End If


    End Sub

    Private Sub ListBox1_SelectedIndexChanged1(sender As Object, e As System.EventArgs) Handles ListBox1.SelectedIndexChanged

        Dim selectionlist As SavNodeSelector = SelectorCollection(ListBox1.SelectedIndex)
        UpdateChecksOnFileList()
        SelectorPanel.Controls.Add(selectionlist)
        selectionlist.Dock = DockStyle.Fill
        LastFileIndex = ListBox1.SelectedIndex


    End Sub

    Private Sub UpdateChecksOnFileList()
        For i As Integer = 0 To SelectorPanel.Controls.Count - 1
            If CType(SelectorPanel.Controls(i), SavNodeSelector).HasSelections Then
                ListBox1.SetItemCheckState(LastFileIndex, CheckState.Checked)
            Else
                ListBox1.SetItemCheckState(LastFileIndex, CheckState.Unchecked)
            End If
            SelectorPanel.Controls.RemoveAt(i)
        Next
    End Sub

    Private Function IsAnythingSelected() As Boolean

        For Each nodelist As SavNodeSelector In SelectorCollection
            If nodelist.HasSelections Then
                Return True
            End If
        Next
        Return False

    End Function

    Public ReadOnly Property GetSelectedSubmodels() As SubmodelCollection
        Get
            Return OutputSubmodelList
        End Get
    End Property
End Class
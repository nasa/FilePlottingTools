﻿Public Class PlotSeriesInfo
    Public TimeColumn As Integer    'The column number containing the time (x) values of x-y plot
    Public ValuesColumn As Integer  'the column number containint the values (y) values of x-y plot
    Public RowStart As Integer      'the first row containing data
    Public RowEnd As Integer        'the last row containing data
    Private FileNameOnly As String   'the file name of the selected series
    Private UseFileNameInLegend As Boolean = False



    Public Sub New()

    End Sub

    Public Sub New(ByVal TimeCol As Integer, ByVal ValuesCol As Integer, ByVal RowStart As Integer, ByVal RowEnd As Integer)
        Me.TimeColumn = TimeCol
        Me.ValuesColumn = ValuesCol
        Me.RowStart = RowStart
        Me.RowEnd = RowEnd

    End Sub

    Public Sub New(ByVal TimeCol As Integer, ByVal ValuesCol As Integer, ByVal RowStart As Integer, ByVal RowEnd As Integer, ByVal FileName As String, ByVal UseFileNameInLegend As Boolean)
        Me.TimeColumn = TimeCol
        Me.ValuesColumn = ValuesCol
        Me.RowStart = RowStart
        Me.RowEnd = RowEnd
        Me.FileNameOnly = FileName
        Me.UseFileNameInLegend = UseFileNameInLegend

    End Sub

    Public ReadOnly Property FileName As String
        Get
            If Me.FileNameOnly Is Nothing Then
                Return ""
            Else
                Return Me.FileNameOnly + " "
            End If
        End Get
    End Property

    'the cell to use as the series name (i.e., ='Formatted Data'!&B18  )
    Public ReadOnly Property SeriesNameAddress(ByVal sheet As Excel.Worksheet)
        'SJS 05-01-15 DIDN'T REVIEW, ASSUMING ITS THE SAME
        Get
            If Me.UseFileNameInLegend = False Then
                Dim NameString = "='" + sheet.Name + "'!$"
                Dim NameCellAddress = sheet.Cells(Me.RowStart - 1, Me.ValuesColumn).Address.ToString

                For i As Integer = 1 To NameCellAddress.Count - 1
                    If NameCellAddress(i) = "$" Then
                        NameString += NameCellAddress(i)
                        Exit For
                    Else
                        NameString += NameCellAddress(i)
                    End If
                Next

                NameString += (RowStart - 1).ToString
                Return NameString
            Else
                Dim NameString = "='" + sheet.Name + "'!$"
                Dim NameCellAddress = sheet.Cells(Me.RowStart - 2, Me.ValuesColumn).Address.ToString
                Dim HeaderCellAddress = sheet.Cells(Me.RowStart - 1, Me.ValuesColumn).Address.ToString

                For i As Integer = 1 To NameCellAddress.Count - 1
                    If NameCellAddress(i) = "$" Then
                        NameString += NameCellAddress(i)
                        Exit For
                    Else
                        NameString += NameCellAddress(i)
                    End If
                Next

                NameString += (RowStart - 2).ToString
                'SET FILENAME + NODE IN ROW 18
                sheet.Cells(Me.RowStart - 2, Me.ValuesColumn).Value = "=""" + Me.FileName + """&" + HeaderCellAddress.ToString
                Return (NameString)

            End If


        End Get
    End Property

    Public Sub IncrementToNextFile(ByVal ColIncrement As Integer, ByVal RowIncrement As Integer)
        Me.TimeColumn += ColIncrement
        Me.ValuesColumn += ColIncrement
        Me.RowEnd += RowIncrement
    End Sub
End Class

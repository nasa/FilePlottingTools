﻿Partial Class FilePlottingRibon
    Inherits Microsoft.Office.Tools.Ribbon.RibbonBase

    <System.Diagnostics.DebuggerNonUserCode()> _
   Public Sub New(ByVal container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        If (container IsNot Nothing) Then
            container.Add(Me)
        End If

    End Sub

    <System.Diagnostics.DebuggerNonUserCode()> _
    Public Sub New()
        MyBase.New(Globals.Factory.GetRibbonFactory())

        'This call is required by the Component Designer.
        InitializeComponent()

    End Sub

    'Component overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Tab2 = Me.Factory.CreateRibbonTab
        Me.Group1 = Me.Factory.CreateRibbonGroup
        Me.btnFileManager = Me.Factory.CreateRibbonButton
        Me.btnRefresh = Me.Factory.CreateRibbonButton
        Me.btnRefreshImportOnly = Me.Factory.CreateRibbonButton
        Me.btnEnvHeatingImport = Me.Factory.CreateRibbonButton
        Me.grpPlotTools = Me.Factory.CreateRibbonGroup
        Me.btnNewPlot = Me.Factory.CreateRibbonButton
        Me.btnPlotManager = Me.Factory.CreateRibbonButton
        Me.btnAddSeries = Me.Factory.CreateRibbonButton
        Me.btnSeriesFormat = Me.Factory.CreateRibbonButton
        Me.btnTEST = Me.Factory.CreateRibbonButton
        Me.Group2 = Me.Factory.CreateRibbonGroup
        Me.btnCompareMaxMin = Me.Factory.CreateRibbonButton
        Me.Group3 = Me.Factory.CreateRibbonGroup
        Me.btnSetSavLib = Me.Factory.CreateRibbonButton
        Me.grpHelp = Me.Factory.CreateRibbonGroup
        Me.btnHelp = Me.Factory.CreateRibbonButton
        Me.btnAbout = Me.Factory.CreateRibbonButton
        Me.Tab2.SuspendLayout()
        Me.Group1.SuspendLayout()
        Me.grpPlotTools.SuspendLayout()
        Me.Group2.SuspendLayout()
        Me.Group3.SuspendLayout()
        Me.grpHelp.SuspendLayout()
        Me.SuspendLayout()
        '
        'Tab2
        '
        Me.Tab2.Groups.Add(Me.Group1)
        Me.Tab2.Groups.Add(Me.grpPlotTools)
        Me.Tab2.Groups.Add(Me.Group2)
        Me.Tab2.Groups.Add(Me.Group3)
        Me.Tab2.Groups.Add(Me.grpHelp)
        Me.Tab2.Label = "FilePlottingTools"
        Me.Tab2.Name = "Tab2"
        '
        'Group1
        '
        Me.Group1.Items.Add(Me.btnFileManager)
        Me.Group1.Items.Add(Me.btnRefresh)
        Me.Group1.Items.Add(Me.btnRefreshImportOnly)
        Me.Group1.Items.Add(Me.btnEnvHeatingImport)
        Me.Group1.Label = "File Management"
        Me.Group1.Name = "Group1"
        '
        'btnFileManager
        '
        Me.btnFileManager.Label = "File Manager"
        Me.btnFileManager.Name = "btnFileManager"
        '
        'btnRefresh
        '
        Me.btnRefresh.Label = "Refresh All"
        Me.btnRefresh.Name = "btnRefresh"
        '
        'btnRefreshImportOnly
        '
        Me.btnRefreshImportOnly.Label = "Refresh Import Only"
        Me.btnRefreshImportOnly.Name = "btnRefreshImportOnly"
        '
        'btnEnvHeatingImport
        '
        Me.btnEnvHeatingImport.Label = "Import Heating"
        Me.btnEnvHeatingImport.Name = "btnEnvHeatingImport"
        Me.btnEnvHeatingImport.Visible = False
        '
        'grpPlotTools
        '
        Me.grpPlotTools.Items.Add(Me.btnNewPlot)
        Me.grpPlotTools.Items.Add(Me.btnPlotManager)
        Me.grpPlotTools.Items.Add(Me.btnAddSeries)
        Me.grpPlotTools.Items.Add(Me.btnSeriesFormat)
        Me.grpPlotTools.Items.Add(Me.btnTEST)
        Me.grpPlotTools.Label = "Plotting Tools"
        Me.grpPlotTools.Name = "grpPlotTools"
        '
        'btnNewPlot
        '
        Me.btnNewPlot.Label = "New Plot"
        Me.btnNewPlot.Name = "btnNewPlot"
        '
        'btnPlotManager
        '
        Me.btnPlotManager.Label = "Plot Manager"
        Me.btnPlotManager.Name = "btnPlotManager"
        '
        'btnAddSeries
        '
        Me.btnAddSeries.Label = "Add Series"
        Me.btnAddSeries.Name = "btnAddSeries"
        '
        'btnSeriesFormat
        '
        Me.btnSeriesFormat.Label = "Format Series"
        Me.btnSeriesFormat.Name = "btnSeriesFormat"
        '
        'btnTEST
        '
        Me.btnTEST.Label = "TEST"
        Me.btnTEST.Name = "btnTEST"
        Me.btnTEST.ShowLabel = False
        '
        'Group2
        '
        Me.Group2.Items.Add(Me.btnCompareMaxMin)
        Me.Group2.Label = "Compare"
        Me.Group2.Name = "Group2"
        '
        'btnCompareMaxMin
        '
        Me.btnCompareMaxMin.Label = "Compare Max Min"
        Me.btnCompareMaxMin.Name = "btnCompareMaxMin"
        '
        'Group3
        '
        Me.Group3.Items.Add(Me.btnSetSavLib)
        Me.Group3.Label = "Manage Plugins"
        Me.Group3.Name = "Group3"
        '
        'btnSetSavLib
        '
        Me.btnSetSavLib.Label = "Set SAV Library"
        Me.btnSetSavLib.Name = "btnSetSavLib"
        '
        'grpHelp
        '
        Me.grpHelp.Items.Add(Me.btnHelp)
        Me.grpHelp.Items.Add(Me.btnAbout)
        Me.grpHelp.Label = "Support"
        Me.grpHelp.Name = "grpHelp"
        '
        'btnHelp
        '
        Me.btnHelp.Label = "Help"
        Me.btnHelp.Name = "btnHelp"
        '
        'btnAbout
        '
        Me.btnAbout.Label = "About"
        Me.btnAbout.Name = "btnAbout"
        '
        'FilePlottingRibon
        '
        Me.Name = "FilePlottingRibon"
        Me.RibbonType = "Microsoft.Excel.Workbook"
        Me.Tabs.Add(Me.Tab2)
        Me.Tab2.ResumeLayout(False)
        Me.Tab2.PerformLayout()
        Me.Group1.ResumeLayout(False)
        Me.Group1.PerformLayout()
        Me.grpPlotTools.ResumeLayout(False)
        Me.grpPlotTools.PerformLayout()
        Me.Group2.ResumeLayout(False)
        Me.Group2.PerformLayout()
        Me.Group3.ResumeLayout(False)
        Me.Group3.PerformLayout()
        Me.grpHelp.ResumeLayout(False)
        Me.grpHelp.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Tab2 As Microsoft.Office.Tools.Ribbon.RibbonTab
    Friend WithEvents Group1 As Microsoft.Office.Tools.Ribbon.RibbonGroup
    Friend WithEvents btnFileManager As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents btnRefresh As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents grpPlotTools As Microsoft.Office.Tools.Ribbon.RibbonGroup
    Friend WithEvents btnNewPlot As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents btnPlotManager As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents Group2 As Microsoft.Office.Tools.Ribbon.RibbonGroup
    Friend WithEvents btnCompareMaxMin As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents btnRefreshImportOnly As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents grpHelp As Microsoft.Office.Tools.Ribbon.RibbonGroup
    Friend WithEvents btnHelp As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents btnAbout As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents btnAddSeries As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents btnSeriesFormat As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents btnTEST As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents Group3 As Microsoft.Office.Tools.Ribbon.RibbonGroup
    Friend WithEvents btnSetSavLib As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents btnEnvHeatingImport As Microsoft.Office.Tools.Ribbon.RibbonButton
End Class

Partial Class ThisRibbonCollection

    <System.Diagnostics.DebuggerNonUserCode()> _
    Friend ReadOnly Property FilePlottingRibon() As FilePlottingRibon
        Get
            Return Me.GetRibbon(Of FilePlottingRibon)()
        End Get
    End Property
End Class

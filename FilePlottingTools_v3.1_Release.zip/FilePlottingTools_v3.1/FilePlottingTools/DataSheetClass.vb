﻿Imports System.Collections
Imports System.IO
Imports System.Windows.Forms

Public Class DataSheetClass
    Public TheDataSheet As Excel.Worksheet


    Public Sub New(ByRef DataSheet As Excel.Worksheet)
        Me.TheDataSheet = DataSheet
    End Sub

    Public Sub New(ByVal DataSheetName As String)
        If SheetNameExists(DataSheetName) Then
            Me.TheDataSheet = UsefulFunctions.GetWorkSheetByName(DataSheetName, Globals.ThisAddIn.Application.ActiveWorkbook)
        Else
            CreateADataSheetInWorkbook(DataSheetName)
        End If
    End Sub

    'SJS 05-11-15 CELL PROPERTIES TO EXPOSE THE CELLS
    'The Purpose of these properties is to retun the cells
    'that contain data that is used in the program.  Any text that is
    'written in the data sheet for comments should be reference from
    'these cell values in the CreateADataSheetInWorkbook function.

    Public ReadOnly Property CellNumberOfFiles As Excel.Range
        Get
            Return Me.TheDataSheet.Range("B1")
        End Get
    End Property

    Public ReadOnly Property CellRefreshOnOpen As Excel.Range
        Get
            Return Me.TheDataSheet.Range("B2")
        End Get
    End Property

    Public ReadOnly Property CellIsSavFiles As Excel.Range
        Get
            Return Me.TheDataSheet.Range("B3")
        End Get
    End Property

    Public ReadOnly Property CellFilePlotterVersion As Excel.Range
        Get
            Return Me.TheDataSheet.Range("B4")
        End Get
    End Property

    Public ReadOnly Property CellTypeOfStitch As Excel.Range
        Get
            Return Me.TheDataSheet.Range("B10")
        End Get
    End Property

    Public ReadOnly Property CellCompareOrStich As Excel.Range
        Get
            Return Me.TheDataSheet.Range("B11")
        End Get
    End Property

    Public ReadOnly Property CellDelimiter As Excel.Range
        Get
            Return Me.TheDataSheet.Range("B12")
        End Get
    End Property

    Public ReadOnly Property CellFirstFileName As Excel.Range
        Get
            Return Me.TheDataSheet.Range("C10")
        End Get
    End Property

    Public ReadOnly Property CellFirstFileRowStart As Excel.Range
        Get
            Return Me.TheDataSheet.Range("D10")
        End Get
    End Property

    Public ReadOnly Property CellFirstFileRowEnd As Excel.Range
        Get
            Return Me.TheDataSheet.Range("E10")
        End Get
    End Property

    Public ReadOnly Property CellFirstFileColStart As Excel.Range
        Get
            Return Me.TheDataSheet.Range("F10")
        End Get
    End Property

    Public ReadOnly Property CellFirstFileColEnd As Excel.Range
        Get
            Return Me.TheDataSheet.Range("G10")
        End Get
    End Property

    Public ReadOnly Property CellFirstFileSavNodeListStart As Excel.Range
        Get
            Return Me.TheDataSheet.Range("H10")
        End Get
    End Property

    Public Function CellTEST(Optional ByVal RowOffset As Integer = 0, Optional ByVal ColOffset As Integer = 0) As Excel.Range

        Return Me.TheDataSheet.Range("E4").Offset(RowOffset, ColOffset)

    End Function

    'DEFAULT PLOT CELLS
    Public ReadOnly Property CellDefaultChartGlobalFontSize
        Get
            Return Me.TheDataSheet.Range("B20")
        End Get
    End Property

    Public ReadOnly Property CellDefaultChartLegendFontSize
        Get
            Return Me.TheDataSheet.Range("B21")
        End Get
    End Property
    Public ReadOnly Property CellDefaultChartXaxisFontSize
        Get
            Return Me.TheDataSheet.Range("B22")
        End Get
    End Property
    Public ReadOnly Property CellDefaultChartYaxisFontSize
        Get
            Return Me.TheDataSheet.Range("B23")
        End Get
    End Property
    Public ReadOnly Property CellDefaultChartXlabelFontSize
        Get
            Return Me.TheDataSheet.Range("B24")
        End Get
    End Property
    Public ReadOnly Property CellDefaultChartYlabelFontSize
        Get
            Return Me.TheDataSheet.Range("B25")
        End Get
    End Property
    Public ReadOnly Property CellDefaultChartTitleFontSize
        Get
            Return Me.TheDataSheet.Range("B26")
        End Get
    End Property

    Public ReadOnly Property CellDefaultChartHasTitle
        Get
            Return Me.TheDataSheet.Range("B27")
        End Get
    End Property

    Public ReadOnly Property CellDefaultChartLegendLocation
        Get
            Return Me.TheDataSheet.Range("B28")
        End Get
    End Property

    'FUNCTIONS AND SUBROUTINES
    Public Sub CreateADataSheetInWorkbook(ByVal SheetName As String)


        'If Me.ThisWorkbook.Sheets(1).Name = SheetName Then
        '    Me.shtDataSheet = ThisWorkbook.Sheets(1)
        '    Exit Function
        'Else
        '    Me.shtDataSheet = CreateNewWorksheet(SheetName)
        '    Me.shtDataSheet.Move(ThisWorkbook.Sheets(1))
        'End If
        Me.TheDataSheet = CreateNewWorksheet(SheetName)
        'Me.TheDataSheet.Move(Globals.ThisAddIn.Application.ActiveWorkbook.Sheets(1))

        Me.CellNumberOfFiles.Offset(, -1).Value = "Number Of Files"
        Me.CellRefreshOnOpen.Offset(, -1).Value = "Refresh On Open"
        Me.CellIsSavFiles.Offset(, -1).Value = "Is SavFiles"
        Me.CellFilePlotterVersion.Offset(, -1).Value = "FilePlotterVersion"
        Me.CellTypeOfStitch.Offset(, -1).Value = "Type Of Stitch"
        Me.CellCompareOrStich.Offset(, -1).Value = "Compare or Stitch"
        Me.CellDelimiter.Offset(, -1).Value = "Delimiter"
        'Don't think I actually use these:
        'Me.shtDataSheet.Offset(, -1).Value = "NumRows"
        'Me.shtDataSheet.Offset(, -1).Value = "NumCols"

        Me.CellNumberOfFiles.Value = "=COUNTA(C10:C1048576)"
        Me.CellFilePlotterVersion.Value = UsefulFunctions.GetVersionString

        Me.CellFirstFileName.Offset(-1).Value = "FILE"
        Me.CellFirstFileRowStart.Offset(-1).Value = "ROW START"
        Me.CellFirstFileRowEnd.Offset(-1).Value = "ROW END"
        Me.CellFirstFileColStart.Offset(-1).Value = "COLS START"
        Me.CellFirstFileColEnd.Offset(-1).Value = "COL END"
        Me.CellFirstFileSavNodeListStart.Offset(-1).Value = "SAV PLOT LIST"

        Me.TheDataSheet.Visible = Excel.XlSheetVisibility.xlSheetVeryHidden
    End Sub

    Private Function CreateNewWorksheet(ByVal SheetName As String) As Excel.Worksheet
        'FPT1.1 HAS THIS CODE, NOT SURE IF ITS THE SAME
        'Dim worksheets As Sheets = Me.ThisWorkbook.Worksheets
        'worksheets.Add(, worksheets.Count)
        'Dim count As Worksheet = DirectCast(worksheets(worksheets.Count), Worksheet)
        'count.Name = SheetName
        'Return count

        Dim Sheets As Microsoft.Office.Interop.Excel.Sheets
        Sheets = Globals.ThisAddIn.Application.ActiveWorkbook.Worksheets

        Sheets.Add(, Sheets(Sheets.Count))
        Dim NewSheet As Excel.Worksheet = Sheets(Sheets.Count)
        NewSheet.Name = SheetName
        Return NewSheet
    End Function

    Public Function SheetNameExists(ByVal Name As String) As Boolean
        For Each sht In Globals.ThisAddIn.Application.ActiveWorkbook.Sheets
            If sht.Name = Name Then
                Return True
            End If
        Next
        Return False
    End Function

    Public Sub ClearDataSheetFilesInfoBlock()
        'dangerous hardcodes
        'SJS TODO 05-01-15 CHECK THE RANGE OF THE CLEAR
        Me.TheDataSheet.Range(Me.CellFirstFileName, Me.TheDataSheet.Range("AAA30000")).Clear()
    End Sub

    Public Sub ClearDataSheet()
        'SJS TODO 05-01-15 CHECK THE RANGE OF THE CLEAR, SHOULD BE FINE BUT ITS
        'NOT THE WHOLE SHEET
        'WHY DOES THIS ONLY CLEAR THE FIRST 2 COLUMNS???
        Me.TheDataSheet.Range("B10:C30000").Clear()
        'Me.TheDataSheet.Range(Me.CellFirstFileName, Me.TheDataSheet.Range("C30000")).Clear()


    End Sub
End Class

﻿Public Class PlotSeriesInfoCollection
    Inherits Collections.CollectionBase

    Public Sub Add(ByVal seriesinfo As PlotSeriesInfo)
        Me.List.Add(seriesinfo)
    End Sub

    Public Sub Remove(ByVal seriesinfo As PlotSeriesInfo)
        Me.List.Remove(seriesinfo)
    End Sub

    Public Property Item(ByVal index As Integer) As PlotSeriesInfo
        Get
            Return CType(Me.List.Item(index), PlotSeriesInfo)
        End Get
        Set(ByVal value As PlotSeriesInfo)
            Me.List.Item(index) = value
        End Set
    End Property
End Class

﻿Imports System.Collections
Imports System.Windows.Forms

Public Class SavNodeSelector
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()
        Me.AutoScaleMode = Windows.Forms.AutoScaleMode.Dpi
        ' Add any initialization after the InitializeComponent() call.

    End Sub
    Public Sub New(ByVal submodel As SubmodelInfo)
        Me.New()
        RefreshList(submodel)
    End Sub

    Public Sub New(ByVal ListName As String, ByVal items As Specialized.StringCollection)
        Me.New()
        RefreshList(items)
    End Sub

    Public Sub RefreshList(ByVal submodel As SubmodelInfo)
        For Each NodeName As String In submodel.GetAllNodes
            CheckedListBox1.Items.Add(NodeName)
        Next
    End Sub

    Public Sub RefreshList(ByVal items As Specialized.StringCollection)
        For Each NodeName As String In items
            CheckedListBox1.Items.Add(NodeName)
        Next
    End Sub

    Private Sub btnSelectAll_Click(sender As System.Object, e As System.EventArgs) Handles btnSelectAll.Click
        For i As Integer = 0 To CheckedListBox1.Items.Count - 1
            CheckedListBox1.SetItemCheckState(i, CheckState.Checked)
        Next
    End Sub

    Private Sub btnSelectNone_Click(sender As System.Object, e As System.EventArgs) Handles btnSelectNone.Click
        For i As Integer = 0 To CheckedListBox1.Items.Count - 1
            CheckedListBox1.SetItemCheckState(i, CheckState.Unchecked)
        Next
    End Sub

    Public ReadOnly Property HasSelections As Boolean
        Get
            If CheckedListBox1.CheckedIndices.Count > 0 Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

    Public ReadOnly Property GetCheckedIndices() As ArrayList
        Get
            Dim list As New ArrayList
            For Each item As Integer In CheckedListBox1.CheckedIndices
                'MessageBox.Show(item.ToString)
                list.Add(item)
            Next
            Return list
        End Get
    End Property

    'Private Sub SeriesAndLimitList_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
    '    For Each controlitem As SeriesAndLimitSelector In flpSelectors.Controls
    '        controlitem.ModifyMargin(Me.Width)
    '    Next
    'End Sub
End Class

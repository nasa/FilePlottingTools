﻿Imports System.Collections

Public Class SeriesAndLimitList

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()
        Me.AutoScaleMode = Windows.Forms.AutoScaleMode.Dpi
        ' Add any initialization after the InitializeComponent() call.

    End Sub
    Public Sub New(ByVal textfile As TextFileInfo)
        Me.New()
        RefreshList(textfile)

    End Sub
    Public Sub RefreshList(ByVal textfile As TextFileInfo)
        For Each Seriesname As String In textfile.SeriesNames
            Dim sls As New SeriesAndLimitSelector(Seriesname)
            flpSelectors.Controls.Add(sls)
        Next
    End Sub

    Private Sub btnSelectAll_Click(sender As System.Object, e As System.EventArgs) Handles btnSelectAll.Click
        For Each SelectionControl As SeriesAndLimitSelector In flpSelectors.Controls
            SelectionControl.chkPlot.Checked = True
        Next
    End Sub

    Private Sub btnSelectNone_Click(sender As System.Object, e As System.EventArgs) Handles btnSelectNone.Click
        For Each SelectionControl As SeriesAndLimitSelector In flpSelectors.Controls
            SelectionControl.chkPlot.Checked = False
        Next
    End Sub

    Public ReadOnly Property HasSelections As Boolean
        Get
            For Each selectcontrol As SeriesAndLimitSelector In flpSelectors.Controls
                If selectcontrol.chkCO.Checked = True Or selectcontrol.chkCS.Checked = True Or selectcontrol.chkHO.Checked = True Or selectcontrol.chkHS.Checked = True Or selectcontrol.chkPlot.Checked = True Then
                    Return True
                End If
            Next
            Return False
        End Get
    End Property

    Public ReadOnly Property GetSeriesControls() As ControlCollection
        Get
            Return flpSelectors.Controls
        End Get
    End Property

    Private Sub SeriesAndLimitList_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
        For Each controlitem As SeriesAndLimitSelector In flpSelectors.Controls
            controlitem.ModifyMargin(Me.Width)
        Next
    End Sub
End Class

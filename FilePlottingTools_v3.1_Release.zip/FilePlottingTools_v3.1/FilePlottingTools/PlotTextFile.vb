﻿Imports System
Imports System.IO
Public Class PlotTextFile
    Private Deliminator As String
    Private filename As String
    Public PastableFile As String

    Public Sub New(ByVal fname As String, ByVal delim As String)
        filename = fname
        Deliminator = delim
    End Sub

    Public Sub New(ByVal fname As String)
        filename = fname
        Deliminator = vbTab
    End Sub

    Public Sub ReadFileIntoClipBoard(ByRef NumLines As Integer, ByRef NumCols As Integer)
        'Reads a file into the clipboard with tab delimited spacing
        'Returns the number of rows and columns in the parsed file

        'NOTE:  HAD A LOT OF TROUBLE WITH SPEED READING IN AND PARSING FILES
        'USING THE STRING CLASS.  IF YOU TRY TO CREATE A STRING WITH VERY LARGE FILES,
        'ADDING CHARACTERS ON EACH LOOP, YOU ALLOCATE MEMORY WHICH SLOWS THE PROCESS DOWN
        'USING A CHARACTER ARRAY TO ALLOCATE MEMORY FIRST IS INCREDIBLY FAST!!!, NEED TO DO THIS FOR LARGE FILES

        NumLines = 0
        NumCols = 0
        Dim plotfilereader As StreamReader = New StreamReader(Me.filename)
        Dim FileString As String = plotfilereader.ReadToEnd
        plotfilereader.Close()
        Dim NumChar As Integer = FileString.Count
        Dim LastWasDelimiter As Boolean = False
        Dim CountOffset As Integer = 0

        Dim IndexOfLastEntry = -1

        Dim FileChars(NumChar) As Char

        For i As Integer = 0 To NumChar - 1
            'MessageBox.Show(Asc(FileString(i)))


            If FileString(i) = Me.Deliminator Then
                'Is the current character a deliminator?
                If LastWasDelimiter Then
                    'if the last found character was also a delimiter, increment the countoffset only
                    CountOffset += 1

                ElseIf Not LastWasDelimiter Then
                    'if the last char was NOT a delimeter, and the current is

                    If i = 0 Then
                        'Check if its the first char your testing
                        CountOffset += 1
                        LastWasDelimiter = True
                    ElseIf FileChars(IndexOfLastEntry) = vbCr Or FileChars(IndexOfLastEntry) = vbCrLf Or FileChars(IndexOfLastEntry) = vbLf Then
                        'check if last entry was a new line, it is, increment countoffset only
                        CountOffset += 1

                    Else
                        'this is the first delimeter found after a number character
                        LastWasDelimiter = True
                        FileChars(i - CountOffset) = vbTab
                        IndexOfLastEntry += 1
                        If NumLines = 0 Then
                            NumCols += 1
                        End If

                    End If
                End If
            Else

                If FileString(i) = vbCr Then
                    If FileChars(IndexOfLastEntry) = vbTab Then
                        'the last entry in the parsed list was a tab
                        'if so, there were extra deliminators after the last entry
                        'remove the last tab

                        FileChars(IndexOfLastEntry) = FileString(i)
                        CountOffset += 1

                    Else
                        'the last entry was not a tab
                        LastWasDelimiter = False

                        FileChars(i - CountOffset) = FileString(i)
                        IndexOfLastEntry += 1

                        If NumLines = 0 Then
                            NumCols += 1
                        End If

                    End If

                    NumLines += 1
                ElseIf FileString(i) = vbLf Then
                    'The current character is a line feed
                    If FileChars(IndexOfLastEntry) = vbCr Then
                        'the last entry was a carrage return
                        FileChars(i - CountOffset) = FileString(i)
                        IndexOfLastEntry += 1
                        LastWasDelimiter = False
                    Else
                        'the last entry was not a carriage return
                        FileChars(i - CountOffset) = FileString(i)
                        IndexOfLastEntry += 1
                        NumLines += 1
                    End If

                Else
                    LastWasDelimiter = False

                    FileChars(i - CountOffset) = FileString(i)
                    IndexOfLastEntry += 1

                End If

            End If

        Next

        My.Computer.Clipboard.Clear()
        'MessageBox.Show(FileChars)
        My.Computer.Clipboard.SetText(FileChars)

    End Sub

    

End Class
